"""Mechanical brief/registry/authority/asset checks. No semantic or legal authority."""
import copy
from pathlib import Path
from composed import engine, jbytes

def execute(function,data,packet,adapter):
    case=data['case_id'];brief=packet['source']['facts']['BRIEF']['value']
    engine.require(brief['id']==case,'Wrong case identity')
    if function=='pack.brief':
        supplied=engine.parse_json(adapter.read_ref(data['briefs_ref']))
        matches=[x for x in supplied['briefs'] if x['id']==case]
        engine.require(len(matches)==1 and matches[0]==brief,'Brief/source mismatch')
        report={'schema':'normalized-campaign-brief/1','version':'1','case_id':case,'brief':copy.deepcopy(brief),'source_ref':data['briefs_ref'],'json_pointer':'/briefs/'+str(supplied['briefs'].index(brief)),'nulls_preserved':True,'external_actions_authorized':False}
    elif function=='pack.registry':
        report=engine.parse_json(adapter.read_ref(data['registry_ref']))
        engine.require(len(report['workflows'])==108 and len({w['workflow_id'] for w in report['workflows']})==108,'Incomplete workflow contract registry')
    elif function=='pack.authority':
        corpus=engine.parse_json(adapter.read_ref(data['corpus_ref']))
        gates=corpus['required_gates']
        engine.require(brief['external_actions_authorized'] is False and all(v is False for v in gates.values()),'This local profile cannot accept live authority')
        report={'schema':'permission-review/1','case_id':case,'source_authority':gates,'decisions':[{'action':a,'state':'blocked','reason':'No explicit live approval or live transport; eligibility and drafts never establish authority.'} for a in ['send','spend','deploy','public_release']], 'recipient':'not supplied','purpose':brief['objective'],'consent':'unestablished_for_real_people','release_authorized':False}
    elif function=='pack.rights':
        manifest=engine.parse_json(adapter.read_ref(data['asset_manifest_ref']));base=Path(data['asset_manifest_ref']['path']).parent
        engine.require(manifest['scenario_id']==case,'Wrong asset case')
        refs=[]
        for f in manifest['files']:
            ref={'path':str(base/f['path']),'sha256':f['sha256'],'media_type':f['media_type'],'artifact_type':'asset'}
            adapter.read_ref(ref,artifact=True);refs.append(ref)
        rights=engine.parse_json(adapter.read_ref(data['readiness_ref']))
        report={'schema':'asset-release-review/1','case_id':case,'content_version':manifest['content_version'],'verified_files':refs,'declared_readiness':rights,'private_scope':'local_synthetic_use_only','release_authorized':False,'unknowns':['Authenticity of declarations','Public release permission','Third-party legal review','Product photography rights not supplied'],'source_scope':'Frozen actual media family, read-only audit. Not a new render.'}
    else:raise ValueError('Unknown mechanical operation')
    report['semantic_truth_verified']=False
    return {'report.json':('application/json',jbytes(report)),'report.txt':('text/plain',jbytes(report))}
