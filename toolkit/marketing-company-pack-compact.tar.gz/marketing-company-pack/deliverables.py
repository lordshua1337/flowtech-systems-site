"""Bounded local producers: proposed wireframes, evidence refresh queue, static markup audit.

No browser, user observation, authentication, network refresh or legal authority.
"""
import copy,csv,hashlib,io,json,textwrap
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from composed import engine,jbytes


def wireflow(brief,source_refs,html_sha):
    case=brief['id'];cta=brief['cta']
    graph={'schema':'proposed-local-wireflow/1','case_id':case,'company':brief['company'],'product':brief['product'],'objective':brief['objective'],'cta':cta,'source_refs':source_refs,'current_html_sha256':html_sha,'scope':'Proposed local demonstration design, not an implemented or browser-tested flow. Nothing sent, stored, booked or registered.','content':['identity','facts','cta','demo_notice','example_email','context','local_ack','validation_messages','confirmation','cancel_notice'],'entries':['landing'],'states':[
      {'id':'landing','kind':'normal','terminal':False,'label':'1. Read the campaign facts','content':['identity','facts','cta','demo_notice'],'controls':[cta],'implementation':'Existing source has landing content and anchor CTA; layout here is a proposed wireframe.'},
      {'id':'form','kind':'normal','terminal':False,'label':'2. Edit fictional details','content':['example_email','context','local_ack','demo_notice'],'controls':['Preview the local demo state','Cancel and return (proposed)'],'implementation':'Form fields and preview exist in current source. Dedicated cancel/return control is proposed, not implemented.'},
      {'id':'error','kind':'error','terminal':False,'label':'3. Validation error','content':['validation_messages','demo_notice'],'controls':['Edit invalid fields (proposed recovery state)','Cancel (proposed)'],'implementation':'Validation messages exist in source logic; dedicated recovery screen and cancel button proposed.'},
      {'id':'recovery','kind':'recovery','terminal':False,'label':'4. Recover and retry','content':['example_email','context','local_ack','validation_messages'],'controls':['Retry preview (proposed separate state)'],'implementation':'Editing and resubmission exist in source logic. Separate recovery screen is proposed; browser behavior unverified.'},
      {'id':'complete','kind':'success','terminal':True,'label':'5. Local preview complete','content':['confirmation','demo_notice'],'controls':[],'implementation':'Local status text is implemented in source. This terminal represents design task completion only, not a real request.'},
      {'id':'cancelled','kind':'success','terminal':True,'label':'6. Cancel / return outcome','content':['cancel_notice','demo_notice'],'controls':[],'implementation':'Dedicated cancel/return terminal is proposed, not implemented. Existing Clear demo is reset, not this navigation.'}],
      'transitions':[
        {'id':'T1','from':'landing','to':'form','trigger':cta},
        {'id':'T2','from':'form','to':'complete','trigger':'Preview with valid made-up details'},
        {'id':'T3','from':'form','to':'error','trigger':'Preview with missing or invalid detail'},
        {'id':'T4','from':'error','to':'recovery','trigger':'Choose to correct the highlighted fields (proposed screen)'},
        {'id':'T5','from':'recovery','to':'form','trigger':'Retry by returning to editable form (proposed screen)'},
        {'id':'T6','from':'form','to':'cancelled','trigger':'Cancel and return to facts (proposed)'},
        {'id':'T7','from':'error','to':'cancelled','trigger':'Cancel after error (proposed)'},
        {'id':'T8','from':'landing','to':'cancelled','trigger':'Leave without preview (proposed explicit action)'}],
      'tasks':[{'id':'preview','start':'landing','goal':'complete','required_content':['identity','facts','cta','demo_notice','example_email','context','local_ack','confirmation']},{'id':'retry','start':'error','goal':'complete','required_content':['validation_messages','confirmation']},{'id':'cancel','start':'form','goal':'cancelled','required_content':['cancel_notice']}],
      'runtime_unknowns':['Browser execution','Focus order and keyboard recovery','Assistive technology announcements','Real people completing tasks','Backend behavior'], 'live_action_authorized':False}
    return graph


def wireframes_svg(graph):
    # Original editable vector/text. Cards are states, labeled connectors refer to full edge ledger.
    width,height=1800,1770;parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">','<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 Z" fill="#536174"/></marker></defs>','<rect width="1800" height="1770" fill="#f4f6fa"/>']
    def text(x,y,value,size=21,color='#192a40',bold=False):
        parts.append(f'<text x="{x}" y="{y}" font-family="DejaVu Sans" font-size="{size}" fill="{color}"'+(' font-weight="bold"' if bold else '')+'>'+escape(value)+'</text>')
    def lines(x,y,value,size=19,wrap=65):
        for i,line in enumerate(textwrap.wrap(value,wrap)):text(x,y+i*(size+8),line,size)
    text(55,53,graph['company']+' | '+graph['product'],29,bold=True)
    text(55,92,'PROPOSED LOCAL DEMO WIREFLOW · editable text and geometry · not browser/backend proof',21)
    text(55,125,'Objective: '+graph['objective']+' | CTA: '+graph['cta'],21)
    text(55,158,'No request, booking, registration, send or storage. Dashed/special recovery and cancel screens are proposed.',20)
    positions={'landing':(55,200),'form':(970,200),'error':(970,560),'recovery':(55,560),'complete':(970,920),'cancelled':(55,920)}
    # Every transition is visible by its unique ID at endpoints; full text appears in the ledger.
    paths={'T1':'M815 335 H970','T2':'M1730 380 H1780 V1020 H1730','T3':'M1370 490 V560','T4':'M970 695 H815','T5':'M815 620 H880 V445 H970','T6':'M1080 490 V525 H900 V1060 H815','T7':'M1080 850 V885 H900 V1100 H815','T8':'M55 335 H20 V1060 H55'}
    labels={'T1':(865,325),'T2':(1738,720),'T3':(1385,532),'T4':(865,684),'T5':(830,603),'T6':(830,1037),'T7':(830,1130),'T8':(24,708)}
    for t in graph['transitions']:
        parts.append(f'<path id="edge-{t["id"]}" d="{paths[t["id"]]}" fill="none" stroke="#536174" stroke-width="3" marker-end="url(#arrow)"/>');text(*labels[t['id']],t['id'],19)
    content={
      'landing':[graph['company']+' / '+graph['product'],'Audience: source brief, not a verified customer segment','Fact-led product summary and unknowns remain visible','CTA: '+graph['cta'],'Local demonstration only. Nothing is sent or saved.'],
      'form':['Example email [ person@example.test ]','Context [ What would you like to evaluate? ]','[ ] I understand this is only a local demo','[ Preview the local demo state ]','[ Cancel and return to facts ] PROPOSED'],
      'error':['Inline error: enter a valid made-up email','Inline error: provide a short fictional context','Inline error: acknowledge local-only demonstration','[ Edit highlighted fields ] PROPOSED recovery screen','[ Cancel ] PROPOSED control'],
      'recovery':['Keep the task context while correcting input','Review email / context / local-only acknowledgement','[ Retry preview ] returns to the editable form','Separate recovery screen is PROPOSED, not current UI','No network retry or backend operation is implied.'],
      'complete':['Local preview state only. Nothing sent or saved.','The fictional details are not a qualified lead.','No demo requested, place reserved or registration made.','Terminal design outcome, not real-world conversion.'],
      'cancelled':['Visitor chooses not to continue the local preview.','Return-to-facts outcome is PROPOSED, not current UI.','No data has been sent, stored or registered.','Existing Clear demo resets fields; it is not navigation.']}
    for s in graph['states']:
        x,y=positions[s['id']];parts.append(f'<g id="state-{s["id"]}"><rect x="{x}" y="{y}" width="760" height="290" rx="12" fill="white" stroke="#79889b" stroke-width="2"/>');text(x+22,y+38,s['label'],25,bold=True)
        for i,line in enumerate(content[s['id']]):lines(x+22,y+78+i*40,line,18,70)
        parts.append('</g>')
    text(55,1260,'Transition ledger: every visible connector maps to its exact graph edge',24,bold=True)
    for i,t in enumerate(graph['transitions']):lines(55,1300+i*42,t['id']+'  '+t['from']+' → '+t['to']+'  |  '+t['trigger'],19,140)
    text(55,1660,'STATIC DESIGN ONLY: implemented source controls and proposed additions are distinguished in wireflow.json.',20)
    text(55,1700,'Graph checks establish reachability only. Real keyboard, browser, assistive-technology and usability results are unknown.',20)
    parts.append('</svg>');return '\n'.join(parts)+'\n'


def freshness(registry,source_refs,case_id,policy):
    engine.require(next(r for r in registry['records'] if r['id']==registry['brief_id'] and r['version']==registry['brief_version'])['payload']['id']==case_id,'Wrong freshness case')
    time_bindings={(x['source_id'],x['version']):x for x in policy.get('source_time_bindings',[])}
    if time_bindings:
        engine.require(policy.get('normalization_profile')=='synthetic-date-label-utc/1','Unsupported date-label convention')
        engine.require(policy.get('cutoff_is_actual_campaign_start') is False and policy.get('source_campaign_start_instant') is None,'Unknown campaign-start instant cannot be claimed')
        engine.require(registry['as_of']==policy['cutoff_date_label']+'T00:00:00Z','Proposed date-label cutoff mismatch')
    checked=engine.registry_report(registry);as_of=engine.instant(registry['as_of']);by={(x['id'],x['version']):x for x in checked['records']};decisions=[];queue=[]
    for record in registry['records']:
        key=(record['id'],record['version']);r=by[key];reasons=[]
        observed=engine.instant(record['observed_at']) if record['observed_at'] else None;valid=engine.instant(record['valid_through']) if record['valid_through'] else None
        if registry['current_versions'].get(record['id'])!=record['version']:reasons.append('superseded_version')
        if valid and as_of>valid:reasons.append('expired_validity')
        if observed and as_of<observed:reasons.append('future_observation')
        if not observed:reasons.append('missing_observation')
        if not valid:reasons.append('missing_validity')
        if not record['source_sha256']:reasons.append('missing_source_hash')
        if record['status']!='current':reasons.append('declared_'+record['status'])
        dependents=[c['id']+'@'+c['version'] for c in registry['records'] if c['kind']=='claim' and c['payload']['evidence_ref']['id']==record['id'] and c['payload']['evidence_ref']['version']==record['version']]
        if record['kind']=='claim':
            target=record['payload']['evidence_ref'];dependency_state=by[(target['id'],target['version'])]['state']
            if dependency_state!='current':reasons.append('linked_evidence_'+dependency_state)
        state='superseded' if 'superseded_version' in reasons else 'expired' if 'expired_validity' in reasons else 'unknown' if r['state']=='unknown' else 'historical' if r['state']=='stale' else 'historical' if 'linked_evidence_stale' in reasons else 'unknown' if 'linked_evidence_unknown' in reasons else 'current'
        row={'source_id':record['id'],'version':record['version'],'source_sha256':record['source_sha256'],'record_sha256':r['record_sha256'],'observed_at':record['observed_at'],'valid_through':record['valid_through'],'declared_cutoff':registry['as_of'],'freshness':state,'registry_state':r['state'],'reasons':reasons,'affected_claims':dependents,'allowed_scope':record['payload'].get('allowed_scopes',[]),'live_reuse_authorized':False}
        time=time_bindings.get(key)
        if time:
            engine.require(time['source_time_precision']=='date_only' and time['source_observed_instant'] is None and time['source_valid_through_instant'] is None,'Date-only source cannot supply exact observation/expiry instants')
            engine.require(record['observed_at']==time['source_observation_date_label']+'T00:00:00Z','Date-label calculation convention mismatch')
            row.update(source_time_precision='date_only',source_observation_date_label=time['source_observation_date_label'],source_date_locator=time['source_date_locator'],source_observed_instant=None,source_valid_through_instant=None,observed_at=None,valid_through=None,calculation_observed_at=record['observed_at'],calculation_valid_through=record['valid_through'],time_normalization='Proposed UTC-midnight date-label convention, not source-observed time or real intraday expiry',freshness_precision='Proposed synthetic date-label policy classification only')
        else:
            row.update(source_time_precision='declared_registry_instant' if record['observed_at'] else 'unknown',source_observation_date_label=None,source_observed_instant=record['observed_at'],source_valid_through_instant=record['valid_through'],calculation_observed_at=record['observed_at'],calculation_valid_through=record['valid_through'],time_normalization='Explicit synthetic registry timestamps only; not independently authenticated observations',freshness_precision='Exact declared-timestamp profile only')
        row.update(cutoff_date_label=policy.get('cutoff_date_label'),source_campaign_timezone=policy.get('source_campaign_timezone'),source_campaign_start_instant=None,cutoff_is_actual_campaign_start=False,cutoff_meaning=policy.get('task_cutoff','Explicit declared test cutoff; not inferred wall-clock or campaign-start time'))
        decisions.append(row)
        if state!='current':
            queue.append({**row,'request_status':'PROPOSED_NOT_SENT','required_observation':'Obtain a new exact-version dated observation and explicit task validity / permitted-use scope; do not overwrite historical source.','impact':'Hold current-use assertions for this version'+(' and dependent claims '+', '.join(dependents) if dependents else '; historical comparison may retain its dated scope.'),'next_action':'Review selected replacement and revalidate dependents' if state=='superseded' else 'Request missing or refreshed evidence through separately authorized research','network_request_made':False})
    return {'schema':'evidence-freshness-decisions/1','case_id':case_id,'as_of':registry['as_of'],'cutoff_source':policy.get('task_cutoff','Explicit declared timestamp test cutoff; not wall clock'), 'source_campaign_start_instant':None, 'cutoff_is_actual_campaign_start':False,'policy':policy,'source_refs':source_refs,'decisions':decisions,'refresh_queue':queue,'registry_report':checked,'authenticity_verified':False,'network_requests':0,'semantic_review_required':True,'boundary_rule':'The calculation valid_through is inclusive. Exact timestamp boundaries apply only within the declared timestamp profile; date-only source labels do not establish real observation times or intraday expiry.'}


def refresh_csv(report):
    s=io.StringIO();fields=['source_id','version','source_sha256','source_time_precision','source_observation_date_label','source_observed_instant','source_valid_through_instant','calculation_observed_at','calculation_valid_through','time_normalization','cutoff_date_label','declared_cutoff','source_campaign_timezone','source_campaign_start_instant','cutoff_is_actual_campaign_start','cutoff_meaning','freshness_precision','freshness','reasons','affected_claims','request_status','required_observation','impact','next_action','network_request_made'];w=csv.DictWriter(s,fieldnames=fields);w.writeheader()
    for r in report['refresh_queue']:w.writerow({k:'; '.join(r[k]) if isinstance(r[k],list) else r[k] for k in fields})
    return s.getvalue()


class Markup(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.nodes=[];self.stack=[]
    def handle_starttag(self,tag,attrs):
        node={'tag':tag,'attrs':dict(attrs),'line':self.getpos()[0],'column':self.getpos()[1]+1,'index':len(self.nodes)+1,'text':'','parents':list(self.stack)};self.nodes.append(node)
        if tag not in {'input','img','meta','link','br','hr','source','area','base','embed','param','track','wbr'}:self.stack.append(node['index'])
    def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs);self.handle_endtag(tag)
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.nodes[self.stack[i]-1]['tag']==tag:self.stack=self.stack[:i];break
    def handle_data(self,data):
        for i in self.stack:self.nodes[i-1]['text']+=data


def audit_markup(raw,case_id,source_path):
    parser=Markup();parser.feed(raw.decode('utf-8'));nodes=parser.nodes;ids={};findings=[];controls=[]
    for n in nodes:
        if n['attrs'].get('id'):ids.setdefault(n['attrs']['id'],[]).append(n)
    def loc(n):return {'source':source_path,'line':n['line'],'column':n['column'],'node_index':n['index'],'tag':n['tag'],'id':n['attrs'].get('id')}
    def finding(code,n,detail,state='FAIL'):findings.append({'code':code,'state':state,'locator':loc(n),'detail':detail})
    for ident,values in ids.items():
        if len(values)>1:
            for n in values:finding('duplicate_id',n,'ID '+ident+' is not unique; referenced name/error targets are ambiguous.')
    role_set=set('alert alertdialog application article banner button cell checkbox columnheader combobox complementary contentinfo definition dialog directory document feed figure form grid gridcell group heading img link list listbox listitem log main marquee math menu menubar menuitem menuitemcheckbox menuitemradio meter navigation none note option presentation progressbar radio radiogroup region row rowgroup rowheader scrollbar search searchbox separator slider spinbutton status switch tab table tablist tabpanel term textbox timer toolbar tooltip tree treegrid treeitem'.split())
    for n in nodes:
        a=n['attrs'];tag=n['tag'];explicit=a.get('role');implicit={'button':'button','textarea':'textbox','select':'combobox','summary':'button'}.get(tag)
        if tag=='input':implicit={'checkbox':'checkbox','radio':'radio','button':'button','submit':'button','reset':'button','range':'slider','number':'spinbutton','hidden':None}.get(a.get('type','text'),'textbox')
        if tag=='a' and 'href' in a:implicit='link'
        if explicit and not any(x in role_set for x in explicit.split()):finding('unknown_aria_role',n,'No recognized ARIA role token: '+explicit)
        relationships=[]
        for attr in ['aria-labelledby','aria-describedby','aria-errormessage']:
            if attr not in a:continue
            for target in a[attr].split():
                matches=ids.get(target,[]);state='STATIC_REFERENCE_EXISTS' if len(matches)==1 else 'FAIL'
                relationships.append({'attribute':attr,'target_id':target,'state':state,'target_locator':loc(matches[0]) if len(matches)==1 else None,'current_text':matches[0]['text'].strip() if len(matches)==1 else None})
                if len(matches)!=1:finding('broken_'+attr,n,'Expected exactly one target for '+target+'; found '+str(len(matches)))
                elif attr in ['aria-describedby','aria-errormessage'] and not matches[0]['text'].strip():finding('empty_dynamic_description',n,'Target '+target+' exists but is initially empty. Runtime error population and announcement are unverified.','UNRESOLVED')
        if not implicit and not (explicit and any(x in {'button','link','checkbox','textbox','combobox','radio','switch'} for x in explicit.split())):continue
        labels=[q for q in nodes if q['tag']=='label' and ((a.get('id') and q['attrs'].get('for')==a['id']) or q['index'] in n['parents'])]
        name_source=None;name=''
        if a.get('aria-labelledby','').strip():name=' '.join(ids[t][0]['text'].strip() for t in a['aria-labelledby'].split() if len(ids.get(t,[]))==1);name_source='aria-labelledby'
        elif 'aria-label' in a:name=(a.get('aria-label') or '').strip();name_source='aria-label'
        elif labels:name=' '.join(q['text'].strip() for q in labels);name_source='label'
        elif tag in {'button','a','summary'}:name=n['text'].strip();name_source='text_content'
        elif tag=='input' and a.get('type') in {'submit','reset','button'}:name=a.get('value','Submit' if a['type']=='submit' else 'Reset' if a['type']=='reset' else '');name_source='value_or_native_default'
        elif a.get('title','').strip():name=a['title'].strip();name_source='title_fallback'
        if not name:finding('empty_control_name',n,'No nonempty static accessible-name candidate. Placeholder text is not a label.')
        if tag in {'input','select','textarea'} and implicit!='button' and not labels and not (a.get('aria-label','').strip() or a.get('aria-labelledby','').strip()):finding('missing_label',n,'Form control lacks an associated label or explicit ARIA label.')
        controls.append({'locator':loc(n),'implicit_role':implicit,'explicit_role':explicit,'name_candidate':name,'name_source':name_source,'label_locators':[loc(q) for q in labels],'relationships':relationships,'runtime_accessible_name_verified':False})
    return {'schema':'static-accessibility-findings/1','case_id':case_id,'source':{'path':source_path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)},'scope':'HTML source only; not the browser accessibility tree or rendered CSS.','controls':controls,'findings':findings,'static_failures':sum(x['state']=='FAIL' for x in findings),'result':'FAIL' if any(x['state']=='FAIL' for x in findings) else 'STATIC_CHECKS_PASS_WITH_RUNTIME_UNRESOLVED','dynamic_unknowns':['Keyboard/focus order','Actual validation and error announcement','Screen-reader accessible names','CSS visibility and visual contrast in the rendered page','Responsive behavior'],'browser_tested':False,'assistive_technology_tested':False,'wcag_certified':False}


def markup_markdown(report):
    s=['# Static accessibility findings',f"Case: {report['case_id']}",f"Source: {report['source']['path']}",f"SHA-256: {report['source']['sha256']}",f"Result: {report['result']}",'','This is source inspection, not browser, keyboard, assistive-technology or whole-WCAG certification.','', '## Controls and relationships']
    for c in report['controls']:s.append(f"- Line {c['locator']['line']}, column {c['locator']['column']}, node {c['locator']['node_index']}: {c['implicit_role'] or c['explicit_role']}; name candidate {c['name_candidate']!r} via {c['name_source']}; relationships {json.dumps(c['relationships'],ensure_ascii=False)}")
    s+=['','## Findings']
    for f in report['findings']:s.append(f"- {f['state']} {f['code']} at line {f['locator']['line']}, column {f['locator']['column']}: {f['detail']}")
    s+=['','## Runtime unresolved']+['- '+x for x in report['dynamic_unknowns']];return '\n'.join(s)+'\n'
