"""Explicit promised-output mapping. Execution, artifact presence and semantic approval differ.

Equivalent filenames/formats are declared, never inferred merely from a successful dispatch.
"""
import csv,hashlib,io,json,re,xml.etree.ElementTree as ET
from pathlib import Path
from composed import ROOT,read_json,sha

# One selector group per promised output, in profile order. #field restricts the content claim.
SELECTORS={
 'R01.W1':['report.json#brief'], 'R01.W2':['packet/schedule.json','packet/disposition.json'], 'R01.W3':['report.json#allocations'],
 'R03.W2':['theme-matrix.csv','report.json#studies'],'R03.W3':['packet/result.json'],
 'R04.W1':['account-identity.csv'],'R04.W2':['report.json#rows','holds.csv'],'R04.W3':['packet/ranked-research-queue.csv','packet/source-ledger.json'],
 'R05.W1':['competitor-comparison.csv'],'R05.W2':['report.json#comparators'],
 'R06.W1':['@input#records','report.json#records'],'R06.W3':['report.json#claims'],'R06.W4':['evidence-refresh-queue.csv'],
 'R07.W4':['manifest.json'],'R09.W1':['campaign-square.svg','edit-proof.svg'],
 'R09.W2':['campaign-square.svg','campaign-landscape.svg','variants.json'],'R09.W3':['sales-sheet.svg','sales-sheet.pdf'],'R09.W4':['print-preflight.json'],
 'R10.W1':['video/edit-decision-list.json'],'R10.W2':['video/review.mp4','video/source-commands.json'],
 'R10.W3':['video/captions.srt','video/captions.vtt','video/caption-audit.json'],'R10.W4':['video/media-qc.json','video/frame-000.png|video/frame-047.png|video/frame-048.png|video/frame-095.png|video/frame-096.png|video/frame-143.png'],
 'R11.W1':['dimension-contract.json'],'R11.W2':['training-technical-view.svg','dimensions.csv'],
 'R12.W1':['query-page-map.csv'],'R12.W2':['report.json#windows'],'R12.W4':['report.json#metadata_findings'],
 'R13.W3':['report.json'],'R13.W4':['report.json#prerequisites'],
 'R14.W1':['social-calendar.csv'],'R14.W4':['report.json'],
 'R15.W3':['media-research.csv'],'R16.W1':['index.html','style.css'],
 'R16.W2':['form-state.js|form-ui.js','@component/vendor/media-web/BUILDER-RESULTS.json'],
 'R16.W3':['metadata.json','route-map.json'],'R16.W4':['web-source-checks.json','browser-checklist.md'],
 'R17.W1':['wireflow.json','wireframes.svg'],'R17.W2':['declared-contrast/packet/report.json','accessibility-findings.md|accessibility-findings.json'],
 'R18.W1':['@helper-input','report.json'],'R18.W3':['report.json#allocations'],'R18.W4':['packet/result.json','packet/report.txt'],
 'R19.W1':['report.json#plans'],'R19.W3':['report.json#allocations'],'R19.W4':['packet/result.json'],
 'R20.W1':['report.json#result'],'R20.W3':['stage-1/email.html|stage-2/email.html|stage-3/email.html','stage-1/email.txt|stage-2/email.txt|stage-3/email.txt','stage-1/asset-manifest.json|stage-2/asset-manifest.json|stage-3/asset-manifest.json'],'R20.W4':['report.json#result'],
 'R21.W1':['report.json#workflows'],'R21.W2':['@run/trace.jsonl','@run/artifact-index.json'],'R21.W3':['@input','report.json'],'R21.W4':['report.json'],
 'R22.W1':['partner-fit.csv'],'R22.W4':['report.json'],
 'R23.W4':['sales-sheet.pdf'],'R24.W1':['packet/result.json','packet/report.txt'],'R24.W2':['report.json','report.json#totals'],'R24.W3':['report.json','report.csv'],
 'R24.W4':['report.html','decision-metrics.csv'],'R25.W2':['packet/result.json'],'R25.W3':['packet/result.json'],'R25.W4':['report.json#interpretation_held','report.json#declared_family_members'],
 'R26.W2':['report.json#decisions'],'R26.W3':['report.json#declared_readiness'],'R27.W1':['report.json#workflow_statuses']}
COMPANION_ALIASES={'change-log.json':'editorial-change-log.json','section-diff.json':'editorial-change-log.json','escalation-queue.json':'community-escalation.json'}


def promises(wid):
    role=int(wid[1:3]);profile=next((ROOT/'roles-content/roles').glob(f'{role:02}-*/AGENT.md'))
    text=profile.read_text();section=text.split('## '+wid+' ',1)[1].split('\n## ',1)[0]
    line=re.search(r'^Output contract: (.+)$',section,re.M).group(1).rstrip('.')
    return profile,line,line.split(' + ')


def inspect_file(path,field=None):
    f=ROOT/path;raw=f.read_bytes()
    if not raw:raise ValueError('Promised deliverable is empty: '+path)
    result={'path':path,'sha256':sha(raw),'bytes':len(raw)}
    suffix=f.suffix.lower()
    if suffix=='.json':
        value=json.loads(raw);selected=value
        if field:
            for key in field.split('.'):
                if not isinstance(selected,dict) or key not in selected:raise ValueError('Missing promised content field '+path+'#'+field)
                selected=selected[key]
        result.update(actual_type='structured JSON',content_locator='#'+field if field else '$',content_summary={'top_level_keys':list(value) if isinstance(value,dict) else None,'selected_type':type(selected).__name__,'selected_item_count':len(selected) if isinstance(selected,(list,dict)) else None})
        if isinstance(value,dict) and isinstance(value.get('sections'),dict):result['content_summary']['authored_section_headings']=list(value['sections'])
    elif suffix=='.jsonl':
        rows=[json.loads(line) for line in raw.splitlines()];result.update(actual_type='JSON Lines',content_summary={'records':len(rows),'record_fields':list(rows[0]) if rows else []})
    elif suffix=='.csv':
        rows=list(csv.reader(io.StringIO(raw.decode())));assert rows and len(rows[0])>1
        result.update(actual_type='CSV table',content_summary={'columns':rows[0],'data_rows':len(rows)-1})
    elif suffix=='.svg':
        node=ET.fromstring(raw);assert node.tag=='{http://www.w3.org/2000/svg}svg';result.update(actual_type='editable SVG',content_summary={'viewBox':node.attrib.get('viewBox'),'editable_text_nodes':len(list(node.iter('{http://www.w3.org/2000/svg}text'))),'elements':len(list(node.iter()))})
    elif suffix=='.pdf':
        assert raw.startswith(b'%PDF');result.update(actual_type='PDF document',content_summary={'pdf_signature':True,'layout_proof_separate':True})
    elif suffix=='.png':
        assert raw.startswith(b'\x89PNG\r\n\x1a\n');result.update(actual_type='PNG proof',content_summary={'width':int.from_bytes(raw[16:20],'big'),'height':int.from_bytes(raw[20:24],'big')})
    elif suffix=='.mp4':
        assert raw[4:8]==b'ftyp';result.update(actual_type='MP4 video',content_summary={'container_signature':True,'actual_decode_check_in_bundle':True})
    else:
        text=raw.decode('utf-8');assert len(text.strip())>10
        result.update(actual_type={'.html':'HTML source','.js':'JavaScript source','.css':'CSS source','.srt':'SubRip captions','.vtt':'WebVTT captions'}.get(suffix,'readable text'),content_summary={'characters':len(text),'lines':len(text.splitlines())})
    return result


def accept(wid,case,bundle_ref,input_ref):
    profile,contract,required=promises(wid);bundle=read_json(ROOT/bundle_ref['path']);parent=Path(bundle_ref['path']).parent
    files={str(Path(x['path']).relative_to(parent)):x['path'] for x in bundle['files']}
    run_root=Path(bundle_ref['path']).parents[2];bindings=SELECTORS.get(wid)
    if bundle['selected_function']=='shared.authored':
        bindings=[]
        for wanted in required:
            name=COMPANION_ALIASES.get(wanted,wanted);companion=ROOT/'roles-content/content'/case/name
            bindings.append('@component/'+str(companion.relative_to(ROOT)) if companion.is_file() else 'report.json#sections')
    if not bindings or len(bindings)!=len(required):raise ValueError('No explicit promised-deliverable mapping: '+wid)
    mapped=[]
    for wanted,selectors in zip(required,bindings):
        actual=[]
        for selector in selectors.split('|'):
            selector,sep,field=selector.partition('#')
            if selector=='@input':path=input_ref['path']
            elif selector=='@helper-input':path=read_json(ROOT/input_ref['path'])['input_ref']['path']
            elif selector.startswith('@component/'):path=selector[len('@component/'):]
            elif selector.startswith('@run/'):path=str(run_root/selector[len('@run/'):])
            else:
                if selector not in files:raise ValueError('Missing promised deliverable '+wanted+' ('+selector+') for '+wid)
                path=files[selector]
            actual.append(inspect_file(path,field if sep else None))
        mapped.append({'promised':wanted,'status':'ACTUAL_CONTENT_BOUND_SEMANTIC_REVIEW_REQUIRED','actual':actual,'equivalence_note':'Exact named artifact or explicitly selected content/field equivalent. JSON prose reports retain full authored sections; companions are separately identified. Invocation status alone is not acceptance.'})
    # These production obligations cannot be fulfilled by a diagnostic-only or generic registry bundle.
    if wid=='R17.W1':
        g=read_json(ROOT/files['wireflow.json']);check=read_json(ROOT/files['graph-check.json']);assert check['pass'] is True and check['errors']==[];assert g['case_id']==case and len(g['states'])==6 and len(g['transitions'])==8
        expected=read_json(ROOT/'inputs'/case/'run.json')['source']['facts']['BRIEF']['value'];assert g['cta']==expected['cta'] and g['objective']==expected['objective'];assert not g['live_action_authorized']
    elif wid=='R06.W4':
        r=read_json(ROOT/files['freshness-decisions.json']);assert r['case_id']==case and r['as_of'] and r['refresh_queue'];assert any(x['affected_claims'] for x in r['refresh_queue']);assert all(x['request_status']=='PROPOSED_NOT_SENT' for x in r['refresh_queue']);assert r['network_requests']==0
    elif wid=='R17.W2':
        r=read_json(ROOT/files['accessibility-findings.json']);raw=(ROOT/files['current-html/index.html']).read_bytes();assert r['source']['sha256']==sha(raw) and r['case_id']==case;assert len(r['controls'])>=10 and r['dynamic_unknowns'];assert not r['browser_tested'];assert 'result' in r
    return {'profile_path':str(profile.relative_to(ROOT)),'profile_sha256':sha(profile.read_bytes()),'output_contract':contract,'deliverables':mapped,'status':'DELIVERABLES_PRESENT_CONTENT_CHECKED','semantic_equivalence_requires_independent_review':True,'runtime_diagnostic_results_not_overridden':True}


def harness_accept(wid,relative,campaigns):
    profile,contract,required=promises(wid)
    holds={'R11.W3':'Native product geometry unavailable; no production input bundle claimed.','R11.W4':'Native scene bundle unavailable; training example is not product rendering.','R27.W4':'Final ZIP release manifest and extracted replay require the separate release gate.'}
    if wid in holds:return {'output_contract':contract,'status':'UNMET_EXPLICIT_HOLD','deliverables':[{'promised':p,'status':'UNMET_EXPLICIT_HOLD','actual':[],'reason':holds[wid]} for p in required]}
    if wid in {'R01.W4','R26.W4'}:selectors=[[relative+'/exercises/owner-feedback.json']]*len(required)
    elif wid=='R27.W3':selectors=[[relative+'/exercises/RESULT.json']]
    elif wid=='R27.W2':selectors=[[relative+'/CAMPAIGNS.json'],[x['trace'] for x in campaigns.values()]]
    else:raise ValueError('Missing harness acceptance mapping '+wid)
    return {'profile_path':str(profile.relative_to(ROOT)),'profile_sha256':sha(profile.read_bytes()),'output_contract':contract,'status':'HARNESS_CONTENT_PRESENT_REVIEW_REQUIRED','deliverables':[{'promised':p,'status':'ACTUAL_HARNESS_CONTENT','actual':[inspect_file(s) for s in paths]} for p,paths in zip(required,selectors)],'semantic_equivalence_requires_independent_review':True}
