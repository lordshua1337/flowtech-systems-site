"""Fixed subprocess boundary for trusted local business, media, email and lead code."""
import hashlib, importlib.util, json, shutil, sys
from pathlib import Path
from portable_receipts import path_stdout,retain_raw
from composed import ROOT, FUNCTIONS, safe_path, read_json, jbytes, sha, verify_lock

def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def bound(ref):
    p=safe_path(ROOT,ref['path'])
    if sha(p.read_bytes())!=ref['sha256']:raise ValueError('Changed secondary input: '+ref['path'])
    return p

def execute(function,data,out):
    nested=0;detail={}
    if function.startswith('business.'):
        sys.path.insert(0,str(ROOT/'vendor/business-workflows'))
        import runtime
        envelope=data['envelope']
        if envelope['operation']!=function.split('.')[1]:raise ValueError('Wrong business operation')
        out.mkdir()
        for name,raw in runtime.render_artifacts(jbytes(envelope)).items():(out/name).write_bytes(raw)
        detail={'call':'runtime.render_artifacts','scope':data.get('input_scope','Supplied finite fictional records, not live business results'),'case_id':data['case_id']}
    elif function.startswith('media.'):
        m=module('trusted_media',ROOT/'vendor/media-web/build.py')
        original=m.command
        def count_command(*args,**kwargs):
            nonlocal nested
            nested+=1;return original(*args,**kwargs)
        m.command=count_command
        briefs=bound(data['briefs_ref']);corpus=bound(data['corpus_ref']);content=bound(data['content_ref'])
        b=m.validate_inputs(read_json(briefs),read_json(corpus),read_json(content),data['case_id']);c=read_json(content);source=read_json(corpus)
        mode=function.split('.')[1]
        if mode=='graphics':
            m.build(briefs,corpus,content,sha(briefs.read_bytes()),sha(corpus.read_bytes()),sha(content.read_bytes()),data['case_id'],out,False)
        else:
            out.mkdir()
            if mode=='video':m.render_video(b,c,source,out)
            elif mode=='technical':m.technical(source,out)
            elif mode=='web':
                design={'schema':'campaign-design-source/1','brief':b,'copy':c['campaign'],'palette':c['creative']['palette'],'variant':'square','width':1080,'height':1080,'accent_stripe':c['creative']['palette']['accent'],'accent_width':72}
                m.render_campaign(design,out/'campaign-square.svg');m.landing(b,c,out);m.inspect_web(out)
            else:raise ValueError('Unsupported media mode')
            (out/'authored-copy.json').write_bytes(content.read_bytes());(out/'source-brief.json').write_bytes(jbytes(b))
        detail={'call':{'graphics':'build(video=False)','video':'validate_inputs + render_video','technical':'validate_inputs + technical','web':'validate_inputs + render_campaign + landing + inspect_web'}[mode], 'case_id':data['case_id'],'closed_three_brief_examples':True,'native_3d':'held','browser_proof':'held','authored_copy_sha256':sha(content.read_bytes())}
    elif function=='email.build':
        import subprocess
        out.mkdir();runs=[]
        for i,ref in enumerate(data['stages'],1):
            inp=bound(ref);dest=out/f'stage-{i}'
            p=subprocess.run([sys.executable,'-B',str(ROOT/'vendor/email-portable-v1/scripts/build_email.py'),str(inp),str(dest)],capture_output=True)
            nested+=1;runs.append({'stage':i,'input_sha256':ref['sha256'],'returncode':p.returncode,'stdout_presentation':path_stdout(p.stdout,dest,f'stage-{i}','email-stdout') if p.returncode==0 else {'raw_error_stdout':retain_raw('email-error-stdout',p.stdout)},'stderr':p.stderr.decode(errors='replace') if not p.stderr else {'raw_error_stderr':retain_raw('email-stderr',p.stderr)}})
            if p.returncode:raise ValueError('Email builder failed: '+p.stderr.decode(errors='replace'))
        detail={'call':'exact build_email.py, three stages','runs':runs,'case_id':data['case_id'],'rendered_client_compatibility':False,'send_authority':False}
    elif function.startswith('helper.'):
        import subprocess
        from helpers import HELPERS
        name=function.split('.')[1];spec=HELPERS[name];base=ROOT/'vendor/reused-helpers'/spec['owner'];inp=bound(data['input_ref'])
        out.mkdir();dest=out/('report.json' if spec.get('output_file') else 'packet');args=[str(inp.relative_to(ROOT)) if x=='{input}' else (str(dest) if name=='dependency' else str(dest.relative_to(ROOT))) if x=='{output}' else x for x in spec['args']]
        p=subprocess.run([sys.executable,'-B',str((base/spec['script']).relative_to(ROOT)),*args],cwd=ROOT,capture_output=True);nested+=1
        if name in {'dependency','coding','contrast'} and p.returncode in (0,1):
            field='report_directory' if name=='contrast' else 'output'
            presentation=path_stdout(p.stdout,dest,'packet','helper-'+name+'-stdout',field)
            (out/'stdout.presentation.json').write_bytes(jbytes(presentation))
        else:(out/'stdout.txt').write_bytes(p.stdout)
        (out/'stderr.txt').write_bytes(p.stderr)
        if p.returncode not in (0,1):raise ValueError('Helper failed: '+p.stderr.decode(errors='replace'))
        if spec.get('stdout_report'):
            parsed=json.loads(p.stdout);(out/'report.json').write_bytes(jbytes(parsed))
        elif not (dest.is_dir() or spec.get('output_file') and dest.is_file()):raise ValueError('Helper produced no packet')
        detail={'call':str(base.relative_to(ROOT)/spec['script']),'case_scope':'Supplemental original synthetic helper fixture, NOT campaign observations','exit_code':p.returncode,'diagnostics_may_contain_holds':True,'input_sha256':data['input_ref']['sha256']}
    elif function in {'design.wireflow','audit.markup','evidence.refresh'}:
        import deliverables
        out.mkdir()
        if function=='evidence.refresh':
            registry=read_json(bound(data['registry_ref']))
            for ref in data['source_refs']:bound(ref)
            report=deliverables.freshness(registry,data['source_refs'],data['case_id'],data['policy'])
            (out/'freshness-decisions.json').write_bytes(jbytes(report))
            (out/'evidence-refresh-queue.csv').write_text(deliverables.refresh_csv(report))
            (out/'refresh-requests.json').write_bytes(jbytes(report['refresh_queue']))
            detail={'call':'shared engine.registry_report + deliverables.freshness','case_id':data['case_id'],'network_requests':0}
        else:
            m=module('trusted_media',ROOT/'vendor/media-web/build.py')
            briefs=read_json(bound(data['briefs_ref']));corpus=read_json(bound(data['corpus_ref']));content=read_json(bound(data['content_ref']))
            b=m.validate_inputs(briefs,corpus,content,data['case_id'])
            source=out/'current-html';source.mkdir();m.landing(b,content,source)
            html=(source/'index.html').read_bytes()
            if function=='design.wireflow':
                graph=deliverables.wireflow(b,{k:data[k] for k in ['briefs_ref','corpus_ref','content_ref']},sha(html))
                checker=module('exact_graph_checker',ROOT/'vendor/reused-helpers/design-experience-architecture/scripts/check_flow.py')
                errors=checker.check(graph)
                (out/'wireflow.json').write_bytes(jbytes(graph));(out/'wireframes.svg').write_text(deliverables.wireframes_svg(graph))
                (out/'graph-check.json').write_bytes(jbytes({'pass':not errors,'errors':errors,'input_sha256':sha(jbytes(graph)),'checker_sha256':sha((ROOT/'vendor/reused-helpers/design-experience-architecture/scripts/check_flow.py').read_bytes()),'scope':'Static proposed graph only, not browser usability'}))
                if errors:raise ValueError('Proposed wireflow graph is invalid')
                import subprocess
                subprocess.run(['inkscape',str(out/'wireframes.svg'),'--export-type=png','--export-filename='+str(out/'wireframes-proof.png')],check=True,capture_output=True);nested+=1
                detail={'call':'deliverables.wireflow + exact check_flow.check + original editable SVG render','case_id':data['case_id'],'browser_tested':False}
            else:
                report=deliverables.audit_markup(html,data['case_id'],'current-html/index.html')
                (out/'accessibility-findings.json').write_bytes(jbytes(report));(out/'accessibility-findings.md').write_text(deliverables.markup_markdown(report))
                execute('helper.contrast',{'input_ref':data['contrast_input_ref']},out/'declared-contrast')
                contrast=out/'declared-contrast'/'packet'/'report.json'
                # The exact helper's diagnostic is separate, never relabeled as whole-page compliance.
                (out/'contrast-report.json').write_bytes(jbytes({'schema':'separate-declared-contrast/1','scope':'Supplemental declared uniform-color fixture, not measured current page contrast','diagnostic_files':[str(f.relative_to(out)) for f in sorted((out/'declared-contrast').rglob('*')) if f.is_file()],'input_ref':data['contrast_input_ref'],'page_contrast_status':'UNRESOLVED'}))
                nested+=1
                detail={'call':'current landing producer + deliverables.audit_markup + unchanged declared contrast helper','case_id':data['case_id'],'browser_tested':False,'diagnostic_failures_preserved':True}
    elif function=='editorial.check':
        m=module('trusted_editorial',ROOT/'vendor/editorial-check/editorial_check.py');out.mkdir()
        inp=bound(data['annotation_ref']);r=m.check(m.parse(inp.read_bytes()));(out/'report.json').write_bytes(jbytes(r))
        authored=bound(data['authored_review_ref']);(out/'authored-review.json').write_bytes(authored.read_bytes())
        detail={'call':'editorial_check.check','case_id':data['case_id'],'mismatch_means_report_diagnostic_not_cli_refusal':True,'annotations_not_automatically_extracted':True}
    elif function=='lead.plan':
        m=module('trusted_lead',ROOT/'vendor/lead-followup-portable-v1/lead_followup.py');out.mkdir()
        result=m.plan(data['snapshot'],ROOT/'vendor/lead-followup-portable-v1/vendor/simulate.py')
        (out/'report.json').write_bytes(jbytes(result));detail={'call':'lead_followup.plan','case_id':data['case_id'],'no_sends':True}
    else:raise ValueError('Function not supported by subprocess boundary')
    (out/'execution.json').write_bytes(jbytes({'schema':'whitelisted-execution/1','function':function,'nested_processes':nested,'external_calls':0,'detail':detail}))

if __name__=='__main__':
    try:
        function,input_path,output=sys.argv[1:]
        if function not in FUNCTIONS:raise ValueError('Unsupported function')
        verify_lock();out=Path(output)
        if out.exists() or out.is_symlink() or any(p.is_symlink() for p in out.parents):raise ValueError('Unsafe/existing invocation output')
        execute(function,read_json(input_path),out)
    except Exception as exc:
        print(type(exc).__name__+': '+str(exc),file=sys.stderr);raise SystemExit(2)
