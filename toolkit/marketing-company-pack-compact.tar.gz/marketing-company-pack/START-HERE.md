# Use the pack

Choose a case: MapleBench/LoopStand, Harbor Lantern Workshops, or LedgerNest. Open that case's final evidence folder first to inspect the actual deliverables without rerunning dependencies.

The most immediately useful files are the authored landing/ad/lifecycle copy, strategy and research drafts, editable campaign SVGs, seller PDF, six-second silent video with captions, static local-only web page, HTML/text email stages and source-bound numerical/authority reports. Native3D, real-browser and live-launch capabilities are explicitly not cleared.

For the recorded new run, open `evidence/final-validation/campaigns/CASE/CASE/role-16-1/index.html` in your own browser as a local demo. It sends and stores nothing. The page source and reducer were checked; your actual browser/keyboard/assistive-technology behavior is not certified by that fact.

Other recorded artifacts use the same directory pattern:

- role-08-1/report.txt: authored landing copy, packaged unchanged.
- role-09-1/campaign-square.svg and sales-sheet.pdf: editable original vector and one-page seller proof.
- role-10-1/video/review.mp4: actual silent procedural edit, with source clips, lineage and supplied captions in the same folder.
- role-11-1/dimension-contract.json: explicit unknown product axes and blocked native geometry/rendering.
- role-20-1/stage-1/email.html and email.txt: first of three real HTML/text stages.
- role-24-1/report.html: source-bound sample metrics, not observed campaign performance.
- role-27-1/report.json: actual upstream artifact integrity audit, not independent semantic approval.

Each folder has a bundle.json with exact produced files and digests. The top-level trace shows note→selected role→orchestrator receipts. The role's proposal envelope is only a pointer to the real file products, not canned substantive work.

For a new campaign, use the matching self-contained role instructions, provide actual sources and preserve unknowns. Do not relabel these fictional examples as current customer data or production-ready artifacts. Authoring requires an actual model/human author; local packaging is not generative reasoning. Review every consequential statement, audience, destination and permission before any separately authorized external action.

New workflow deliverables are under evidence/final-validation/workflows/CASE-R17-W1/CASE-R17-W1/R17-W1-1/ (wireflow.json and editable wireframes.svg); use CASE-R06-W4 for the freshness-decisions.json and evidence-refresh-queue.csv, and CASE-R17-W2 for accessibility-findings.json/.md and the separate declared-contrast folder. Replace CASE with the chosen case ID. These are proposed local design / source inspection / declared-cutoff review outputs, not browser or live research proof.

Freshness classifications use a proposed synthetic 00:00 UTC review convention on source date labels. They do not establish actual America/Chicago campaign-start time or exact observation/expiry instants. The output preserves date-only precision and null unknown real instants beside explicitly labeled calculation timestamps.
