"""Retain real failure, recovery and narrow owner-feedback exercise receipts."""
import copy, json, sys
from pathlib import Path
from composed import ROOT,Adapter,Orchestrator,read_json,jbytes,file_reference,make_result,ContractError,safe_path

def exercises(relative):
    out=safe_path(ROOT,relative);out.mkdir(parents=True,exist_ok=False)
    manifest=read_json(ROOT/'inputs/maplebench/run.json')
    def write(name,data):
        f=out/name;f.write_bytes(jbytes(data));return file_reference(ROOT,str(f.relative_to(ROOT)),'exercise_input')
    def run(name,jobs,adapter_cls=Adapter):
        adapter=adapter_cls(ROOT,relative+'/'+name)
        runner=Orchestrator(manifest['source'],manifest['roles'],jobs,catalog=manifest['catalog'],root=ROOT,adapter=adapter,run_id=name)
        return runner,adapter
    def job(name,role,skill,ref=None,requires=None):
        return {'id':name,'role_id':role,'skill_id':skill,'inputs':[ref or manifest['workflow_inputs'][skill]],'requires':requires or []}
    def save(name,r):
        r.save_trace(out/(name+'.jsonl'));(out/(name+'.json')).write_bytes(jbytes(r.summary()))
    d=read_json(ROOT/'inputs/maplebench/allocation.json');d['allocations'][1]['amount_minor']+=1
    r,a=run('over-cap',[job('budget',1,'R01.W3',write('over-cap-input.json',d))]);s=r.run(a);assert s['terminal']=='failed';save('over-cap',r)
    d=read_json(ROOT/'inputs/maplebench/allocation.json');ref=write('recover-input.json',d);raw=(out/'recover-input.json').read_bytes();(out/'recover-input.json').unlink()
    r,a=run('recover',[job('budget',1,'R01.W3',ref)]);r.accept(a(r.begin('budget')));assert r.counters['retries']==1;(out/'recover-input.json').write_bytes(raw);s=r.run(a);assert s['task_chain_complete'];save('recover',r)
    bad=write('unsupported-copy.json',{'schema':'authored-content/1','title':'Seeded unsupported population claim','sections':{'Copy':['60% of coffee shops lack counter space. Request a demo.']}})
    good=write('corrected-copy.json',{'schema':'authored-content/1','title':'Corrected bounded research claim','sections':{'Copy':['In five fictional convenience interviews, three participants mentioned cramped counters. This does not establish population prevalence or purchase intent. Request a demo.']}})
    class NarrowReview(Adapter):
        def __call__(self,packet):
            if packet['role_id']==26:
                target=packet['review_targets']['copy'];self.verify_files(target)
                bundle=read_json(ROOT/target['files'][0]['path']);texts=[self.read_ref(f,artifact=True).decode() for f in bundle['files'] if f['path'].endswith('/report.txt')]
                if any('60% of coffee shops lack counter space.' in t for t in texts):
                    return make_result(packet,status='rework',review={'target_job_id':'copy','target_artifact_id':target['id'],'reason':'Exact seeded population inference is unsupported by five convenience interviews. Return to original Copywriter; retain3/5 sample context and CTA.'})
            return super().__call__(packet)
    jobs=[job('budget',1,'R01.W3'),job('copy',8,'R08.W1',bad),job('handoff',21,'R21.W2',requires=[{'job_id':'copy','artifact_type':manifest['roles'][7]['output_type']}]),job('review',26,'R26.W1',requires=[{'job_id':'copy','artifact_type':manifest['roles'][7]['output_type']},{'job_id':'handoff','artifact_type':manifest['roles'][20]['output_type']}])]
    jobs[1]['retry_inputs']=[good];jobs[-1]['review_targets']=['copy']
    r,a=run('owner-feedback',jobs,NarrowReview);s=r.run(a,external_actions=['send','deploy']);assert s['task_chain_complete'];assert s['counters']['reworks']==1;assert s['counters']['invalidated_artifacts']==2;assert r.attempts['budget']==1
    assert len([x for x in r.receipts if x['job_id']=='budget'])==1;save('owner-feedback',r)
    budget_ref=r.artifacts['budget']['files'][0];before=(ROOT/budget_ref['path']).read_bytes()
    # The original current budget bundle was never regenerated or altered during copy rework.
    assert a.read_ref(budget_ref,artifact=True)==before
    statuses={'over_cap':'refused','missing_input_same_hash_recovery':'completed_after_one_retry','owner_feedback':'one_rework_to_original_owner','invalidated_descendants':2,'unrelated_budget_attempts':1,'external_actions':'blocked','semantic_scope':'Exact seeded literal rule only; not a generic semantic reviewer.','new_source_truth_created':False}
    (out/'RESULT.json').write_bytes(jbytes(statuses));return statuses
if __name__=='__main__':print(json.dumps(exercises(sys.argv[1]),indent=2))
