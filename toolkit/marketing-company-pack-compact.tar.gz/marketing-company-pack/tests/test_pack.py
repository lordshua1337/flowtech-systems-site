"""Fresh integrated checks. These do not constitute independent semantic review."""
import copy, hashlib, json, os, shutil, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from composed import Adapter,Orchestrator,engine,read_json,jbytes,verify_lock,safe_path,file_reference,make_result,ContractError
from helpers import HELPERS

class PackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.m=read_json(ROOT/'inputs/maplebench/run.json')
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='.test-',dir=ROOT);self.path=Path(self.temp.name);self.rel=str(self.path.relative_to(ROOT))
    def tearDown(self):self.temp.cleanup()
    def write(self,name,value):
        f=self.path/name;f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes(jbytes(value));return file_reference(ROOT,str(f.relative_to(ROOT)),'test_input')
    def runner(self,jobs,roles=None,run_id='test'):
        adapter=Adapter(ROOT,self.rel+'/outputs')
        runner=Orchestrator(self.m['source'],roles or self.m['roles'],jobs,catalog=self.m['catalog'],root=ROOT,adapter=adapter,run_id=run_id)
        return runner,adapter
    def one(self,workflow='R01.W3',ref=None):
        role=int(workflow[1:3]);return [{'id':'one','role_id':role,'skill_id':workflow,'requires':[],'inputs':[ref or self.m['workflow_inputs'][workflow]]}]
    def test_108_unique_registry(self):
        rows=read_json(ROOT/'WORKFLOWS.json')['workflows'];self.assertEqual({x['workflow_id'] for x in rows},{f'R{r:02}.W{w}' for r in range(1,28) for w in range(1,5)})
    def test_27_role_profiles(self):self.assertEqual(len(list((ROOT/'roles-content/roles').glob('*/AGENT.md'))),27)
    def test_original_owner_envelopes_preserved(self):
        originals=read_json(ROOT/'vendor/shared-runtime/legacy/fixtures/roles.json')
        for original,now in zip(originals,self.m['roles']):
            for key in ['id','output_type','proposal_fields','group']:self.assertEqual(original[key],now[key])
    def test_source_lock(self):self.assertGreater(verify_lock(),1000)
    def test_source_lock_tamper_detected(self):
        lock=read_json(ROOT/'SOURCE-LOCK.json');lock['files']=[{'path':'sample.py','sha256':'0'*64,'bytes':4}];(self.path/'SOURCE-LOCK.json').write_bytes(jbytes(lock));(self.path/'sample.py').write_text('nope')
        with self.assertRaises(ValueError):verify_lock(self.path)
    def test_unsafe_relative_path(self):
        for name in ['../escape','/tmp/escape']:
            with self.assertRaises(ValueError):safe_path(ROOT,name)
    def test_symlink_ref_refused(self):
        (self.path/'link').symlink_to(ROOT/'inputs/scenario-seeds.json')
        with self.assertRaises(ValueError):safe_path(ROOT,self.rel+'/link')
    def test_selected_real_function(self):
        r,a=self.runner(self.one());result=r.run(a);self.assertTrue(result['task_chain_complete']);self.assertEqual(result['file_counters']['function_invocations'],1);self.assertEqual(len(r.receipts),1)
    def test_cap_overrun(self):
        d=read_json(ROOT/'inputs/maplebench/allocation.json');d['allocations'][1]['amount_minor']+=1
        r,a=self.runner(self.one(ref=self.write('bad.json',d)));s=r.run(a);self.assertEqual(s['terminal'],'failed');self.assertEqual(s['counters']['retries'],0)
    def test_missing_input_bounded_failure(self):
        ref=self.write('missing.json',{'x':1});(self.path/'missing.json').unlink();r,a=self.runner(self.one(ref=ref));s=r.run(a)
        self.assertEqual(s['terminal'],'failed');self.assertEqual(s['counters']['dispatches'],2);self.assertEqual(s['counters']['retries'],1)
    def test_missing_input_restored_same_hash(self):
        d=read_json(ROOT/'inputs/maplebench/allocation.json');ref=self.write('restore.json',d);raw=(self.path/'restore.json').read_bytes();(self.path/'restore.json').unlink();r,a=self.runner(self.one(ref=ref))
        r.accept(a(r.begin('one')));(self.path/'restore.json').write_bytes(raw);s=r.run(a)
        self.assertTrue(s['task_chain_complete']);self.assertEqual(s['counters']['retries'],1)
    def test_wrong_role_rejected(self):
        r,a=self.runner(self.one());p=r.begin('one');result=a(p);result['role_id']=2
        with self.assertRaises(ContractError):r.accept(result)
    def test_terminal_late_result_refused(self):
        r,a=self.runner(self.one());p=r.begin('one');result=a(p);r.finish('failed')
        with self.assertRaises(ContractError):r.accept(result)
    def test_wrong_skill_owner_refused(self):
        jobs=self.one();jobs[0]['skill_id']='R02.W1'
        with self.assertRaises(ValueError):self.runner(jobs)
    def test_output_tamper_rejected(self):
        r,a=self.runner(self.one());result=a(r.begin('one'));b=read_json(ROOT/result['artifact']['files'][0]['path']);f=ROOT/b['files'][0]['path'];f.write_text('tamper')
        with self.assertRaises(ValueError):r.accept(result)
    def test_no_clobber(self):
        r,a=self.runner(self.one());p=r.begin('one');first=a(p);bundle=ROOT/first['artifact']['files'][0]['path'];before=bundle.read_bytes();second=a(p)
        self.assertEqual(second['status'],'failed');self.assertEqual(bundle.read_bytes(),before)
    def test_holds_do_not_become_pass(self):
        rows={x['workflow_id']:x for x in read_json(ROOT/'WORKFLOWS.json')['workflows']}
        for wid in ['R11.W3','R11.W4']:self.assertEqual(rows[wid]['status'],'blocked_native_runtime');self.assertIsNone(rows[wid]['execution'])
    def test_no_canned_adapter_used(self):
        src=(ROOT/'composed.py').read_text();self.assertNotIn('FileRoleplayAdapter',src);self.assertNotIn('roleplay.json',src)
    def test_three_independent_notes(self):
        ms=[read_json(ROOT/'inputs'/c/'run.json') for c in ['maplebench','harbor_workshops','ledgernest']]
        self.assertEqual(len({x['source']['note'] for x in ms}),3)
        for m in ms:self.assertEqual(len(m['jobs']),27)
    def test_latest_comparator_observation_retained(self):
        d=read_json(ROOT/'inputs/maplebench/competitors.json')['envelope']['data']['comparators'][0]
        self.assertEqual(d['observed']['price_minor'],18900);self.assertEqual(d['baseline']['price_minor'],17900);self.assertIsNone(d['observed']['shipping_minor'])
    def test_unknowns_retained(self):
        b=read_json(ROOT/'inputs/scenario-seeds.json')['briefs'];self.assertIsNone(b[0]['product_facts']['dimension_axis_order']);self.assertIsNone(b[1]['product_facts']['refund_policy']);self.assertIn('real-time two-way sync',b[2]['product_facts']['unverified_features'])
    def test_declared_plan_totals(self):
        for case,total in [('maplebench',150000),('harbor_workshops',120000),('ledgernest',200000)]:
            r=engine.allocation_report(read_json(ROOT/'inputs'/case/'allocation.json'));self.assertEqual(r['total_minor'],total);self.assertEqual(r['headroom_minor'],0);self.assertFalse(r['platform_budget_enforced'])
    def test_purchase_alias_refused(self):
        x=read_json(ROOT/'vendor/shared-runtime/fixtures/demo-events.json');x['profile']='settled-paid-purchase'
        with self.assertRaises(ValueError):engine.demo_report(x)
    def test_registry_unknown_asset_rights(self):
        r=engine.registry_report(read_json(ROOT/'inputs/maplebench/registry.json'));self.assertEqual(r['assets'][0]['rights_status'],'unknown');self.assertFalse(r['ready_for_live_release']);self.assertTrue(r['blockers'])
    def test_authored_is_not_generation(self):
        r=engine.authored_report(read_json(ROOT/'roles-content/content/maplebench/R08.W1.json'));self.assertFalse(r['semantic_truth_verified'])
    def test_helper_paths_resolve(self):
        for h in HELPERS.values():
            for key in ['script','input']:self.assertTrue((ROOT/'vendor/reused-helpers'/h['owner']/h[key]).is_file())
    def test_external_actions_blocked(self):
        r,a=self.runner(self.one());s=r.run(a,external_actions=['send','spend','deploy']);self.assertEqual(s['terminal'],'not_ready_for_release');self.assertEqual(s['counters']['external_calls'],0)
    def test_mechanical_normalization_actual(self):
        r,a=self.runner(self.one('R01.W1'));s=r.run(a);self.assertTrue(s['task_chain_complete']);bundle=read_json(ROOT/r.artifacts['one']['files'][0]['path']);report=next(x for x in bundle['files'] if x['path'].endswith('/report.json'));self.assertEqual(read_json(ROOT/report['path'])['brief'],self.m['source']['facts']['BRIEF']['value'])
    def test_authority_stays_absent(self):
        r,a=self.runner(self.one('R26.W2'));s=r.run(a);self.assertTrue(s['task_chain_complete']);bundle=read_json(ROOT/r.artifacts['one']['files'][0]['path']);report=read_json(ROOT/next(x for x in bundle['files'] if x['path'].endswith('/report.json'))['path']);self.assertTrue(all(x['state']=='blocked' for x in report['decisions']))
    def test_exercise_path_traversal_refused(self):
        from run_exercises import exercises
        with self.assertRaises(ValueError):exercises('../not-a-pack-output')
    def test_validation_path_traversal_refused(self):
        from validate_pack import validate
        with self.assertRaises(ValueError):validate('../not-a-pack-output')
    def test_supplemental_profiles_explicit(self):
        rows={w['workflow_id']:w for w in read_json(ROOT/'WORKFLOWS.json')['workflows']}
        for wid in ['R12.W2','R24.W3','R25.W2']:
            self.assertEqual(rows[wid]['status'],'supplemental_fixture_execution_not_campaign_observations')
    def test_portable_stdout_keeps_raw_separate(self):
        from portable_receipts import path_stdout
        dest=self.path/'packet';raw=(str(dest)+'\n').encode();r=path_stdout(raw,dest,'packet','test-path')
        self.assertEqual(r['evidence_kind'],'DERIVED_PRESENTATION_NOT_RAW_STDOUT');self.assertEqual(r['presentation'],'packet');self.assertEqual(r['raw_original']['sha256'],hashlib.sha256(raw).hexdigest());self.assertNotIn(str(ROOT),json.dumps(r))
    def test_portable_stdout_verifies_exact_path(self):
        from portable_receipts import path_stdout
        with self.assertRaises(ValueError):path_stdout((str(self.path/'wrong')+'\n').encode(),self.path/'expected','packet','test-wrong-path')
    def test_portable_json_changes_only_path_field(self):
        from portable_receipts import path_stdout
        raw=jbytes({'output':str(self.path/'packet'),'counts':{'FAIL':1},'state':'produced'});r=path_stdout(raw,self.path/'packet','packet','test-json-path','output')
        self.assertEqual(r['presentation'],{'output':'packet','counts':{'FAIL':1},'state':'produced'})
    def test_portable_os_error_not_raw_trace(self):
        from portable_receipts import os_error
        error=FileNotFoundError(2,'No such file',str(self.path/'absent'));detail=os_error(error)
        self.assertIn('Portable diagnostic',detail);self.assertNotIn(str(ROOT),detail);self.assertIn('absent',detail)
    def test_diagnostic_is_not_wireflow_production(self):
        from unittest.mock import patch
        from deliverable_acceptance import accept
        with patch('deliverable_acceptance.read_json',return_value={'selected_function':'helper.navigation','files':[]}):
            with self.assertRaises(ValueError):accept('R17.W1','maplebench',{'path':'fake/run/job/bundle.json'},{'path':'unused'})
    def test_registry_is_not_refresh_queue(self):
        from unittest.mock import patch
        from deliverable_acceptance import accept
        with patch('deliverable_acceptance.read_json',return_value={'selected_function':'shared.registry','files':[]}):
            with self.assertRaises(ValueError):accept('R06.W4','maplebench',{'path':'fake/run/job/bundle.json'},{'path':'unused'})
    def test_contrast_is_not_markup_audit(self):
        from unittest.mock import patch
        from deliverable_acceptance import accept
        with patch('deliverable_acceptance.read_json',return_value={'selected_function':'helper.contrast','files':[]}):
            with self.assertRaises(ValueError):accept('R17.W2','maplebench',{'path':'fake/run/job/bundle.json'},{'path':'unused'})
    def test_all_promises_have_mapping_or_explicit_hold(self):
        from deliverable_acceptance import SELECTORS,promises
        for w in read_json(ROOT/'WORKFLOWS.json')['workflows']:
            profile,line,items=promises(w['workflow_id']);self.assertTrue(items)
            self.assertTrue(w['workflow_id'] in SELECTORS or w['execution']=='shared.authored' or not w['execution'])
    def test_live_authority_rejected(self):
        import mechanical
        r,a=self.runner(self.one('R26.W2'));packet=r.begin('one');packet['source']['facts']['BRIEF']['value']['external_actions_authorized']=True
        with self.assertRaises(ValueError):mechanical.execute('pack.authority',read_json(ROOT/'inputs/maplebench/authority.json'),packet,a)

if __name__=='__main__':unittest.main()
