import copy,csv,importlib.util,io,json,sys,unittest,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from composed import engine,read_json
from deliverables import wireflow,wireframes_svg,freshness,refresh_csv,audit_markup,markup_markdown

def load(name,path):
    s=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
CHECK=load('flowchecker','vendor/reused-helpers/design-experience-architecture/scripts/check_flow.py')
MEDIA=load('mediabuilder','vendor/media-web/build.py')
BRIEFS=read_json(ROOT/'inputs/scenario-seeds.json');CORPUS=read_json(ROOT/'inputs/source-corpus.json')

class DeliverableTests(unittest.TestCase):
    def brief(self):return BRIEFS['briefs'][0]
    def graph(self):return wireflow(self.brief(),{},'0'*64)
    def registry(self):
        b={'id':'brief','version':'1','kind':'brief','status':'current','observed_at':'2026-10-01T00:00:00Z','valid_through':'2027-01-01T00:00:00Z','payload':{'id':'maplebench'},'source_sha256':'a'*64}
        r={**b,'id':'evidence','kind':'evidence','payload':{'value':{'price':14900},'allowed_scopes':['declared']}}
        return {'schema':'registry/1','brief_id':'brief','brief_version':'1','as_of':'2026-10-25T00:00:00Z','current_versions':{'brief':'1','evidence':'1'},'records':[b,r]}
    def decision(self,reg):return freshness(reg,[],'maplebench',{'scope':'declared test cutoff'})['decisions'][1]
    def test_three_case_valid_graphs(self):
        for b in BRIEFS['briefs']:
            g=wireflow(b,{},'0'*64);self.assertEqual(CHECK.check(g),[]);self.assertEqual(g['cta'],b['cta']);self.assertEqual(g['objective'],b['objective']);self.assertEqual(g['case_id'],b['id'])
    def test_independent_success_and_cancel_reachable(self):
        g=self.graph();seen=set();todo=['landing']
        while todo:
            n=todo.pop()
            if n in seen:continue
            seen.add(n);todo.extend(t['to'] for t in g['transitions'] if t['from']==n)
        self.assertIn('complete',seen);self.assertIn('cancelled',seen);self.assertEqual(seen,{s['id'] for s in g['states']})
    def test_seed_dead_end(self):
        g=self.graph();g['transitions']=[t for t in g['transitions'] if t['from']!='form'];self.assertIn('dead-end form',CHECK.check(g))
    def test_seed_missing_recovery(self):
        g=self.graph();g['states'][3]['kind']='normal';self.assertIn('missing recovery error',CHECK.check(g))
    def test_seed_unknown_target(self):
        g=self.graph();g['transitions'][0]['to']='absent';self.assertIn('unknown transition target/source',CHECK.check(g))
    def test_editable_svg_states_edges(self):
        g=self.graph();s=ET.fromstring(wireframes_svg(g));ids={x.attrib.get('id') for x in s.iter()}
        self.assertTrue({'state-'+x['id'] for x in g['states']}<=ids);self.assertTrue({'edge-'+x['id'] for x in g['transitions']}<=ids);self.assertGreater(len(list(s.iter('{http://www.w3.org/2000/svg}text'))),30)
    def test_added_controls_explicitly_proposed(self):
        g=self.graph();self.assertIn('not implemented',g['states'][1]['implementation']);self.assertIn('not implemented',g['states'][-1]['implementation']);self.assertFalse(g['live_action_authorized'])
    def test_wrong_case_refused(self):
        c=read_json(ROOT/'roles-content/media-copy/maplebench.json')
        with self.assertRaises((ValueError,AssertionError)):MEDIA.validate_inputs(BRIEFS,CORPUS,c,'ledgernest')
    def test_wrong_cta_refused(self):
        b=copy.deepcopy(BRIEFS);b['briefs'][0]['cta']='Buy now';c=read_json(ROOT/'roles-content/media-copy/maplebench.json')
        with self.assertRaises((ValueError,AssertionError)):MEDIA.validate_inputs(b,CORPUS,c,'maplebench')
    def test_current_freshness(self):self.assertEqual(self.decision(self.registry())['freshness'],'current')
    def test_expired_freshness(self):
        r=self.registry();r['records'][1]['valid_through']='2026-10-24T23:59:59Z';d=self.decision(r);self.assertEqual(d['freshness'],'expired');self.assertIn('expired_validity',d['reasons'])
    def test_exact_boundary_inclusive(self):
        r=self.registry();r['records'][1]['valid_through']=r['as_of'];self.assertEqual(self.decision(r)['freshness'],'current');r['as_of']='2026-10-25T00:00:00.000001Z';self.assertEqual(self.decision(r)['freshness'],'expired')
    def test_future_observation(self):
        r=self.registry();r['records'][1]['observed_at']='2026-10-26T00:00:00Z';d=self.decision(r);self.assertEqual(d['freshness'],'unknown');self.assertIn('future_observation',d['reasons'])
    def test_missing_observation_and_validity(self):
        for field in ['observed_at','valid_through']:
            r=self.registry();r['records'][1][field]=None;self.assertEqual(self.decision(r)['freshness'],'unknown')
    def test_superseded_preserved(self):
        r=self.registry();v=copy.deepcopy(r['records'][1]);v['version']='2';r['records'].append(v);r['current_versions']['evidence']='2';self.assertEqual(self.decision(r)['freshness'],'superseded');self.assertEqual(len(freshness(r,[],'maplebench',{})['decisions']),3)
    def test_claim_dependency_and_real_queue(self):
        r=self.registry();e=r['records'][1];e['valid_through']='2026-10-24T00:00:00Z';claim={**r['records'][0],'id':'claim','kind':'claim','payload':{'assertion':e['payload']['value'],'scope':'declared','evidence_ref':{'id':e['id'],'version':'1','record_sha256':engine.object_hash(e)}}};r['records'].append(claim);r['current_versions']['claim']='1'
        report=freshness(r,[],'maplebench',{});q=report['refresh_queue'];self.assertEqual(q[0]['affected_claims'],['claim@1']);self.assertEqual(q[1]['freshness'],'historical');self.assertIn('linked_evidence_stale',q[1]['reasons']);rows=list(csv.DictReader(io.StringIO(refresh_csv(report))));self.assertEqual(len(rows),2);self.assertTrue(all(x['request_status']=='PROPOSED_NOT_SENT' for x in rows));self.assertEqual(report['network_requests'],0)
    def date_profile(self,case='maplebench'):
        data=read_json(ROOT/'inputs'/case/'freshness.json');reg=read_json(ROOT/data['registry_ref']['path']);return data,reg
    def test_date_labels_and_unknown_instants_survive(self):
        for b in BRIEFS['briefs']:
            data,reg=self.date_profile(b['id']);r=freshness(reg,data['source_refs'],b['id'],data['policy']);rows=[x for x in r['decisions'] if x['source_time_precision']=='date_only'];self.assertEqual(len(rows),4)
            expected={(x['source_id'],x['version']):x for x in data['policy']['source_time_bindings']}
            for row in rows:
                self.assertEqual(row['source_observation_date_label'],expected[(row['source_id'],row['version'])]['source_observation_date_label']);self.assertIsNone(row['source_observed_instant']);self.assertIsNone(row['observed_at']);self.assertIsNone(row['source_valid_through_instant']);self.assertIsNone(row['valid_through']);self.assertEqual(row['calculation_observed_at'],row['source_observation_date_label']+'T00:00:00Z')
    def test_cutoff_not_local_campaign_midnight(self):
        data,reg=self.date_profile();r=freshness(reg,[],'maplebench',data['policy']);self.assertFalse(r['cutoff_is_actual_campaign_start']);self.assertIsNone(r['source_campaign_start_instant']);self.assertIn('DATE LABEL',r['cutoff_source']);self.assertIn('not the actual America/Chicago',r['cutoff_source']);self.assertEqual(data['policy']['source_campaign_timezone'],'America/Chicago')
    def test_date_precision_and_normalization_in_queue_csv(self):
        data,reg=self.date_profile();r=freshness(reg,[],'maplebench',data['policy']);rows=list(csv.DictReader(io.StringIO(refresh_csv(r))));dated=[x for x in rows if x['source_time_precision']=='date_only'];self.assertEqual(len(dated),2)
        for row in dated:self.assertEqual(row['source_observation_date_label'],'2026-10-01');self.assertEqual(row['source_observed_instant'],'');self.assertEqual(row['source_valid_through_instant'],'');self.assertEqual(row['cutoff_is_actual_campaign_start'],'False');self.assertIn('not source-observed time',row['time_normalization']);self.assertIn('DATE LABEL',row['cutoff_meaning'])
    def test_date_only_cannot_claim_observed_instant(self):
        data,reg=self.date_profile();data['policy']['source_time_bindings'][0]['source_observed_instant']='2026-10-01T00:00:00Z'
        with self.assertRaises(ValueError):freshness(reg,[],'maplebench',data['policy'])
    def test_date_label_cutoff_claim_refused(self):
        data,reg=self.date_profile();data['policy']['cutoff_is_actual_campaign_start']=True
        with self.assertRaises(ValueError):freshness(reg,[],'maplebench',data['policy'])
    def test_normalized_cutoff_drift_refused(self):
        data,reg=self.date_profile();reg['as_of']='2027-02-01T06:00:00Z'
        with self.assertRaises(ValueError):freshness(reg,[],'maplebench',data['policy'])
    def test_freshness_wrong_case_refused(self):
        with self.assertRaises(ValueError):freshness(self.registry(),[],'ledgernest',{})
    def test_three_actual_html_sources(self):
        for b in BRIEFS['briefs']:
            raw=(ROOT/'vendor/media-web/examples'/b['id']/'index.html').read_bytes();r=audit_markup(raw,b['id'],'index.html');self.assertEqual(r['static_failures'],0);self.assertGreaterEqual(len(r['controls']),10);self.assertTrue(any(x['code']=='empty_dynamic_description' for x in r['findings']));self.assertIn('UNRESOLVED',r['result']);self.assertFalse(r['browser_tested']);self.assertIn(r['source']['sha256'],markup_markdown(r))
    def test_seed_missing_label(self):
        r=audit_markup(b'<input id="email" placeholder="Email">','test','index.html');self.assertTrue(any(x['code']=='missing_label' for x in r['findings']));self.assertEqual(r['result'],'FAIL')
    def test_seed_broken_description(self):
        r=audit_markup(b'<label for="x">Email</label><input id="x" aria-describedby="missing">','test','index.html');self.assertTrue(any(x['code']=='broken_aria-describedby' for x in r['findings']))
    def test_seed_empty_control_name(self):
        r=audit_markup(b'<button></button>','test','index.html');self.assertTrue(any(x['code']=='empty_control_name' for x in r['findings']))
    def test_seed_duplicate_id(self):
        r=audit_markup(b'<p id="x">A</p><p id="x">B</p>','test','index.html');self.assertEqual(r['static_failures'],2)
    def test_explicit_name_role_and_error_links(self):
        raw=b'<label for="x">Email</label><input id="x" aria-describedby="e" aria-errormessage="e"><p id="e">Invalid email</p><button aria-label="Continue"></button>'
        r=audit_markup(raw,'test','index.html');self.assertEqual(r['static_failures'],0);self.assertEqual(r['controls'][0]['name_candidate'],'Email');self.assertEqual(r['controls'][1]['name_candidate'],'Continue');self.assertEqual(len(r['controls'][0]['relationships']),2)

if __name__=='__main__':unittest.main()
