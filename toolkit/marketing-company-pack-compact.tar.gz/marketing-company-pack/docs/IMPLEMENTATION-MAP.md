# Portable implementation map

The registry below maps each role procedure to a real bounded callable or an explicit hold. Supplemental fixture execution is not new business observation. Exact outcomes and produced files are in WORKFLOW-RESULTS.json.

## R01.W1 Normalize campaign brief

Role instructions: ../roles-content/roles/01-marketing-lead/AGENT.md

Status: bounded_local_implementation.

Callable: pack.brief.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R01.W2 Build dependency and decision plan

Role instructions: ../roles-content/roles/01-marketing-lead/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.dependency.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R01.W3 Reconcile declared channel cap

Role instructions: ../roles-content/roles/01-marketing-lead/AGENT.md

Status: bounded_local_implementation.

Callable: shared.allocation.

Limit: Reconciles declared total only; never an allocation recommendation or platform hard cap.

## R01.W4 Replan after a rejected artifact

Role instructions: ../roles-content/roles/01-marketing-lead/AGENT.md

Status: integration_regression_workflow.

Callable: None.

Limit: Executed by the separate composed integration harness, not recursively inside its own dispatch. See tests/test_pack.py and VALIDATION.json.

## R02.W1 Build buyer alternatives map

Role instructions: ../roles-content/roles/02-brand-growth-strategist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R02.W2 Develop distinct positioning options

Role instructions: ../roles-content/roles/02-brand-growth-strategist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R02.W3 Produce message hierarchy and hypotheses

Role instructions: ../roles-content/roles/02-brand-growth-strategist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R02.W4 Connect strategy to outcome metrics

Role instructions: ../roles-content/roles/02-brand-growth-strategist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R03.W1 Code exact research evidence

Role instructions: ../roles-content/roles/03-market-researcher/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R03.W2 Count themes with explicit denominators

Role instructions: ../roles-content/roles/03-market-researcher/AGENT.md

Status: bounded_local_implementation.

Callable: business.themes.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R03.W3 Reconcile analyst disagreements

Role instructions: ../roles-content/roles/03-market-researcher/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.coding.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R03.W4 Design a neutral follow-up study

Role instructions: ../roles-content/roles/03-market-researcher/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R04.W1 Resolve account identity and source coverage

Role instructions: ../roles-content/roles/04-account-researcher/AGENT.md

Status: bounded_local_implementation.

Callable: business.accounts.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R04.W2 Apply declared ICP and exclusions

Role instructions: ../roles-content/roles/04-account-researcher/AGENT.md

Status: bounded_local_implementation.

Callable: business.accounts.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R04.W3 Rank supported professional contacts

Role instructions: ../roles-content/roles/04-account-researcher/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.contacts.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R04.W4 Write sourced account brief

Role instructions: ../roles-content/roles/04-account-researcher/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R05.W1 Normalize dated competitor offers

Role instructions: ../roles-content/roles/05-competitive-analyst/AGENT.md

Status: bounded_local_implementation.

Callable: business.competitors.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R05.W2 Compare baseline to observed snapshot

Role instructions: ../roles-content/roles/05-competitive-analyst/AGENT.md

Status: bounded_local_implementation.

Callable: business.competitors.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R05.W3 Build supported differentiation ledger

Role instructions: ../roles-content/roles/05-competitive-analyst/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R05.W4 Prepare competitive discovery handoff

Role instructions: ../roles-content/roles/05-competitive-analyst/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R06.W1 Register exact source versions

Role instructions: ../roles-content/roles/06-evidence-librarian/AGENT.md

Status: bounded_local_implementation.

Callable: shared.registry.

Limit: Exact structured source/version/claim/asset checks only; no free-text entailment, authenticity or legal rights proof.

## R06.W2 Extract claim-specific evidence

Role instructions: ../roles-content/roles/06-evidence-librarian/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R06.W3 Check citations and dependencies

Role instructions: ../roles-content/roles/06-evidence-librarian/AGENT.md

Status: bounded_local_implementation.

Callable: shared.registry.

Limit: Exact structured source/version/claim/asset checks only; no free-text entailment, authenticity or legal rights proof.

## R06.W4 Maintain expiration and reuse scope

Role instructions: ../roles-content/roles/06-evidence-librarian/AGENT.md

Status: bounded_local_implementation.

Callable: shared.registry.

Limit: Exact structured source/version/claim/asset checks only; no free-text entailment, authenticity or legal rights proof.

## R07.W1 Create distinct creative territories

Role instructions: ../roles-content/roles/07-creative-director/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R07.W2 Specify coherent visual system

Role instructions: ../roles-content/roles/07-creative-director/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R07.W3 Produce timed storyboard and production brief

Role instructions: ../roles-content/roles/07-creative-director/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R07.W4 Audit asset and variant readiness

Role instructions: ../roles-content/roles/07-creative-director/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R08.W1 Write complete landing-page copy

Role instructions: ../roles-content/roles/08-copywriter/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R08.W2 Write placement-bounded ad variants

Role instructions: ../roles-content/roles/08-copywriter/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R08.W3 Draft reviewed lifecycle messages

Role instructions: ../roles-content/roles/08-copywriter/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R08.W4 Repair factual and voice drift

Role instructions: ../roles-content/roles/08-copywriter/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R09.W1 Author editable campaign vector

Role instructions: ../roles-content/roles/09-graphic-designer/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R09.W2 Recompose placement variants

Role instructions: ../roles-content/roles/09-graphic-designer/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R09.W3 Produce an editable sales sheet

Role instructions: ../roles-content/roles/09-graphic-designer/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R09.W4 Preflight supplied print/export specification

Role instructions: ../roles-content/roles/09-graphic-designer/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R10.W1 Assemble traceable edit decision list

Role instructions: ../roles-content/roles/10-motion-video-editor/AGENT.md

Status: bounded_local_implementation.

Callable: media.video.

Limit: Original six-second silent procedural video and supplied text captions only; no ASR, listening, full motion perception or native timeline proof.

## R10.W2 Render and cut original silent clips

Role instructions: ../roles-content/roles/10-motion-video-editor/AGENT.md

Status: bounded_local_implementation.

Callable: media.video.

Limit: Original six-second silent procedural video and supplied text captions only; no ASR, listening, full motion perception or native timeline proof.

## R10.W3 Produce and align supplied-text captions

Role instructions: ../roles-content/roles/10-motion-video-editor/AGENT.md

Status: bounded_local_implementation.

Callable: media.video.

Limit: Original six-second silent procedural video and supplied text captions only; no ASR, listening, full motion perception or native timeline proof.

## R10.W4 Inspect media and expose quality holds

Role instructions: ../roles-content/roles/10-motion-video-editor/AGENT.md

Status: bounded_local_implementation.

Callable: media.video.

Limit: Original six-second silent procedural video and supplied text captions only; no ASR, listening, full motion perception or native timeline proof.

## R11.W1 Resolve dimensional evidence contract

Role instructions: ../roles-content/roles/11-3d-technical-illustrator/AGENT.md

Status: bounded_local_implementation.

Callable: media.technical.

Limit: Separate fictional training block only. LoopStand axis assignment, native product geometry and native rendering remain held. Not manufacturing evidence.

## R11.W2 Draw source-bound technical views

Role instructions: ../roles-content/roles/11-3d-technical-illustrator/AGENT.md

Status: bounded_local_implementation.

Callable: media.technical.

Limit: Separate fictional training block only. LoopStand axis assignment, native product geometry and native rendering remain held. Not manufacturing evidence.

## R11.W3 Prepare native geometry workflow

Role instructions: ../roles-content/roles/11-3d-technical-illustrator/AGENT.md

Status: blocked_native_runtime.

Callable: None.

Limit: Qualified native Blender execution and product geometry evidence unavailable. No successful substitute claimed.

## R11.W4 Stage and render native product scene

Role instructions: ../roles-content/roles/11-3d-technical-illustrator/AGENT.md

Status: blocked_native_runtime.

Callable: None.

Limit: Qualified native Blender execution and product geometry evidence unavailable. No successful substitute claimed.

## R12.W1 Map query intent to actual pages

Role instructions: ../roles-content/roles/12-seo-strategist/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: business.search.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R12.W2 Calculate supported search opportunities

Role instructions: ../roles-content/roles/12-seo-strategist/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: business.search.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R12.W3 Write evidence-ready content briefs

Role instructions: ../roles-content/roles/12-seo-strategist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R12.W4 Run local discoverability checks

Role instructions: ../roles-content/roles/12-seo-strategist/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: business.search.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R13.W1 Edit for meaning and channel fit

Role instructions: ../roles-content/roles/13-content-editor/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R13.W2 Refresh stale source-grounded content

Role instructions: ../roles-content/roles/13-content-editor/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R13.W3 Review claims and quotation fidelity

Role instructions: ../roles-content/roles/13-content-editor/AGENT.md

Status: bounded_local_implementation.

Callable: editorial.check.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R13.W4 Maintain version and handoff integrity

Role instructions: ../roles-content/roles/13-content-editor/AGENT.md

Status: bounded_local_implementation.

Callable: pack.route.

Limit: Actual received artifact index and authority-held operational handoff, not live CRM transport or a general workflow host.

## R14.W1 Build channel-specific editorial calendar

Role instructions: ../roles-content/roles/14-social-media-manager/AGENT.md

Status: bounded_local_implementation.

Callable: business.calendar.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R14.W2 Repurpose with native-channel context

Role instructions: ../roles-content/roles/14-social-media-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R14.W3 Draft and triage community responses

Role instructions: ../roles-content/roles/14-social-media-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R14.W4 Measure organic content cohorts

Role instructions: ../roles-content/roles/14-social-media-manager/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.organic.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R15.W1 Select supported news angle

Role instructions: ../roles-content/roles/15-pr-communications/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R15.W2 Draft release and press FAQ

Role instructions: ../roles-content/roles/15-pr-communications/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R15.W3 Build beat-based media research list

Role instructions: ../roles-content/roles/15-pr-communications/AGENT.md

Status: bounded_local_implementation.

Callable: business.media.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R15.W4 Prepare correction or holding statement

Role instructions: ../roles-content/roles/15-pr-communications/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R16.W1 Build complete static campaign page

Role instructions: ../roles-content/roles/16-web-developer/AGENT.md

Status: bounded_local_implementation.

Callable: media.web.

Limit: Actual static source and local-only form; real browser responsiveness, keyboard, AT, provider and deployment proofs remain held.

## R16.W2 Implement clearly local form demo

Role instructions: ../roles-content/roles/16-web-developer/AGENT.md

Status: bounded_local_implementation.

Callable: media.web.

Limit: Actual static source and local-only form; real browser responsiveness, keyboard, AT, provider and deployment proofs remain held.

## R16.W3 Implement metadata and safe handoffs

Role instructions: ../roles-content/roles/16-web-developer/AGENT.md

Status: bounded_local_implementation.

Callable: media.web.

Limit: Actual static source and local-only form; real browser responsiveness, keyboard, AT, provider and deployment proofs remain held.

## R16.W4 Verify source/build and declare browser gaps

Role instructions: ../roles-content/roles/16-web-developer/AGENT.md

Status: bounded_local_implementation.

Callable: media.web.

Limit: Actual static source and local-only form; real browser responsiveness, keyboard, AT, provider and deployment proofs remain held.

## R17.W1 Model the full conversion wireflow

Role instructions: ../roles-content/roles/17-cro-ux-specialist/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.navigation.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R17.W2 Check declared contrast and semantic risks

Role instructions: ../roles-content/roles/17-cro-ux-specialist/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.contrast.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R17.W3 Prioritize CRO hypotheses

Role instructions: ../roles-content/roles/17-cro-ux-specialist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R17.W4 Author task-based acceptance criteria

Role instructions: ../roles-content/roles/17-cro-ux-specialist/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R18.W1 Design bounded search architecture

Role instructions: ../roles-content/roles/18-paid-search-manager/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.paid-search.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R18.W2 Build intent-keyword and copy review pack

Role instructions: ../roles-content/roles/18-paid-search-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R18.W3 Validate shared plan against cap

Role instructions: ../roles-content/roles/18-paid-search-manager/AGENT.md

Status: bounded_local_implementation.

Callable: shared.allocation.

Limit: Reconciles declared total only; never an allocation recommendation or platform hard cap.

## R18.W4 Diagnose search export performance

Role instructions: ../roles-content/roles/18-paid-search-manager/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.paid-reconciliation.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R19.W1 Specify bounded audience and exclusions

Role instructions: ../roles-content/roles/19-paid-social-manager/AGENT.md

Status: bounded_local_implementation.

Callable: business.paid_social.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R19.W2 Build paid-social creative matrix

Role instructions: ../roles-content/roles/19-paid-social-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R19.W3 Reconcile cross-channel media plan

Role instructions: ../roles-content/roles/19-paid-social-manager/AGENT.md

Status: bounded_local_implementation.

Callable: shared.allocation.

Limit: Reconciles declared total only; never an allocation recommendation or platform hard cap.

## R19.W4 Diagnose creative performance slices

Role instructions: ../roles-content/roles/19-paid-social-manager/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.paid-reconciliation.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R20.W1 Replay lifecycle eligibility

Role instructions: ../roles-content/roles/20-email-lifecycle-marketer/AGENT.md

Status: bounded_local_implementation.

Callable: lead.plan.

Limit: Explicit synthetic demo/workshop trigger composition over unchanged lifecycle engine; intent is not send authority.

## R20.W2 Author stage-specific grounded messages

Role instructions: ../roles-content/roles/20-email-lifecycle-marketer/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R20.W3 Produce editable HTML and text email

Role instructions: ../roles-content/roles/20-email-lifecycle-marketer/AGENT.md

Status: bounded_local_implementation.

Callable: email.build.

Limit: Three source-grounded HTML/text stages; no email-client rendering, deliverability or sending.

## R20.W4 Reconcile revocation and replay state

Role instructions: ../roles-content/roles/20-email-lifecycle-marketer/AGENT.md

Status: bounded_local_implementation.

Callable: lead.plan.

Limit: Explicit synthetic demo/workshop trigger composition over unchanged lifecycle engine; intent is not send authority.

## R21.W1 Define portable workflow contracts

Role instructions: ../roles-content/roles/21-marketing-ops-automation/AGENT.md

Status: bounded_local_implementation.

Callable: pack.registry.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R21.W2 Route actual produced artifacts

Role instructions: ../roles-content/roles/21-marketing-ops-automation/AGENT.md

Status: bounded_local_implementation.

Callable: pack.route.

Limit: Actual received artifact index and authority-held operational handoff, not live CRM transport or a general workflow host.

## R21.W3 Validate demo-request event lineage

Role instructions: ../roles-content/roles/21-marketing-ops-automation/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: shared.demo.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R21.W4 Prepare provider-neutral operational handoff

Role instructions: ../roles-content/roles/21-marketing-ops-automation/AGENT.md

Status: bounded_local_implementation.

Callable: pack.route.

Limit: Actual received artifact index and authority-held operational handoff, not live CRM transport or a general workflow host.

## R22.W1 Score declared partner fit

Role instructions: ../roles-content/roles/22-partner-marketing-manager/AGENT.md

Status: bounded_local_implementation.

Callable: business.partners.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R22.W2 Map evidenced introduction routes

Role instructions: ../roles-content/roles/22-partner-marketing-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R22.W3 Draft co-marketing offer and ask

Role instructions: ../roles-content/roles/22-partner-marketing-manager/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R22.W4 Plan joint deliverables and approvals

Role instructions: ../roles-content/roles/22-partner-marketing-manager/AGENT.md

Status: bounded_local_implementation.

Callable: business.joint_plan.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R23.W1 Produce buyer-specific battlecard

Role instructions: ../roles-content/roles/23-sales-enablement/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R23.W2 Prepare approved-scope proof bank

Role instructions: ../roles-content/roles/23-sales-enablement/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R23.W3 Build technical FAQ and objection responses

Role instructions: ../roles-content/roles/23-sales-enablement/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R23.W4 Produce usable seller one-pager

Role instructions: ../roles-content/roles/23-sales-enablement/AGENT.md

Status: bounded_local_implementation.

Callable: media.graphics.

Limit: Closed three-brief original SVG/PDF/static family. Printer specification is absent, so print readiness is held. Browser and native-editor proofs are absent.

## R24.W1 Reconcile paid-media exports

Role instructions: ../roles-content/roles/24-marketing-analyst/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.paid-reconciliation.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R24.W2 Report organic accepted cohorts

Role instructions: ../roles-content/roles/24-marketing-analyst/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.organic.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R24.W3 Report objective-specific funnel

Role instructions: ../roles-content/roles/24-marketing-analyst/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: shared.demo.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R24.W4 Produce decision-ready metrics report

Role instructions: ../roles-content/roles/24-marketing-analyst/AGENT.md

Status: bounded_local_implementation.

Callable: business.decision.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R25.W1 Freeze a causal experiment protocol

Role instructions: ../roles-content/roles/25-experiment-analyst/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R25.W2 Calculate supported design feasibility

Role instructions: ../roles-content/roles/25-experiment-analyst/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.causal-plan.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R25.W3 Audit and read out bounded experiment

Role instructions: ../roles-content/roles/25-experiment-analyst/AGENT.md

Status: supplemental_fixture_execution_not_campaign_observations.

Callable: helper.causal-readout.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R25.W4 Reconcile learning and decision limits

Role instructions: ../roles-content/roles/25-experiment-analyst/AGENT.md

Status: bounded_local_implementation.

Callable: business.decision.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R26.W1 Audit factual and comparative claims

Role instructions: ../roles-content/roles/26-compliance-reviewer/AGENT.md

Status: authored_draft_semantic_review_required.

Callable: shared.authored.

Limit: Actual substantial authored draft packaged unchanged; independent semantic review and a model host for new briefs are required.

## R26.W2 Review consent and authority separately

Role instructions: ../roles-content/roles/26-compliance-reviewer/AGENT.md

Status: bounded_local_implementation.

Callable: pack.authority.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R26.W3 Review asset rights and disclosure scope

Role instructions: ../roles-content/roles/26-compliance-reviewer/AGENT.md

Status: bounded_local_implementation.

Callable: pack.rights.

Limit: Supplied finite fictional data only; semantic interpretation, source authenticity and release permissions are not established.

## R26.W4 Return exact corrections to owners

Role instructions: ../roles-content/roles/26-compliance-reviewer/AGENT.md

Status: integration_regression_workflow.

Callable: None.

Limit: Executed by the separate composed integration harness, not recursively inside its own dispatch. See tests/test_pack.py and VALIDATION.json.

## R27.W1 Audit every role and workflow output

Role instructions: ../roles-content/roles/27-qa-auditor/AGENT.md

Status: bounded_local_implementation.

Callable: pack.audit.

Limit: 108-entry coverage and real prerequisite-file verification only; semantic review, independent whole-pack review and final ZIP inspection are separate.

## R27.W2 Resimulate three independently seeded campaigns

Role instructions: ../roles-content/roles/27-qa-auditor/AGENT.md

Status: integration_regression_workflow.

Callable: None.

Limit: Executed by the separate composed integration harness, not recursively inside its own dispatch. See tests/test_pack.py and VALIDATION.json.

## R27.W3 Run adversarial regressions and repairs

Role instructions: ../roles-content/roles/27-qa-auditor/AGENT.md

Status: integration_regression_workflow.

Callable: None.

Limit: Executed by the separate composed integration harness, not recursively inside its own dispatch. See tests/test_pack.py and VALIDATION.json.

## R27.W4 Verify final ZIP by extraction and replay

Role instructions: ../roles-content/roles/27-qa-auditor/AGENT.md

Status: pending_final_export_review.

Callable: None.

Limit: Final ZIP extraction, independent review and export clearance belong to final package release, not this builder.
