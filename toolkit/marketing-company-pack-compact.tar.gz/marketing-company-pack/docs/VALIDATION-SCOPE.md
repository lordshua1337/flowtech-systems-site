# Validation scope

Three independent source notes each traversed all27fixed roles and returned27accepted, newly produced artifact bundles. All selected runs retain concurrency1 and the unchanged64dispatch limit. The wider108workflow registry has101bounded callables,4outer integration/regression workflows,2native-runtime holds and1final-export gate. This is not108fully live-ready skills.

The new runs and additional selected workflow checks are in WORKFLOW-RESULTS.json. Seventy integration and producer tests passed. Actual media generation, HTML/text email building, business calculations, supplemental existing helper execution, exact editorial annotation checking and authored-document packaging are separately identified in execution receipts. Successful local execution does not imply semantic truth or authority.

The repair exercise rejected an exact unsupported population claim from a real produced draft, returned its current artifact to the original Copywriter, invalidated2descendants, retained the unrelated budget and completed after one bounded rework. That reviewer is an explicit finite rule, not general semantic intelligence. Missing input recovery used the same restored hash and one retry. An over-cap150001proposal was refused.

Earlier component and integration failures are not presented as successes. The final candidate uses corrected source and fresh output directories. Component historical test evidence remains scoped to its original fixture; it is not reclassified as independent whole-pack review. Final semantic review and ZIP extraction are separate release gates.

Version2 adds exact workspace-unit arithmetic gates and separately preserved raw evidence with narrow labeled portable presentations. The final receipts and source pins, not the predecessor verdict, define this successor.

Version3 adds actual proposed wireflow/editable SVG, source-markup audit and claim-linked refresh-queue producers, plus explicit promise-to-file/type/content acceptance. Three native/final-export workflows remain explicitly unmet holds; successful diagnostics do not satisfy missing production.

Version4 preserves date-only source precision and unknown real observation/campaign-start instants. UTC midnight and the 30-day interval are explicitly proposed synthetic calculation conventions, not actual Chicago midnight or real intraday expiry. Existing explicit timestamp fixtures retain their bounded exact-instant tests.
