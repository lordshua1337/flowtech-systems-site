# Version4 date-only time attribution repair

The prior freshness adapter deterministically constructed UTC-midnight instants from source YYYY-MM-DD values, but its policy wording incorrectly described the cutoff as the campaign start without explaining the America/Chicago distinction. No canonical current/expired/superseded classifications changed. The source-time attribution and exact-boundary interpretation needed repair.

Version4 retains original date labels and source locators, labels UTC midnight and 30-day expiration as proposed synthetic calculation conventions, and leaves actual comparator observation/expiry and campaign-start instants null. Decisions and refresh CSV/JSON rows expose the precision, assumptions and limits directly. A date-only label cannot establish real intraday precision. Explicit timestamp fixtures remain a distinct declared-instant test profile.

No timezone/calendar parser or source observation was added. No source authenticity or network refresh is inferred. The three producer repairs and prior numeric/export repairs remain. Frozen version3, all earlier failures and component originals remain preserved separately.
