# Version2 repairs

This is a separate successor to the frozen version1 candidate, whose manifest SHA-256 is 546afd28b62ef6404df8c481e5e6406464e2db633d2b39f641320131acb0f728. The predecessor and its authentic original receipts remain unchanged outside this successor. A prior successful run of the three canonical examples did not reveal the nearby unsupported-unit defect; that defect and the export hold are not erased or reclassified as passes.

## Price-unit semantics

The changed business component source digest is ebb0bff161f265957347b4e4b3903e3dcc40514ea72c3b73e04b805353f57392. The prior digest was b8e4bd87fb2bd6d5340fef806f3e7d2bbaae704dbd5c94f524a727f9b93adc0e. Actual changed source: vendor/business-workflows/competitors.py. The new contract and tests are shipped alongside it.

- An own annual, per-user or unknown unit no longer produces twelve monthly payments or a monthly-versus-annual difference.
- Observed per-user or unknown prices no longer become five-seat workspace totals.
- A declared annual workspace bundle with five included seats remains a valid annual five-seat amount, with its original unit and currency retained.
- Unknown additional-seat prices and unsupported additional-seat billing periods stay null.
- The supported monthly workspace control remains 58,800 versus 48,000 minor units, nominal difference 10,800, with different payment/commitment terms explicitly retained.
- Cross-currency, cross-unit and equal-but-unknown unit comparisons remain held rather than silently converted.

The independent pre-repair expectations are in contracts/repair-oracles/. All twelve supplied neighbor expectations and additional null/unit/currency controls are covered by the affected component suite. This is bounded arithmetic correctness, not authentication of market facts or a recommendation to buy a plan.

## Portable evidence, not rewritten raw history

Causal-study tools receive actual pack-relative arguments. Their generated receipts are retained as those tools emitted them. For the four path-emitting stdout classes, a presentation receipt replaces only the exact verified output-directory field and is explicitly labeled DERIVED_PRESENTATION_NOT_RAW_STDOUT. Original byte count, SHA-256 and raw receipt identity remain recorded. Authentic raw stdout is stored outside the export root, not rewritten and called raw.

New filesystem failures produce a labeled portable diagnostic while separately preserving the authentic exception record. Genuine failed outcomes stay failed. Two unnecessary historical raw shared-runtime traces are excluded from this export selection with their original hashes retained in vendor/shared-runtime/PORTABLE-SELECTION.json. Its UPSTREAM-FINAL-SHA256SUMS describes the complete original component; the enclosing pack manifest describes current shipped bytes.

The media component was not changed for a retracted presentation concern. Native geometry, real-browser behavior, live integrations and release authority remain held. Fresh successor tests and review receipts, not the predecessor's status, determine this version's acceptance scope.
