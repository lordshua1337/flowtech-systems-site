# Version3 local producer repairs

Version2 had three missing substantive outputs despite successful captured invocations: R17.W1 used a mismatched synthetic navigation fixture and produced neither promised design file; R06.W4 only returned generic registry states; R17.W2 only returned declared contrast. Version2 and its genuine receipts remain preserved separately.

Version3 adds source-bound proposed wireflow/SVG production, declared-cutoff evidence refresh decisions/queue, and actual source-markup audit. Original shared runtime, graph checker, contrast helper, media, numerical and email implementations are unchanged from version2. Role operating guidance and three bindings are explicitly versioned successors; authored drafts remain unchanged. Numeric billing-unit and portable-receipt repairs remain intact.

Focused tests cover valid flows, dead ends, missing recovery, unknown destinations, wrong case/CTA, freshness current/expired/future/missing/superseded/exact-boundary states and claim impacts, plus missing labels, empty names, duplicate IDs and broken description references. Actual diagram proofs were inspected. The complete final resimulation is separately linked in WORKFLOW-RESULTS.json.

Deliverable acceptance is now explicit per output promise. Equivalent representations identify actual fields/types, not just file existence or an invocation counter. Structured content checks still require independent semantic review. Native geometry/rendering, real browser/keyboard/AT, live actions and final ZIP approval remain held as before.
