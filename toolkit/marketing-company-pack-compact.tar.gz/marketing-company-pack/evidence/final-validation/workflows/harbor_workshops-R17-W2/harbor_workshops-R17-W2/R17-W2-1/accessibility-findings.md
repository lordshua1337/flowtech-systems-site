# Static accessibility findings
Case: harbor_workshops
Source: current-html/index.html
SHA-256: 9c8d8f6a69308a03c255ff06d48a2e748de71870bf0144cb53c15e03e03efbab
Result: STATIC_CHECKS_PASS_WITH_RUNTIME_UNRESOLVED

This is source inspection, not browser, keyboard, assistive-technology or whole-WCAG certification.

## Controls and relationships
- Line 3, column 7, node 11: link; name candidate 'Skip to content' via text_content; relationships []
- Line 3, column 141, node 14: link; name candidate 'Harbor Lantern Workshops' via text_content; relationships []
- Line 3, column 222, node 16: link; name candidate 'Facts' via text_content; relationships []
- Line 3, column 248, node 17: link; name candidate 'Questions' via text_content; relationships []
- Line 3, column 282, node 18: link; name candidate 'Ask about a workshop place' via text_content; relationships []
- Line 4, column 290, node 25: link; name candidate 'Ask about a workshop place' via text_content; relationships []
- Line 5, column 983, node 47: button; name candidate 'Can I fit it around shop opening hours?' via text_content; relationships []
- Line 5, column 1242, node 50: button; name candidate 'What does the price include?' via text_content; relationships []
- Line 5, column 1407, node 53: button; name candidate 'What happens here?' via text_content; relationships []
- Line 7, column 77, node 62: textbox; name candidate 'Example email' via label; relationships [{"attribute": "aria-describedby", "target_id": "email-error", "state": "STATIC_REFERENCE_EXISTS", "target_locator": {"source": "current-html/index.html", "line": 7, "column": 208, "node_index": 63, "tag": "p", "id": "email-error"}, "current_text": ""}]
- Line 7, column 307, node 65: textbox; name candidate 'What would you like to evaluate?' via label; relationships [{"attribute": "aria-describedby", "target_id": "context-error", "state": "STATIC_REFERENCE_EXISTS", "target_locator": {"source": "current-html/index.html", "line": 7, "column": 399, "node_index": 66, "tag": "p", "id": "context-error"}, "current_text": ""}]
- Line 7, column 458, node 68: checkbox; name candidate 'I understand this is a local-only demo, not a real request.' via label; relationships [{"attribute": "aria-describedby", "target_id": "consent-error", "state": "STATIC_REFERENCE_EXISTS", "target_locator": {"source": "current-html/index.html", "line": 7, "column": 621, "node_index": 70, "tag": "p", "id": "consent-error"}, "current_text": ""}]
- Line 7, column 661, node 71: button; name candidate 'Preview the local demo state' via text_content; relationships []
- Line 7, column 720, node 72: button; name candidate 'Clear demo' via text_content; relationships []

## Findings
- UNRESOLVED empty_dynamic_description at line 7, column 77: Target email-error exists but is initially empty. Runtime error population and announcement are unverified.
- UNRESOLVED empty_dynamic_description at line 7, column 307: Target context-error exists but is initially empty. Runtime error population and announcement are unverified.
- UNRESOLVED empty_dynamic_description at line 7, column 458: Target consent-error exists but is initially empty. Runtime error population and announcement are unverified.

## Runtime unresolved
- Keyboard/focus order
- Actual validation and error announcement
- Screen-reader accessible names
- CSS visibility and visual contrast in the rendered page
- Responsive behavior
