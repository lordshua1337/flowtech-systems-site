# Professional-contact research brief

Dataset kind: fictional (unverified caller label). Cutoff: 2026-10-18T12:00:00Z.

Only supplied professional business records are assessed. Buying intent and purchasing authority are unknown.

## Scope

Offering: "Harbor Studio fixed\-scope online\-ordering cleanup for independent bakeries"

Territory: "Fictional Harbor District"

Purpose: "Prepare a source\-bound business\-contact research shortlist for manual review"

Freshness: effective evidence age <= 2,592,000 elapsed seconds, inclusive. Review/capture timestamps do not refresh an old fact.

Reconciliation: 16 original rows; 15 canonical contacts; 1 explicit aliases.
Disposition totals: excluded=3, held=6, not_relevant=2, research_review_candidate=4

## Ranked research priorities

### 1. p01 at A

Display names from original rows r01, r02: "Alex Sample"

Upstream account score 90; tier A. decision-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Professional role marketing; separate relevance 3. p01-role / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Source-supported professional destination "p01@a\.example". p01-destination / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; support-p01-destination / support-p01-destination / effective 2026-10-18T11:05:00Z / age 3300s / reviewed 2026-10-18T11:30:00Z

Employer support: p01-employer / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Ownership support: owner-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p01-owner / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Explicit negative clearances: p01-prior / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p01-suppression / contact-p01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Next research question: Is this person the appropriate professional contact for the stated offering? Purchasing authority and buying intent have not been established.

### 2. p04 at B

Display names from original rows r04: "Morgan Baker"

Upstream account score 90; tier A. decision-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Professional role owner; separate relevance 3. p04-role / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Source-supported professional destination "p04@b\.example". p04-destination / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; support-p04-destination / support-p04-destination / effective 2026-10-18T11:05:00Z / age 3300s / reviewed 2026-10-18T11:30:00Z

Employer support: p04-employer / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Ownership support: owner-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p04-owner / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Explicit negative clearances: p04-prior / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p04-suppression / contact-p04 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Next research question: Is this person the appropriate professional contact for the stated offering? Purchasing authority and buying intent have not been established.

### 3. p16 at H

Display names from original rows r16: "Harper Loaf"

Upstream account score 80; tier B. decision-H / account-H / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Professional role operations; separate relevance 2. p16-role / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Source-supported professional destination "p16@h\.example". p16-destination / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; support-p16-destination / support-p16-destination / effective 2026-10-18T11:05:00Z / age 3300s / reviewed 2026-10-18T11:30:00Z

Employer support: p16-employer / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Ownership support: owner-H / account-H / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p16-owner / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Explicit negative clearances: p16-prior / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p16-suppression / contact-p16 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Next research question: Is this person the appropriate professional contact for the stated offering? Purchasing authority and buying intent have not been established.

### 4. p06 at C

Display names from original rows r06: "Casey Oven"

Upstream account score 75; tier B. decision-C / account-C / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Professional role operations; separate relevance 2. p06-role / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Source-supported professional destination "p06@c\.example". p06-destination / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; support-p06-destination / support-p06-destination / effective 2026-10-18T11:05:00Z / age 3300s / reviewed 2026-10-18T11:30:00Z

Employer support: p06-employer / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Ownership support: owner-C / account-C / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p06-owner / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Explicit negative clearances: p06-prior / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p06-suppression / contact-p06 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Next research question: Is this person the appropriate professional contact for the stated offering? Purchasing authority and buying intent have not been established.

## Every non-candidate and unresolved question

### p03 at A: not_relevant

Display names from rows r03: "Alex Sample"

Selected upstream score 90, tier A; separate role relevance 0. Account reference: decision-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- role_not_relevant: p03-role / contact-p03 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Known finance role has relevance 0 for this task-specific offering. This is not a judgment of the person or their general authority.

### p05 at B: held

Display names from rows r05: "Riley Fields"

Selected upstream score 90, tier A; separate role relevance 3. Account reference: decision-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- destination_support_missing: no supplied assertion
- destination_unverified: p05-destination / contact-p05 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves destination_support_missing, destination_unverified? Retain this hold until the snapshot is explicitly corrected.

### p07 at C: held

Display names from rows r07: "Taylor Flour"

Selected upstream score 75, tier B; separate role relevance unknown. Account reference: decision-C / account-C / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-C / account-C / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- role_stale: p07-role / contact-p07 / effective 2026-09-17T12:00:00Z / age 2678400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves role_stale? Retain this hold until the snapshot is explicitly corrected.

### p08 at D: excluded

Display names from rows r08: "Avery Crumb"

Selected upstream score 100, tier A; separate role relevance 3. Account reference: decision-D / account-D / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Existing customer restriction". decision-D / account-D / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- account_excluded: decision-D / account-D / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Excluded from this research queue. A later negative observation does not cancel a positive exclusion in this contract.

### p09 at E: held

Display names from rows r09: "Quinn Hearth"

Selected upstream score 70, tier B; separate role relevance 3. Account reference: decision-E / account-E / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Missing mandatory company evidence". decision-E / account-E / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- account_held: decision-E / account-E / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves account_held? Retain this hold until the snapshot is explicitly corrected.

### p10 at F: held

Display names from rows r10: "Skyler Roll"

Selected upstream score 85, tier A; separate role relevance 3. Account reference: decision-F / account-F / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-F / account-F / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- account_owner_conflicting: owner-F / account-F / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; owner-F-conflict / account-F / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves account_owner_conflicting? Retain this hold until the snapshot is explicitly corrected.

### p11 at A: excluded

Display names from rows r11: "Jordan Glaze"

Selected upstream score 90, tier A; separate role relevance 3. Account reference: decision-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-A / account-A / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- suppression_conflicting: p11-opt-out / contact-p11 / effective 2026-10-16T12:00:00Z / age 172800s / reviewed 2026-10-18T11:30:00Z; p11-suppression / contact-p11 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
- suppression_positive: p11-opt-out / contact-p11 / effective 2026-10-16T12:00:00Z / age 172800s / reviewed 2026-10-18T11:30:00Z
Excluded from this research queue. A later negative observation does not cancel a positive exclusion in this contract.

### p12 at B: excluded

Display names from rows r12: "Emery Batch"

Selected upstream score 90, tier A; separate role relevance 3. Account reference: decision-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-B / account-B / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- prior_touch_positive: p12-prior / contact-p12 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Excluded from this research queue. A later negative observation does not cancel a positive exclusion in this contract.

### p13 at G: held

Display names from rows r13: "Drew Rise"

Selected upstream score 80, tier B; separate role relevance 3. Account reference: decision-G / account-G / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-G / account-G / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- employer_conflicting: p13-employer / contact-p13 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z; p13-employer-conflict / contact-p13 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves employer_conflicting? Retain this hold until the snapshot is explicitly corrected.

### p14 at G: not_relevant

Display names from rows r14: "Rowan Dough"

Selected upstream score 80, tier B; separate role relevance 0. Account reference: decision-G / account-G / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-G / account-G / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- role_not_relevant: p14-role / contact-p14 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Known finance role has relevance 0 for this task-specific offering. This is not a judgment of the person or their general authority.

### p15 at H: held

Display names from rows r15: "Finley Cake"

Selected upstream score 80, tier B; separate role relevance 3. Account reference: decision-H / account-H / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

Upstream company decision reason: "Reviewed upstream company criteria satisfied for this fictional offering". decision-H / account-H / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

- prior_touch_unknown: p15-prior / contact-p15 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z
Research question: What reviewed evidence resolves prior_touch_unknown? Retain this hold until the snapshot is explicitly corrected.

## Source coverage and identity

38 supplied sources; 38 carry a review timestamp; 124 assertions; 1 stale assertions retained.

Names and mailboxes do not merge people. All original rows and exact alias support remain in identity-map.csv and request.json.

Alias q01 => p01: alias-q01-p01 / alias-q01 / effective 2026-10-17T12:00:00Z / age 86400s / reviewed 2026-10-18T11:30:00Z

## Supplied source index

- account-A; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-A"
- account-B; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-B"
- account-C; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-C"
- account-D; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-D"
- account-E; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-E"
- account-F; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-F"
- account-G; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-G"
- account-H; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:account\-H"
- alias-q01; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:alias\-q01"
- contact-p01; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p01"
- contact-p03; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p03"
- contact-p04; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p04"
- contact-p05; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p05"
- contact-p06; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p06"
- contact-p07; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p07"
- contact-p08; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p08"
- contact-p09; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p09"
- contact-p10; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p10"
- contact-p11; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p11"
- contact-p12; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p12"
- contact-p13; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p13"
- contact-p14; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p14"
- contact-p15; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p15"
- contact-p16; observed 2026-10-18T11:00:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:contact\-p16"
- support-p01-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p01\-destination"
- support-p03-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p03\-destination"
- support-p04-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p04\-destination"
- support-p06-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p06\-destination"
- support-p07-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p07\-destination"
- support-p08-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p08\-destination"
- support-p09-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p09\-destination"
- support-p10-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p10\-destination"
- support-p11-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p11\-destination"
- support-p12-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p12\-destination"
- support-p13-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p13\-destination"
- support-p14-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p14\-destination"
- support-p15-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p15\-destination"
- support-p16-destination; observed 2026-10-18T11:15:00Z; reviewed 2026-10-18T11:30:00Z; locator "urn\:fictional\:support\-p16\-destination"

## Limits and safe reading

- Dataset kind, local-use authorization and snapshot completeness are unverified caller declarations.
- Sources are supplied snapshots with caller-extracted assertions; review timestamps and hashes do not authenticate facts, identity, text entailment or publisher truth.
- Company score, tier and disposition are reviewed upstream inputs, not recomputed or independently verified live fit.
- Source-confirmed professional destination means supplied source support only; deliverability and authority to contact remain unknown.
- Buying intent and purchasing authority are unknown. No sensitive-trait or employment/credit eligibility decisions.
- No outreach, message drafts, enrollment, live CRM changes, network access or scheduled follow-up.
- CSV text cells use reversible text:JSON display encoding. Import as text; no universal spreadsheet-software safety claim.

Read source-ledger.json alongside evidence-ledger.json to check extracted assertions against the retained source text. The machine cannot establish that the text entails the caller-extracted assertions.
