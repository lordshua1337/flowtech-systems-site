# Browser checks still required

Source/build checks and Node reducer execution do not establish browser behavior. Before any live use, separately test at the declared desktop/mobile sizes, zoom and reflow, tab order, visible focus, keyboard submission/reset, error announcements, screen-reader labels, no-JavaScript behavior, real DOM state changes and local-only network behavior. No such browser, keyboard or assistive-technology session was run for this artifact. Public release remains unauthorized.
