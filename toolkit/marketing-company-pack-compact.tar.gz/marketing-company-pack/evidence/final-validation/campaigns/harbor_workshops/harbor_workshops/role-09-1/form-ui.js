/* Local DOM wiring. Behavior is not claimed browser-tested. */
(function () {
  'use strict';
  const form = document.getElementById('interest-demo');
  if (!form) return;
  let state = LocalDemoState.initialState();
  const status = document.getElementById('form-status');
  function show() {
    for (const field of ['email','context','consent']) {
      const input = document.getElementById(field);
      input.setAttribute('aria-invalid', state.errors[field] ? 'true' : 'false');
      document.getElementById(field+'-error').textContent = state.errors[field] || '';
    }
    status.textContent = state.message;
  }
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    for (const field of ['email','context','consent']) {
      const input = document.getElementById(field);
      state = LocalDemoState.transition(state,{type:'change',field:field,value:field==='consent' ? input.checked : input.value});
    }
    state = LocalDemoState.transition(state,{type:'submit'});
    show();
  });
  form.addEventListener('reset', function () { state=LocalDemoState.transition(state,{type:'reset'}); show(); });
})();
