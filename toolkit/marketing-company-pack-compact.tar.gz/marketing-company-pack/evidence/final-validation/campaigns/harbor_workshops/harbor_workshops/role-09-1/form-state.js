/* Pure local demo state. No network, persistence, tracking, transmission or side effects. */
(function (root) {
  'use strict';
  function initialState() { return {stage:'idle', email:'', context:'', consent:false, errors:{}, message:''}; }
  function transition(previous, action) {
    if (!previous || !action || typeof action.type !== 'string') throw new TypeError('state and action required');
    if (action.type === 'reset') return initialState();
    if (action.type === 'change') {
      if (!['email','context','consent'].includes(action.field)) throw new Error('unknown field');
      if (action.field === 'consent' && typeof action.value !== 'boolean') throw new TypeError('consent must be boolean');
      if (action.field !== 'consent' && typeof action.value !== 'string') throw new TypeError('text required');
      return Object.assign({}, previous, {[action.field]: action.value}, {stage:'editing',errors:{},message:''});
    }
    if (action.type === 'submit') {
      const errors = {};
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(previous.email) || previous.email.length > 254) errors.email='Enter a valid example email.';
      if (!previous.context.trim() || previous.context.length > 400) errors.context='Add 1 to 400 characters of context.';
      if (previous.consent !== true) errors.consent='Confirm that you understand this is a local-only demo.';
      return Object.assign({}, previous, {errors: errors, stage:Object.keys(errors).length ? 'invalid' : 'demo_complete', message:Object.keys(errors).length ? 'Review the highlighted demo fields.' : 'Demo complete. Nothing was sent or saved. No request or registration was created.'});
    }
    throw new Error('unknown action');
  }
  const api = {initialState, transition};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.LocalDemoState = api;
})(typeof window !== 'undefined' ? window : null);
