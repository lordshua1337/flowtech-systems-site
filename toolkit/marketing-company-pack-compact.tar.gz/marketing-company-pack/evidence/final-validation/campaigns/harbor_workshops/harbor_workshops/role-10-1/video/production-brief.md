# Original silent technical edit

Create original 640x360, 24 fps, silent text/geometry clips using the local font and existing FFmpeg filters. Retain intro frames [0,48), detail [24,72), and CTA [0,48). Each output segment is 48 frames; the result is 144 frames and six seconds. The supplied caption timing is 0-1800, 2000-3800, 4000-5800 ms. Exact authored cue text, price and full limitations are in the local source text files.

Visible source-frame counters distinguish every selected source frame. The FFV1 intermediate has exact all-frame decoded hash lineage. The distribution MP4 is lossy H.264 and is separately checked for timestamps and similarity. No music, voice, external footage, raster source, image provider, browser or Blender is used. This is not narration, ASR, listening or full-motion playback proof.
