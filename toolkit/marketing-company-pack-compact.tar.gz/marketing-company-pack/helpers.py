"""Exact narrow local helper commands; sample fixtures are not campaign observations."""
HELPERS={
 'dependency':{'owner':'coordinate-project-delivery','script':'scripts/project_dependencies.py','input':'examples/fictional-launch-selected.json','args':['create','--input','{input}','--output','{output}']},
 'coding':{'owner':'customer-research-analysis','script':'scripts/reconcile_coding.py','input':'examples/cedar-coding.json','args':['run','--input','{input}','--output','{output}']},
 'contacts':{'owner':'qualify-prospects','script':'scripts/contact_shortlist.py','input':'fixtures/contact-shortlist-fictional.json','args':['build','{input}','{output}']},
 'organic':{'owner':'channel-content-measurement','script':'scripts/measure.py','input':'references/synthetic.json','output_file':True,'args':['{input}','--out','{output}']},
 'navigation':{'owner':'design-experience-architecture','script':'scripts/check_flow.py','input':'examples/lumen-notes.json','args':['{input}'],'stdout_report':True},
 'contrast':{'owner':'audit-accessibility','script':'scripts/declared_text_contrast.py','input':'tests/example.json','args':['{input}','{output}']},
 'paid-search':{'owner':'design-paid-account-structure','script':'scripts/validate.py','input':'fixtures/architecture.json','args':['{input}'],'stdout_report':True},
 'paid-reconciliation':{'owner':'analyze-paid-media','script':'scripts/reconcile_paid_exports.py','input':'examples/paid-reconciliation.synthetic.json','args':['{input}','{output}']},
 'causal-plan':{'owner':'design-causal-conversion-studies','script':'scripts/study.py','input':'examples/plan.json','args':['plan','{input}','--output-dir','{output}']},
 'causal-readout':{'owner':'design-causal-conversion-studies','script':'scripts/study.py','input':'examples/study.json','args':['analyze','{input}','--output-dir','{output}']}}
