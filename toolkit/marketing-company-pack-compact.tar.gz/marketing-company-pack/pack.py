#!/usr/bin/env python3
"""Run one selected marketing workflow, a27-role local resimulation, or inspect holds."""
import argparse, json, os, sys
from pathlib import Path
from composed import ROOT, Adapter, Orchestrator, read_json, jbytes, verify_lock, safe_path

def fresh_output(relative):
    p=safe_path(ROOT,relative)
    if p.exists() or p.is_symlink():raise ValueError('Use a fresh output directory; no clobber')
    p.mkdir(parents=True);return p

def run_case(case,out,workflow=None):
    manifest=read_json(ROOT/'inputs'/case/'run.json')
    if workflow:
        registry=read_json(ROOT/'WORKFLOWS.json');matches=[x for x in registry['workflows'] if x['workflow_id']==workflow]
        if len(matches)!=1:raise ValueError('Unknown workflow')
        item=matches[0]
        if not item.get('execution'):
            folder=fresh_output(out);(folder/'hold.json').write_bytes(jbytes(item));return {'state':'held','workflow':workflow,'reason':item['limitation']},3
        role=int(workflow[1:3]);job={'id':workflow.replace('.','-'),'role_id':role,'skill_id':workflow,'requires':[],'inputs':[manifest['workflow_inputs'][workflow]]}
        manifest['jobs']=[job]
        # Integrity handoff tests need actual upstream files, not an empty relay.
        if workflow in {'R13.W4','R21.W4'}:
            upstream_role=8 if workflow=='R13.W4' else 20
            upstream_skill='R08.W1' if upstream_role==8 else 'R20.W3'
            upstream={'id':'upstream','role_id':upstream_role,'skill_id':upstream_skill,'requires':[],'inputs':[manifest['workflow_inputs'][upstream_skill]]}
            job['requires']=[{'job_id':'upstream','artifact_type':manifest['roles'][upstream_role-1]['output_type']}]
            manifest['jobs']=[upstream,job]
    folder=fresh_output(out);adapter=Adapter(ROOT,out)
    runner=Orchestrator(manifest['source'],manifest['roles'],manifest['jobs'],catalog=manifest['catalog'],root=ROOT,adapter=adapter,run_id=case if workflow is None else case+'-'+workflow.replace('.','-'))
    summary=runner.run(adapter,external_actions=['send','spend','deploy'])
    (folder/'summary.json').write_bytes(jbytes(summary));runner.save_trace(folder/'trace.jsonl')
    (folder/'artifact-index.json').write_bytes(jbytes(runner.artifacts));(folder/'dispatch-receipts.json').write_bytes(jbytes(runner.receipts))
    return summary,0 if summary['task_chain_complete'] else 2

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='mode',required=True)
    for mode in ['run','workflow']:
        s=sub.add_parser(mode);s.add_argument('case',choices=['maplebench','harbor_workshops','ledgernest'])
        if mode=='workflow':s.add_argument('workflow')
        s.add_argument('--out',required=True,help='Fresh relative directory inside pack')
    sub.add_parser('verify-source');sub.add_parser('list')
    a=p.parse_args()
    try:
        if a.mode=='verify-source':print(json.dumps({'verified_bytes':verify_lock(),'status':'source_bytes_match','semantic_truth_verified':False}));return 0
        if a.mode=='list':print((ROOT/'WORKFLOWS.json').read_text());return 0
        summary,code=run_case(a.case,a.out,getattr(a,'workflow',None));print(json.dumps(summary,indent=2));return code
    except Exception as exc:print(json.dumps({'status':'refused','reason':str(exc)}),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
