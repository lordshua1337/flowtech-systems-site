"""Narrow presentation receipts; authentic raw bytes remain outside export root."""
import copy,hashlib,json,os,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def retain_raw(kind,raw):
    if not re.fullmatch(r'[a-z0-9-]+',kind) or not isinstance(raw,bytes):raise ValueError('Malformed raw receipt')
    folder=Path(os.environ.get('MARKETING_RAW_EVIDENCE_DIR',str(ROOT.parent/(ROOT.name+'-private-evidence')))).resolve()
    if folder==ROOT or folder.is_relative_to(ROOT):raise ValueError('Raw receipt directory must be outside the portable pack')
    folder.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(raw).hexdigest();name=kind+'-'+digest+'.raw';path=folder/name
    try:
        with path.open('xb') as f:f.write(raw)
    except FileExistsError:
        if path.read_bytes()!=raw:raise ValueError('Raw receipt collision')
    return {'raw_receipt_id':name,'sha256':digest,'bytes':len(raw),'storage_scope':'Authentic raw bytes retained separately outside export root; not embedded in this presentation.'}

def same_path(value,expected):
    if not isinstance(value,str):raise ValueError('Expected a path-only stdout field')
    path=Path(value);path=path if path.is_absolute() else ROOT/path
    if path.resolve()!=Path(expected).resolve():raise ValueError('Unexpected returned output directory')

def path_stdout(raw,expected,replacement,kind,field=None):
    saved=retain_raw(kind,raw)
    if field is None:
        value=raw.decode('utf-8').strip();same_path(value,expected);presentation=replacement
    else:
        value=json.loads(raw);same_path(value[field],expected);presentation=copy.deepcopy(value);presentation[field]=replacement
    return {'schema':'portable-stdout-presentation/1','evidence_kind':'DERIVED_PRESENTATION_NOT_RAW_STDOUT','raw_original':saved,'normalizations':[{'field':field or 'entire_path_only_stdout','replacement':replacement,'reason':'Omit only the exact verified local output directory, retaining original raw bytes separately.'}],'presentation':presentation}

def os_error(exc):
    raw=json.dumps({'type':type(exc).__name__,'detail':str(exc),'filename':exc.filename},ensure_ascii=False).encode()
    saved=retain_raw('filesystem-error',raw);filename='not supplied'
    if exc.filename:
        path=Path(exc.filename)
        try:filename=str(path.resolve().relative_to(ROOT))
        except ValueError:filename='outside portable pack'
    return f"Portable diagnostic: {type(exc).__name__}; file={filename}; original raw error SHA-256={saved['sha256']}."
