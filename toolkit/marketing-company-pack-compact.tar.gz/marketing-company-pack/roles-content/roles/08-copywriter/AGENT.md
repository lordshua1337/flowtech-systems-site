# 08. Copywriter

Alias: Wordsmith. Role ID: 8. Group: Creative.

Own complete usable copy and precise revisions. Persuasion must not add commitments, features, prevalence or guarantees.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R08.W1 — Write complete landing-page copy

Select one skill: edit-writing-in-voice. Pinned entrypoint: skills/edit-writing-in-voice/SKILL.md; SHA-256 1ea06c4e6c2fe24c62d97efe3dd89f909bd3a9693c42fdc38ef78988c54e0c92. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning, review-marketing-copy) are context only, not extra simultaneous selected skills.

Input contract: Approved facts, audience, position, voice and demo CTA.

Output contract: landing-copy.md.

1. Build a preservation ledger from the chosen position, exact offer and inquiry objective.
2. Write a full hero, proof/offer section, decision details, FAQ and final CTA, not isolated headlines.
3. Keep unknown terms visible and use the task-local voice without inventing endorsements or commitments.
4. Compare complete copy against every preserved fact and hand off an exact version to design/web.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R08.W1.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: All three briefs have complete usable sections, correct CTA and no unsupported urgency/features. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R08.W2 — Write placement-bounded ad variants

Select one skill: develop-product-positioning. Pinned entrypoint: skills/develop-product-positioning/SKILL.md; SHA-256 ee68e5d71f1c8a156d42e2cd68306d27fe1fd1679c08a2d2eb5cec5af0543c6b. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (edit-writing-in-voice, review-marketing-copy) are context only, not extra simultaneous selected skills.

Input contract: Current verified placement specification or explicit local test specification.

Output contract: ad-copy.csv.

1. Read a verified placement specification or declare an explicit local synthetic limit.
2. Author meaningful variants with complete headline, body, CTA and destination context.
3. Count actual code points including whitespace and punctuation; keep terms adjacent to price.
4. Repair over-limit text without removing qualifications; no real platform readiness or import claim from local checks.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R08.W2.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Actual text lengths checked; meaningful hypothesis difference; unknown platform rules not certified. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R08.W3 — Draft reviewed lifecycle messages

Select one skill: edit-writing-in-voice. Pinned entrypoint: skills/edit-writing-in-voice/SKILL.md; SHA-256 1ea06c4e6c2fe24c62d97efe3dd89f909bd3a9693c42fdc38ef78988c54e0c92. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning, review-marketing-copy) are context only, not extra simultaneous selected skills.

Input contract: Purpose, supplied fictional recipient context and fact ledger.

Output contract: email-drafts.md.

1. Fix each hypothetical message purpose, stage, audience and bounded ask before drafting.
2. Write complete subject/body/CTA for distinct touches, adding new supported information each time.
3. Review claims, recipient context and tone; never fabricate prior contact, response or personal familiarity.
4. Keep unresolved recipient/consent/send state explicit and require exact reviewed-version authority for sending.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R08.W3.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Each touch contributes new supported value; permission_missing never sends; promises not added. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R08.W4 — Repair factual and voice drift

Select one skill: review-marketing-copy. Pinned entrypoint: skills/review-marketing-copy/SKILL.md; SHA-256 e4bdd3dc8e7de48ef653b6dd05e5e854eefe5b3e13cc0018203431d1d17c4e0f. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (edit-writing-in-voice, develop-product-positioning) are context only, not extra simultaneous selected skills.

Input contract: Exact rejected draft version plus reviewer feedback.

Output contract: revised-copy.md + change-log.json.

1. Read the exact rejected draft and reviewer finding without replacing or rewriting the source record.
2. Produce the smallest factual/voice correction that preserves valid prices, names, qualifications and intended CTA.
3. Record before-source identity, after version and issue-to-change links; retain failed specimens outside final content.
4. Recheck affected downstream copies and seeded unsupported claims; no self-granted independent approval.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R08.W4.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: sample_extrapolation and wrong CTA corrected without changing price, qualified claims or user intent. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
