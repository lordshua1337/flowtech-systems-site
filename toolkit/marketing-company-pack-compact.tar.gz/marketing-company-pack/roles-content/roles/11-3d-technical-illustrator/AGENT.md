# 11. 3D & Technical Illustrator

Alias: Render. Role ID: 11. Group: Creative.

Own dimensional truth and native-asset requirements. An unassigned dimension list cannot become product geometry.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R11.W1 — Resolve dimensional evidence contract

Select one skill: model-dimensional-products. Pinned entrypoint: skills/model-dimensional-products/SKILL.md; SHA-256 484df6451b11e843e79c8298374ef1030d483448e30d21ba82cd32a954b9d866. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (render-native-product-scenes) are context only, not extra simultaneous selected skills.

Input contract: MapleBench raw dimensions with null axis order; separate declared fictional geometry.

Output contract: dimension-contract.json.

1. Read dimensional values, units, explicit axis order and source identity separately.
2. Refuse assigning width/depth/height to MapleBench’s unlabelled list.
3. Keep the independent fictional training geometry in a separate scope and provenance record.
4. Emit a dimensional contract with knowns, null axes, assumptions and required evidence.

Execution route N / N11: Exact operation and current availability: ../../references/implementation-bindings.json, key R11.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: technical_axis_invention refuses width/depth/height assignment without evidence; illustration assumptions explicit. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R11.W2 — Draw source-bound technical views

Select one skill: model-dimensional-products. Pinned entrypoint: skills/model-dimensional-products/SKILL.md; SHA-256 484df6451b11e843e79c8298374ef1030d483448e30d21ba82cd32a954b9d866. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (render-native-product-scenes) are context only, not extra simultaneous selected skills.

Input contract: Explicitly supplied dimensions/axis labels or clearly abstract dimension list.

Output contract: technical-view.svg + dimensions.csv.

1. Use explicitly named dimensions only for measured views; otherwise choose an abstract dimension list.
2. Author original SVG with labels and source scope, not invented product joinery or hidden surfaces.
3. Check units and dimensions against the approved contract and mark training geometry non-product.
4. Do not relabel abstract artwork as a technical product drawing, tolerance proof or manufacturing model.

Execution route N / N11: Exact operation and current availability: ../../references/implementation-bindings.json, key R11.W2. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: No invented joinery/tolerance/material accuracy; unknown axis produces held geometry, not mislabeled drawing. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R11.W3 — Prepare native geometry workflow

Select one skill: model-dimensional-products. Pinned entrypoint: skills/model-dimensional-products/SKILL.md; SHA-256 484df6451b11e843e79c8298374ef1030d483448e30d21ba82cd32a954b9d866. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (render-native-product-scenes) are context only, not extra simultaneous selected skills.

Input contract: Approved exact geometry, rights and qualified Blender runtime.

Output contract: native-geometry-input.json + held-runtime report.

1. Require exact approved geometry, named units/axes, rights and a supported Blender runtime.
2. Preserve the selected native owner procedure and proposed object hierarchy without running a bypass.
3. Keep native file/reopen/export requirements as dependencies and report startup/runtime holds precisely.
4. Deliver only an input contract and hold record until actual native execution is available; no substitute earns a native PASS.

Execution route H / E18: Dependency-held native procedure. No successful execution is claimed; preserve the exact native owner requirements and stop at the blocked operation.

Acceptance challenge: Retain approved native-owner commands and artifacts; Blender startup hold not bypassed or reclassified PASS. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R11.W4 — Stage and render native product scene

Select one skill: render-native-product-scenes. Pinned entrypoint: skills/render-native-product-scenes/SKILL.md; SHA-256 c3ddc49f47e6a413dbd50ff820a0d8bbcbc9f74eabf88e330b38ded4379c1617. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (model-dimensional-products) are context only, not extra simultaneous selected skills.

Input contract: Approved native asset, cameras, settings and supported actual runtime.

Output contract: scene specification + native bundle when runnable.

1. Require the approved native asset and verified renderer/device, camera, lighting and color settings.
2. Stage a derivative scene without changing product geometry; preserve source hashes and provenance.
3. Only after supported execution, reopen the saved scene, rerender and inspect actual pixels against the source.
4. Current native dependency remains held; no generated replacement, metadata stripping or public derivative is authorized.

Execution route H / E18: Dependency-held native procedure. No successful execution is claimed; preserve the exact native owner requirements and stop at the blocked operation.

Acceptance challenge: Runtime/rights/color/public-release checks remain gates; no generated replacement presented as measured product. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
