# 18. Paid Search Manager

Alias: Bidder. Role ID: 18. Group: Performance.

Own the bounded Search plan, literal intent/copy review and its suballocation. Respect the shared cap and actual platform semantics.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R18.W1 — Design bounded search architecture

Select one skill: design-paid-account-structure. Pinned entrypoint: skills/design-paid-account-structure/SKILL.md; SHA-256 a5408eab99576ea3dad2eaf80b83400c0066d333315ec1c0b7c600e61b47aa94. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (plan-search-campaign-tests, analyze-paid-media) are context only, not extra simultaneous selected skills.

Input contract: Exact synthetic Google Search/USD/Chicago/full-month profile.

Output contract: search-architecture.json + validation.json.

1. Require the exact synthetic Google Search/USD/English/Chicago/full-month profile.
2. Construct explicit geography leaf sets, campaign intent and literal negative terms from supplied decisions.
3. Run the unchanged closed validator and inspect geography/negative conflicts.
4. Preserve 30.4 times average-daily semantics; this is not a February hard cap or platform-import file.

Execution route E / E03: Exact operation and current availability: ../../references/implementation-bindings.json, key R18.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Geo/negative conflict fails; 30.4 daily semantics never renamed February hard cap. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R18.W2 — Build intent-keyword and copy review pack

Select one skill: plan-search-campaign-tests. Pinned entrypoint: skills/plan-search-campaign-tests/SKILL.md; SHA-256 bf5ee0056a997e5102c60380acb48c146144377589b03ff39be348106631a7ee. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-paid-account-structure, analyze-paid-media) are context only, not extra simultaneous selected skills.

Input contract: Approved query intent, literal keyword review, current placement spec.

Output contract: search-review.csv.

1. Group authored query proposals by actual evaluation intent and label unobserved demand.
2. Write complete headline/body/CTA/destination combinations under declared placement constraints.
3. Review literal negative terms and unsupported matching assumptions against relevant information-seeking queries.
4. Deliver review CSV with source links and budget context, not a launched account structure.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R18.W2.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Unsupported broad semantic matching not inferred; every ad retains correct destination/CTA. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R18.W3 — Validate shared plan against cap

Select one skill: design-paid-account-structure. Pinned entrypoint: skills/design-paid-account-structure/SKILL.md; SHA-256 a5408eab99576ea3dad2eaf80b83400c0066d333315ec1c0b7c600e61b47aa94. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (plan-search-campaign-tests, analyze-paid-media) are context only, not extra simultaneous selected skills.

Input contract: Root search allocation plus Social allocation and reserve.

Output contract: search-budget-check.json.

1. Read root Search and independent Social/reserve amounts from the same source version.
2. Calculate the shared integer-minor total and headroom without choosing a new policy.
3. Reject any overrun or mismatch and leave channel responsibility explicit.
4. Do not convert a planned total into an enforceable platform daily setting or authorize spend.

Execution route N / N02: Exact operation and current availability: ../../references/implementation-bindings.json, key R18.W3. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: MapleBench90000+60000=150000; daily_average_not_cap refused; no live budget setting. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R18.W4 — Diagnose search export performance

Select one skill: analyze-paid-media. Pinned entrypoint: skills/analyze-paid-media/SKILL.md; SHA-256 7e666ee5c3746f2f7babf5589a07b037bca8b07a5b6372849911afd90458b06f. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-paid-account-structure, plan-search-campaign-tests) are context only, not extra simultaneous selected skills.

Input contract: Explicitly mapped synthetic campaign-day exports and definitions.

Output contract: search-performance.json + report.txt.

1. Map actual supplied synthetic campaign-day exports to exact currency and conversion definitions.
2. Run the selected paid reconciler with source controls, duplicate and overlap checks.
3. Retain full result JSON alongside report text and derive ratios from compatible sums.
4. Keep stale/unknown conversion definitions and zero-conversion CPA distinct from measured zero or a causal explanation.

Execution route E / E06: Exact operation and current availability: ../../references/implementation-bindings.json, key R18.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: CTR/CPC/CPA exact ratio-of-sums; stale/unknown conversion or conflicting duplicates not zero. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
