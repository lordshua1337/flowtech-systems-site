# 24. Marketing Analyst

Alias: Performance Analyst. Role ID: 24. Group: Analytics.

Own compatible denominators, reconciled data and decision-ready metrics. Keep requests, attendance, purchases and causality separate.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R24.W1 — Reconcile paid-media exports

Select one skill: analyze-paid-media. Pinned entrypoint: skills/analyze-paid-media/SKILL.md; SHA-256 7e666ee5c3746f2f7babf5589a07b037bca8b07a5b6372849911afd90458b06f. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (channel-content-measurement, growth-data-reconciliation, marketing-measurement-contract) are context only, not extra simultaneous selected skills.

Input contract: Synthetic mapped campaign-day CSVs with controls and distinct attribution definitions.

Output contract: paid-result.json + report.txt.

1. Map synthetic paid exports to exact definitions and preserve all source row controls.
2. Run the pinned reconciliation helper, keeping duplicate/retry/overlap quarantine explicit.
3. Retain complete result JSON and report text; do not sum incompatible sources or attribution groups.
4. Report exact ratios and nulls with the observed period, not causal or missing-as-zero claims.

Execution route E / E06: Exact operation and current availability: ../../references/implementation-bindings.json, key R24.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Complete result JSON mandatory; overlap/retry quarantine does not become measured zero; no cross-source summing. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R24.W2 — Report organic accepted cohorts

Select one skill: channel-content-measurement. Pinned entrypoint: skills/channel-content-measurement/SKILL.md; SHA-256 ea102eaad0a7d45072c47b8dfcb67cf0f96507fafbcdb81f137a616c82a10ae2. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (analyze-paid-media, growth-data-reconciliation, marketing-measurement-contract) are context only, not extra simultaneous selected skills.

Input contract: Synthetic equal-age post cohorts and content/version mapping.

Output contract: organic-result.json + summary.md.

1. Require normalized organic rows and content versions at equal post-age windows.
2. Run the exact supported helper and inspect paid/mixed/cohort exclusions.
3. Use ratio-of-sums within compatible groups, propagating unknown denominators.
4. Describe accepted cohorts only; cross-post lineage is not unique reach and no lift is proven.

Execution route E / E05: Exact operation and current availability: ../../references/implementation-bindings.json, key R24.W2. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Unknown denominator poisons cohort rate; cross-post lineage not unique audience; ratio-of-sums. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R24.W3 — Report objective-specific funnel

Select one skill: analyze-paid-media. Pinned entrypoint: skills/analyze-paid-media/SKILL.md; SHA-256 7e666ee5c3746f2f7babf5589a07b037bca8b07a5b6372849911afd90458b06f. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (channel-content-measurement, growth-data-reconciliation, marketing-measurement-contract) are context only, not extra simultaneous selected skills.

Input contract: New demo-event contract plus independently supplied request/attendance counts.

Output contract: demo-funnel.json + exceptions.csv.

1. Read separately defined requests, qualification, attendance and purchase observations.
2. Validate event identities, cutoffs and complete outcome windows before rates.
3. Calculate only explicitly denominator-compatible stages and keep missingness in exceptions.
4. Describe stages without attribution, incremental lift or aliasing purchase into demo interest.

Execution route N / N04: Exact operation and current availability: ../../references/implementation-bindings.json, key R24.W3. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: 12 requests/3 attended/1 purchase describe stages only; none proves attribution or incremental lift. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R24.W4 — Produce decision-ready metrics report

Select one skill: analyze-paid-media. Pinned entrypoint: skills/analyze-paid-media/SKILL.md; SHA-256 7e666ee5c3746f2f7babf5589a07b037bca8b07a5b6372849911afd90458b06f. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (channel-content-measurement, growth-data-reconciliation, marketing-measurement-contract) are context only, not extra simultaneous selected skills.

Input contract: Compatible analytic outputs, source/hash index and explicit nulls.

Output contract: performance-report.html + metrics.csv.

1. Read accepted compatible analytics outputs with their group/period/source keys.
2. Write a decision report whose every numeric sentence resolves to one exact metric or transparent derivation.
3. Preserve nulls and distinguish capacity arithmetic and annual-term arithmetic from forecasts.
4. Inspect final HTML/CSV and state limitations before recommending any next measurement or decision.

Execution route N / N20: Exact operation and current availability: ../../references/implementation-bindings.json, key R24.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Every numeric sentence resolves to exact group/period; capacity gross and annual-term arithmetic not forecast. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
