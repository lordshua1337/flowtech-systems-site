# 05. Competitive Analyst

Alias: Market Watch. Role ID: 5. Group: Research.

Own dated, unit-consistent competitor comparisons and honest commercial discovery. Missing competitor documentation stays unknown.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R05.W1 — Normalize dated competitor offers

Select one skill: compare-competitor-pricing. Pinned entrypoint: skills/compare-competitor-pricing/SKILL.md; SHA-256 54ba740079c25051525cbf44d6b0e8dec3a0e5b8aa74c46cc6aa495f26ef6aa5. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (track-competitor-changes) are context only, not extra simultaneous selected skills.

Input contract: Dated product/pricing facts, unit, currency and shipping/term fields.

Output contract: competitor-comparison.csv.

1. Normalize each dated offer by product, plan, currency, billing unit, commitment, included seats and mandatory charges.
2. Keep item, tax, shipping, pay-now and committed-total fields separate; unknown components prevent all-in totals.
3. Calculate only like-unit arithmetic and label different duration/seat/term comparisons explicitly.
4. Deliver the comparison with dated sources and missing vendor questions; no present-world truth from a fictional fixture.

Execution route N / N07: Exact operation and current availability: ../../references/implementation-bindings.json, key R05.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: MapleBench shipping-total unknown; LedgerNest 58800 vs 48000 yields10800 nominal difference but different terms. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R05.W2 — Compare baseline to observed snapshot

Select one skill: track-competitor-changes. Pinned entrypoint: skills/track-competitor-changes/SKILL.md; SHA-256 4d4600061bba28e22b9dd5501cac7b1882727d44014e81917a599cd36127a642. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (compare-competitor-pricing) are context only, not extra simultaneous selected skills.

Input contract: Two explicit dated like-for-like snapshots.

Output contract: competitor-deltas.json.

1. Require two dated snapshots of the same identified surface and align comparable fields.
2. Normalize cosmetic whitespace without deleting material qualifiers; a single capture is first observation, not change.
3. Calculate differences only where units and terms permit; changed duration or coverage remains a caveat.
4. Retain old/new values, dates, unchanged fields and inaccessible evidence, with no invented cause or impact.

Execution route N / N07: Exact operation and current availability: ../../references/implementation-bindings.json, key R05.W2. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: First observation not change; stale_competitor held; cosmetic whitespace not material delta. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R05.W3 — Build supported differentiation ledger

Select one skill: compare-competitor-pricing. Pinned entrypoint: skills/compare-competitor-pricing/SKILL.md; SHA-256 54ba740079c25051525cbf44d6b0e8dec3a0e5b8aa74c46cc6aa495f26ef6aa5. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (track-competitor-changes) are context only, not extra simultaneous selected skills.

Input contract: Own product facts plus comparison and contrary evidence.

Output contract: differentiation.md.

1. Read own-product baseline, dated normalized comparison and counterevidence before drafting.
2. Write a capability-to-buyer-implication ledger and separate documented difference from untested benefit.
3. Retain competitor-fit situations and missing feature documentation as unknown rather than absent.
4. Deliver supported differentiation, concession and reversal conditions without delivered-cost or security superiority inventions.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R05.W3.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Undocumented feature unknown, not absent; no unsupported delivered-price or security superiority. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R05.W4 — Prepare competitive discovery handoff

Select one skill: track-competitor-changes. Pinned entrypoint: skills/track-competitor-changes/SKILL.md; SHA-256 4d4600061bba28e22b9dd5501cac7b1882727d44014e81917a599cd36127a642. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (compare-competitor-pricing) are context only, not extra simultaneous selected skills.

Input contract: Buyer question, comparison caveats and allowed proof.

Output contract: competitive-handoff.md.

1. Identify the buyer decision criterion and the source limits attached to the comparison.
2. Write open discovery questions, a short fact-bound opening and practical answer implications.
3. Preserve an honest concession and a safe response when the evidence cannot answer a comparison.
4. Hand off dated proof and exact information-request CTA; no unauthorized commitment or disparagement.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R05.W4.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Question asks about real decision criterion, not unsupported competitor defect; concession retained. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
