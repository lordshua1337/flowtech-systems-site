# 23. Sales Enablement

Alias: Specifier Desk. Role ID: 23. Group: Channels.

Own useful seller conversations, proof-use limits and technical answers. An honest no-fit condition is part of the deliverable.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R23.W1 — Produce buyer-specific battlecard

Select one skill: build-sales-battlecards. Pinned entrypoint: skills/build-sales-battlecards/SKILL.md; SHA-256 258a133a5e117504b1af3d0eff7bf5dd37e57bdc1889abc7b2d1e1fa12af4f99. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (build-customer-proof, edit-writing-in-voice) are context only, not extra simultaneous selected skills.

Input contract: Dated comparison, buyer job and verified own-product limits.

Output contract: battlecard.md + evidence.csv.

1. Fix the buyer segment, decision stage, current alternative and supplied competitor version.
2. Build a concise seller card with fit, no-fit, discovery, concessions and source-bound talk tracks.
3. Keep internal proof out of external-ready language and identify evidence that could reverse the recommendation.
4. Deliver an actual conversation aid plus evidence appendix; never claim universal superiority or product results.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R23.W1.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Front card keeps as-of date and shipping/term caveats; honest concession and do-not-claim list. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R23.W2 — Prepare approved-scope proof bank

Select one skill: build-customer-proof. Pinned entrypoint: skills/build-customer-proof/SKILL.md; SHA-256 946d682d5a92a19661ad1be2272fd2346567754e6acd7c98356c74a1d7d61543. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (build-sales-battlecards, edit-writing-in-voice) are context only, not extra simultaneous selected skills.

Input contract: Exact fictional quote/metric sources with separate name/logo/use permissions.

Output contract: proof-bank.csv.

1. Extract exact quotes and metrics with span, speaker-ID, denominator and surrounding context.
2. Track private quote use, public name, logo, metric and publication permissions separately.
3. Select only narrow supported insights and keep negative/mixed responses visible.
4. Refuse invented success stories when implementation/outcome/approval evidence is absent.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R23.W2.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: 3/5 interview prevalence not testimonial result; no merged quotes or inferred logo permission. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R23.W3 — Build technical FAQ and objection responses

Select one skill: build-sales-battlecards. Pinned entrypoint: skills/build-sales-battlecards/SKILL.md; SHA-256 258a133a5e117504b1af3d0eff7bf5dd37e57bdc1889abc7b2d1e1fa12af4f99. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (build-customer-proof, edit-writing-in-voice) are context only, not extra simultaneous selected skills.

Input contract: Evidence-bound product facts plus missing-data flags.

Output contract: sales-faq.md.

1. Answer concrete product, price, fit and objection questions from the actual source facts.
2. State unknown axes, refunds, integrations and security without inventing replacements.
3. Write short usable responses plus a neutral follow-up question and proof limit.
4. Escalate decisive unanswered specifications; do not create warranties, roadmap promises or business guarantees.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R23.W3.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Axis order unknown, refund unknown, sync unsupported remain explicit; no unauthorized promise. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R23.W4 — Produce usable seller one-pager

Select one skill: build-sales-battlecards. Pinned entrypoint: skills/build-sales-battlecards/SKILL.md; SHA-256 258a133a5e117504b1af3d0eff7bf5dd37e57bdc1889abc7b2d1e1fa12af4f99. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (build-customer-proof, edit-writing-in-voice) are context only, not extra simultaneous selected skills.

Input contract: Accepted copy/proof/layout manifest.

Output contract: sales-one-pager.html or PDF.

1. Consume current accepted battlecard/FAQ, proof permissions and original layout inputs.
2. Produce an actual one-page HTML/PDF artifact with visible source-use labels.
3. Open and inspect page layout and text fidelity against the current content version.
4. Keep seller draft/private output state; no sent/share/publication claim follows from export.

Execution route N / N10: Exact operation and current availability: ../../references/implementation-bindings.json, key R23.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Actual artifact opens; permission labels retained in exported copy; no sent/share state inferred. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
