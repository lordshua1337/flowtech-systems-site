# 21. Marketing Ops & Automation

Alias: Router. Role ID: 21. Group: Performance.

Own typed contracts, one-skill dispatch and artifact lineage. Routing does not grant external execution or broaden a helper’s scope.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R21.W1 — Define portable workflow contracts

Select one skill: marketing-measurement-contract. Pinned entrypoint: skills/marketing-measurement-contract/SKILL.md; SHA-256 0cac45d6d7074b1a82523dda83e6578a969a899ffaf0db5eed430a86e14cd189. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-lifecycle-orchestration, coordinate-project-delivery) are context only, not extra simultaneous selected skills.

Input contract: Role/workflow IDs, exact inputs/output types and source versions.

Output contract: workflow-registry.json.

1. Register exact 27 role IDs/aliases and each of 108 workflow contracts without adding a developer team.
2. Define source digest, selected skill ID, typed inputs/prerequisites and one expected output type per job.
3. Validate one selected skill dispatch against role ownership and versioned implementation binding.
4. Keep authored-host dependencies, executable functions and held native operations distinct.

Execution route N / N18: Exact operation and current availability: ../../references/implementation-bindings.json, key R21.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Dispatch selects one skill at a time; wrong type/source/role refused; registry not runtime proof. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R21.W2 — Route actual produced artifacts

Select one skill: marketing-measurement-contract. Pinned entrypoint: skills/marketing-measurement-contract/SKILL.md; SHA-256 0cac45d6d7074b1a82523dda83e6578a969a899ffaf0db5eed430a86e14cd189. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-lifecycle-orchestration, coordinate-project-delivery) are context only, not extra simultaneous selected skills.

Input contract: New artifact-producing handlers and immutable prototype packets.

Output contract: dispatch-trace.jsonl + artifact-index.json.

1. Resolve safe relative input references and verify their actual byte hashes before dispatch.
2. Run only the selected bounded handler and write fresh real artifact files.
3. Bind envelope to role/job/run/workflow/version and inspect current prerequisite identities.
4. Accept only matching current artifacts; preserve traces and refuse stale/wrong-owner outputs or unsafe paths.

Execution route N / N18: Exact operation and current availability: ../../references/implementation-bindings.json, key R21.W2. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: No canned FileRoleplayAdapter outputs in expanded run; hashes refer to real files; concurrency1 and bounded retry. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R21.W3 — Validate demo-request event lineage

Select one skill: marketing-measurement-contract. Pinned entrypoint: skills/marketing-measurement-contract/SKILL.md; SHA-256 0cac45d6d7074b1a82523dda83e6578a969a899ffaf0db5eed430a86e14cd189. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-lifecycle-orchestration, coordinate-project-delivery) are context only, not extra simultaneous selected skills.

Input contract: Explicit synthetic demo request/attendance lifecycle and exact IDs/cutoffs.

Output contract: demo-event-contract.json + demo-funnel.json.

1. Define exact synthetic request/qualified/attendance events, identity, cutoff and completeness fields.
2. Validate event lineage with the new demo/workshop contract, not the settled-purchase helper.
3. Deduplicate exact IDs and expose invalid stage sequences or missing source coverage.
4. Emit objective-specific stages and exceptions; no inferred attribution or conversion-definition substitution.

Execution route N / N04: Exact operation and current availability: ../../references/implementation-bindings.json, key R21.W3. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: wrong_goal_alias rejects purchase-validator substitution; duplicate/conflicting IDs quarantine; no attribution/lift claim. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R21.W4 — Prepare provider-neutral operational handoff

Select one skill: marketing-measurement-contract. Pinned entrypoint: skills/marketing-measurement-contract/SKILL.md; SHA-256 0cac45d6d7074b1a82523dda83e6578a969a899ffaf0db5eed430a86e14cd189. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (design-lifecycle-orchestration, coordinate-project-delivery) are context only, not extra simultaneous selected skills.

Input contract: Role outputs, exception queue and no-op external action records.

Output contract: operations-handoff.json.

1. Assemble accepted output references, unresolved exceptions and exact ownership for the next operator.
2. Represent external operations as no-op proposals with explicit authority requirements.
3. Retain provenance and rollback/retry uncertainty without embedding credentials or private payloads.
4. Deliver a provider-neutral handoff, not a connected automation or assertion of successful external transport.

Execution route N / N18: Exact operation and current availability: ../../references/implementation-bindings.json, key R21.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Every pending action has owner and authority state; unsupported connector not fabricated; no installed automation. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
