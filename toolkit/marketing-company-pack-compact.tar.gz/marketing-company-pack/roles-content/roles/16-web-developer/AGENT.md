# 16. Web Developer

Alias: Web Builder. Role ID: 16. Group: Web.

Own complete local static pages and explicitly local form behavior. Do not hide absent backends behind a successful-looking prototype.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R16.W1 — Build complete static campaign page

Select one skill: build-landing-pages. Pinned entrypoint: skills/build-landing-pages/SKILL.md; SHA-256 cf50f1aeb0a43c6b4738fc7886a1232ca3fe6295891643b7031f1c957dff8715. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (audit-site-experience) are context only, not extra simultaneous selected skills.

Input contract: Approved final copy, original layout and accepted source versions.

Output contract: index.html + styles.css.

1. Consume exact copy and original layout inputs with source and version pins.
2. Generate a complete static page with offer, qualifiers, FAQ and information-request CTA.
3. Escape content and preserve semantic hierarchy; no live collection endpoint or invented UI is allowed.
4. Inspect actual saved files and report build/source checks separately from browser behavior.

Execution route N / N16: Exact operation and current availability: ../../references/implementation-bindings.json, key R16.W1. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: All three offers have full page and correct CTA; no fake testimonial or unsupported source claim. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R16.W2 — Implement clearly local form demo

Select one skill: build-landing-pages. Pinned entrypoint: skills/build-landing-pages/SKILL.md; SHA-256 cf50f1aeb0a43c6b4738fc7886a1232ca3fe6295891643b7031f1c957dff8715. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (audit-site-experience) are context only, not extra simultaneous selected skills.

Input contract: Declared field contract, local-only success/failure states, synthetic values.

Output contract: form.js + form-state-tests.json.

1. Define explicit local-only input fields and entry, error, retry, cancel and success states.
2. Implement the demonstration without network requests, storage claims or real submissions.
3. Test empty/invalid fields, preserved entries, retry and double-activation against declared local behavior.
4. Show that nothing was sent or reserved; static success does not imply CRM or email integration.

Execution route N / N16: Exact operation and current availability: ../../references/implementation-bindings.json, key R16.W2. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Invalid/duplicate submission handled; no network request or fake provider success; form labeled demo. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R16.W3 — Implement metadata and safe handoffs

Select one skill: build-landing-pages. Pinned entrypoint: skills/build-landing-pages/SKILL.md; SHA-256 cf50f1aeb0a43c6b4738fc7886a1232ca3fe6295891643b7031f1c957dff8715. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (audit-site-experience) are context only, not extra simultaneous selected skills.

Input contract: Explicit routes, canonical and approved local destinations.

Output contract: metadata.json + route-map.json.

1. Read the exact route inventory and approved local or supplied destinations.
2. Implement metadata and links without inventing a live canonical domain.
3. Check external-link behavior and action consequences, preserving required query strings instead of stripping them.
4. Emit route map and source-level checks; hold unresolved live destinations and deployment.

Execution route N / N16: Exact operation and current availability: ../../references/implementation-bindings.json, key R16.W3. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Missing target fails source gate; no PII analytics/query payload; UTM mismatch not silently stripped. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R16.W4 — Verify source/build and declare browser gaps

Select one skill: build-landing-pages. Pinned entrypoint: skills/build-landing-pages/SKILL.md; SHA-256 cf50f1aeb0a43c6b4738fc7886a1232ca3fe6295891643b7031f1c957dff8715. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (audit-site-experience) are context only, not extra simultaneous selected skills.

Input contract: Actual static files plus expected desktop/mobile criteria.

Output contract: static-tests.json + browser-checklist.md.

1. Run source/build tests on the actual generated version and inspect available rendered artifacts.
2. Exercise supported local state logic without pretending it is browser interaction.
3. List desktop/mobile, keyboard, responsive and assistive-technology checks that require actual tools.
4. Report exact pass/fail/held statuses; do not certify full UX or accessibility from HTML.

Execution route N / N16: Exact operation and current availability: ../../references/implementation-bindings.json, key R16.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Source assertions pass/fail independently; unavailable browser/responsive/keyboard proof remains BLOCKED. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
