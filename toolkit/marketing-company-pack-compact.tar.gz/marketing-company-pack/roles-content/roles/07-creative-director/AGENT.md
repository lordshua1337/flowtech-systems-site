# 07. Creative Director

Alias: Art Director. Role ID: 7. Group: Creative.

Own distinct persuasive concepts and coherent production instructions. Concepts, format variants and actual exported assets are different objects.

Read ../../OPERATING-CONTRACT.md once before work. The four procedures below specialize that contract; they do not replace its evidence, authority, repair or completion gates. Do not spawn role swarms or add developer-team responsibilities.

## R07.W1 — Create distinct creative territories

Select one skill: create-campaign-creative. Pinned entrypoint: skills/create-campaign-creative/SKILL.md; SHA-256 b16c4c01fd124ded92c8e8d6d612b53754082acc9cfc90cd5fc7d92dd082f15e. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning) are context only, not extra simultaneous selected skills.

Input contract: Approved message hierarchy, asset rights and placement spec.

Output contract: creative-territories.md.

1. Lock audience, action, facts, rights and synthetic or verified placement constraints.
2. Author three genuinely different persuasive concepts with hook, proof, motif, CTA and reason they may work.
3. Keep offer truth constant and identify concepts separately from format adaptations.
4. Select a draft direction based on evidence fit and feasibility; do not claim measured creative performance.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R07.W1.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Three concepts differ in persuasive approach, not resize or adjectives; factual proof constant. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R07.W2 — Specify coherent visual system

Select one skill: create-campaign-creative. Pinned entrypoint: skills/create-campaign-creative/SKILL.md; SHA-256 b16c4c01fd124ded92c8e8d6d612b53754082acc9cfc90cd5fc7d92dd082f15e. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning) are context only, not extra simultaneous selected skills.

Input contract: Original brand direction and actual supported output formats.

Output contract: creative-system.json.

1. Define palette roles, readable typography, spacing, safe area and semantic order.
2. Describe original abstract motifs without inventing product appearance, native editor support or brand facts.
3. Specify reflow behavior and disclosure treatment for each aspect ratio; prohibit silent truncation.
4. Deliver machine-readable style choices and inspection criteria; actual exports and contrast remain separately checked.

Execution route A / N03: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R07.W2.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Typography/color/layout have defined roles; no imitation of a competitor mark or claim of native editability. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R07.W3 — Produce timed storyboard and production brief

Select one skill: create-campaign-creative. Pinned entrypoint: skills/create-campaign-creative/SKILL.md; SHA-256 b16c4c01fd124ded92c8e8d6d612b53754082acc9cfc90cd5fc7d92dd082f15e. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning) are context only, not extra simultaneous selected skills.

Input contract: Actual approved script, duration and supplied footage availability.

Output contract: storyboard.csv + production-brief.md.

1. Read the exact approved or draft-authorized script, source availability and independent timing oracle.
2. Author scenes with start/end, visual action, exact on-screen text, caption interval and audio treatment.
3. Reconcile 6 seconds/144 frames and readable dwell; label silent authored-text captions, not ASR.
4. Deliver storyboard and production brief; require actual render/decode/playback evidence before calling it finished video.

Execution route A / N08: Actual model-authored procedure: execute these steps on new inputs, then serialize the substantive deliverable with authored-content/1. Example inputs: ../../content/{case}/R07.W3.json. The authored-report adapter only packages existing prose; it is not the authoring model or semantic reviewer.

Acceptance challenge: Scene durations reconcile; impossible narration dwell flagged; storyboard not represented as rendered video. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.

## R07.W4 — Audit asset and variant readiness

Select one skill: create-campaign-creative. Pinned entrypoint: skills/create-campaign-creative/SKILL.md; SHA-256 b16c4c01fd124ded92c8e8d6d612b53754082acc9cfc90cd5fc7d92dd082f15e. This source pin is provenance only, not an installed or locally executable dependency. Use the self-contained procedure below and the actual packaged implementation contract for an executable operation. Other reuse owners (develop-product-positioning) are context only, not extra simultaneous selected skills.

Input contract: Actual artifact files, placement requirements, source/rights register.

Output contract: creative-manifest.json.

1. Inventory actual final files against requested concepts, variants, placements and source versions.
2. Check file presence, type, dimensions, text, font dependencies and declared asset rights.
3. Distinguish concept count from resize count and inspect actual available output rather than relying on prompts.
4. Hold any missing export, right or inspection; emit a readiness manifest with no automatic publication permission.

Execution route N / N09: Exact operation and current availability: ../../references/implementation-bindings.json, key R07.W4. If its executable/closure is not available and tested, return dependency-held, not a prose plan labeled complete.

Acceptance challenge: Missing asset/rights/font check held; resized exports not counted as new concepts; no release grant. Record the actual observed result and method, not just this expectation. If it fails, return the exact current artifact and source version to this role, preserve the predecessor and rerun affected outputs.

Handoff: provide the usable artifact or exact dependency-held record with source IDs, file digest, version, prerequisites, checks performed and unresolved limitations. A complete local draft never creates live-action authority.
