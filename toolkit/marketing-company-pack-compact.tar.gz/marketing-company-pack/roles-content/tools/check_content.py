#!/usr/bin/env python3
"""Literal content checks only. This does not establish semantic truth or independent approval."""
import argparse,csv,hashlib,json,re,sys
from pathlib import Path

def check_envelope(x):
    if not isinstance(x,dict) or set(x)!={'schema','title','sections'}:raise ValueError('authored envelope fields differ')
    if x['schema']!='authored-content/1' or not isinstance(x['title'],str) or not x['title'].strip():raise ValueError('bad schema/title')
    if not isinstance(x['sections'],dict) or not x['sections']:raise ValueError('missing sections')
    for k,v in x['sections'].items():
        if not isinstance(k,str) or not k.strip() or not isinstance(v,list) or not v or any(not isinstance(t,str) or not t.strip() for t in v):raise ValueError('invalid authored section')
    return True

def direct_claim_tripwires(text,case):
    """Catch explicitly seeded direct-claim strings; not a general semantic or negation classifier."""
    checks={
      'maplebench':[r'60\s*%\s*of\s*(?:all\s*)?coffee shops',r'shipping is free',r'guarantees? (?:more sales|revenue)',r'sustainable LoopStand',r'30\s*cm wide'],
      'harbor_workshops':[r'(?:50\s*%|half)\s*of\s*all\s*(?:shop\s*)?operators',r'(?:our|earn) accredited',r'only a few seats remain',r'double your revenue'],
      'ledgernest':[r'(?:66\.7\s*%|two thirds)\s*of\s*all teams',r'49\s*(?:USD|dollars) per user',r'delivers certified security',r'includes real-time two-way',r'it is SOC2 certified']}
    return [p for p in checks[case] if re.search(p,text,re.I)]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--content-root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--fixtures',type=Path,required=True);ap.add_argument('--output',type=Path);args=ap.parse_args()
    p=args.content_root;f=args.fixtures;checks=[]
    def record(name,condition,detail=''):
        checks.append({'check':name,'passed':bool(condition),'detail':detail})
    briefs=json.loads((f/'scenario-seeds.json').read_text())['briefs'];corpus=json.loads((f/'source-corpus.json').read_text());extra=json.loads((f/'comparison-editorial-issue-fixtures.json').read_text())
    roles=json.loads((p/'references/roles.json').read_text());reg=json.loads((p/'references/workflow-registry.json').read_text());manifest=json.loads((p/'CONTENT-MANIFEST.json').read_text())
    record('exact_role_count',len(roles)==27 and {r['id'] for r in roles}==set(range(1,28)))
    record('four_workflows_per_role',len(reg)==108 and all(sum(r['role_id']==i for r in reg)==4 for i in range(1,28)))
    expected={(b['id'],r['workflow_id']) for b in briefs for r in reg if r['route']=='A'}
    actual={(r['case_id'],r['workflow_id']) for r in manifest['artifacts']}
    record('108_authored_case_workflows',len(expected)==108 and actual==expected)
    for row in manifest['artifacts']:
        key=row['case_id']+'/'+row['workflow_id'];q=p/row['input_path'];x=json.loads(q.read_text())
        try:check_envelope(x);okay=True
        except ValueError:okay=False
        record('envelope:'+key,okay)
        record('substantive_sections:'+key,len(x['sections'])>=4 and sum(len(t.split()) for v in x['sections'].values() for t in v)>=100,'Minimum content coverage is not semantic validation.')
        for typ in ['input','readable']:
            record('hash:'+key+':'+typ,hashlib.sha256((p/row[typ+'_path']).read_bytes()).hexdigest()==row[typ+'_sha256'])
    for b in briefs:
        case=b['id'];q=p/'content'/case;media=json.loads((p/'media-copy'/f'{case}.json').read_text())
        record('exact_cta:'+case,media['campaign']['cta']==b['cta'] and media['landing']['cta']==b['cta'])
        public_text=[media['campaign']['headline'],media['campaign']['subhead'],media['campaign']['price_line']]
        for name,hlim,blim in [('ad-copy.csv',40,180),('paid-social-creative.csv',80,500)]:
            rs=list(csv.DictReader((q/name).open()))
            for n,r in enumerate(rs):
                body=r['body'] if name=='ad-copy.csv' else r['primary_text']
                record('length:'+case+':'+name+':'+str(n),len(r['headline'])<=hlim and len(body)<=blim and len(r['cta'])<=32)
                record('cta:'+case+':'+name+':'+str(n),r['cta']==b['cta'])
                public_text += [r['headline'],body]
        messages=json.loads((q/'lifecycle-messages.json').read_text())
        record('no_send_state:'+case,messages['send_authorized'] is False and messages['recipient'] is None and all(r['state']=='local_draft' and r['trigger_evidence'] is None for r in messages['messages']))
        public_text += [r['body'] for r in messages['messages']]
        record('direct_claim_tripwires_clean:'+case,not any(direct_claim_tripwires(t,case) for t in public_text),'Narrow direct-claim strings only; rejected-claim discussions are intentionally excluded.')
        coded=list(csv.DictReader((q/'coded-evidence.csv').open()));raw=corpus['interviews'][case]
        record('exact_quotes:'+case,len(coded)==len(raw) and all(r['exact_quote']==s['quote'] and r['span_id']==s['span'] and r['participant_id']==s['id'] and r['purchase_intent']==s['purchase_intent'] and r['codes'].split(';')==s['themes'] for r,s in zip(coded,raw)))
        record('unique_participants:'+case,len({r['participant_id'] for r in coded})==len(raw))
        bank=list(csv.DictReader((q/'proof-bank.csv').open()))
        record('proof_permissions:'+case,all(r['quote_private_draft']=='True' and r['name_public']=='False' and r['logo_public']=='False' and r['publication']=='False' for r in bank))
        old=next(o for o in extra['old_pages'] if o['brief_id']==case);log=json.loads((q/'editorial-change-log.json').read_text())
        record('exact_repair_source:'+case,log['before_source_id']==old['id'] and log['before_version']==old['version'])
        price=media['campaign']['price_line']
        if case=='maplebench':record('literal_maple_terms','149' in price and 'extra' in price and 'unverified' in media['campaign']['disclaimer'].lower() and 'have not been identified' in media['landing']['faq'][0]['answer'])
        if case=='harbor_workshops':record('literal_harbor_terms','85' in price and '12' in price and 'unknown' in price and '90-minute' in media['landing']['sections'][0]['body'])
        if case=='ledgernest':record('literal_ledger_terms','49 per workspace' in price and '480 annually' in price and 'Five seats' in price and 'differ' in price and 'manual CSV export' in media['landing']['sections'][0]['body'])
    source_map=json.loads((p/'references/evidence-sources.json').read_text())['sources'];ids={s['id'] for s in source_map}
    record('all_source_ids_exist',all(set(r['sources'])<=ids for r in manifest['artifacts']))
    for sr in source_map:record('fixture_digest:'+sr['id'],hashlib.sha256((f/sr['fixture']).read_bytes()).hexdigest()==sr['fixture_sha256'])
    # Missing fields and altered evidence are negative inputs, not edits to deliverable files.
    good={'schema':'authored-content/1','title':'t','sections':{'s':['text']}}
    for key in ['schema','title','sections']:
        bad=dict(good);del bad[key]
        try:check_envelope(bad);rejected=False
        except ValueError:rejected=True
        record('negative_missing_'+key,rejected)
    for case,text in [('maplebench','60% of coffee shops lack space.'),('maplebench','Shipping is free.'),('maplebench','LoopStand is 30 cm wide.'),('harbor_workshops','Earn accredited certification.'),('harbor_workshops','Only a few seats remain.'),('ledgernest','It is SOC2 certified.'),('ledgernest','49 USD per user per month.')]:
        record('negative_seed:'+text,bool(direct_claim_tripwires(text,case)))
    quote=corpus['interviews']['maplebench'][0]['quote'];changed=quote.replace('not evaluated','evaluated')
    record('negative_changed_quote',changed!=quote)
    record('negative_oversize_ad',len('x'*41)>40)
    report={'schema':'authored-literal-checks/1','passed':all(r['passed'] for r in checks),'checks':checks,'total':len(checks),'failures':[r for r in checks if not r['passed']],'semantic_truth_verified':False,'independent_review':False,'limitations':['Envelope, literal data, length and narrow seeded-tripwire checks only.','No general contradiction, negation, persuasion, legal or source-authenticity verification.','No executed browser, send, native-render or production behavior is established.']}
    text=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(text)
    else:print(text)
    print(f'{len(checks)} checks; {len(report["failures"])} failures; semantic review not established.',file=sys.stderr)
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
