# 27 marketing roles and authored campaign drafts

Read OPERATING-CONTRACT.md, then the relevant roles/NN-name/AGENT.md. Each role has four distinct procedures with inputs, outputs, selected-skill references, acceptance challenges and repair/permission boundaries.

The three fictional cases each contain 36 substantial authored workflow drafts, 108 authored inputs in total. They cover strategy, exact interview coding, account and competitive research, creative concepts, full landing/ad/email copy, editorial repair, social/PR, CRO/experiment design, partner proposals and sales enablement. Machine-readable companions retain coding, ads, proof, storyboards and acceptance criteria. CONTENT-MANIFEST.json identifies every authored workflow/case/version/hash.

These are real draft artifacts, not evidence that a live campaign ran. New cases require a model host to execute the written procedures; the shared authored-content/1 packaging adapter does not write or fact-check content. Numeric/source/length tests are deliberately narrower than independent semantic review.

media-copy/ contains source-grounded draft-1 inputs for separate original SVG/PDF/video/static-page production. The versioned production manifest, not this folder alone, establishes which media files were built and inspected. Unavailable browser, native, public-release and sending capabilities remain explicit holds.

references/evidence-sources.json maps stable evidence IDs to the supplied fictional fixture filenames and JSON pointers. references/selected-skills.json pins selected repository entrypoints without claiming installed-support parity. references/implementation-bindings.json records where actual operations are available or held; consult the enclosing pack's final workflow-status and validation records before relying on a completion claim.

No additional role, developer team, external contact, real purchase, deployment or publication is included. This component awards itself no qualification credit.
