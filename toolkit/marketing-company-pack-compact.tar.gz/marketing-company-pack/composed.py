"""Bounded, trusted local composition over the unchanged file-runtime/v2 envelopes.

This is not a model host, network integration, security sandbox or semantic judge.
"""
from __future__ import annotations
import copy, hashlib, json, mimetypes, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor/shared-runtime'))
import engine
from file_runtime import FileArtifactAdapter, FileArtifactOrchestrator, safe_path, file_reference
from legacy.orchestrator import ContractError, Limits, make_result, canonical
sys.path.insert(0, str(ROOT))

FUNCTIONS = {'shared.authored', 'shared.allocation', 'shared.registry', 'shared.demo',
             'business.themes', 'business.accounts', 'business.partners', 'business.competitors',
             'business.search', 'business.calendar', 'business.joint_plan', 'business.media',
             'business.paid_social', 'business.decision', 'media.graphics', 'media.video',
             'media.technical', 'media.web', 'email.build', 'lead.plan', 'pack.route', 'pack.audit', 'pack.brief', 'pack.registry', 'pack.authority', 'pack.rights','editorial.check','design.wireflow','evidence.refresh','audit.markup'}
from helpers import HELPERS
FUNCTIONS |= {'helper.'+name for name in HELPERS}

def sha(data): return hashlib.sha256(data).hexdigest()
def jbytes(value): return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
def read_json(path): return engine.parse_json(Path(path).read_bytes())

def verify_lock(root=ROOT, expected=None):
    raw = safe_path(root, 'SOURCE-LOCK.json').read_bytes()
    if expected is not None and sha(raw) != expected: raise ValueError('Source lock changed')
    lock = engine.parse_json(raw)
    for item in lock['files']:
        p = safe_path(root, item['path'])
        if not p.is_file() or sha(p.read_bytes()) != item['sha256']: raise ValueError('Source closure changed: ' + item['path'])
    return len(raw) + sum(x['bytes'] for x in lock['files'])

class Adapter(FileArtifactAdapter):
    def __init__(self, root, output_root):
        super().__init__(root, output_root)
        self.counters.update(nested_processes=0, media_render_invocations=0, authored_packaging_invocations=0)
    def read_ref(self, ref, *, artifact=False):
        engine.fields(ref, 'path sha256 media_type artifact_type', 'file reference')
        engine.require(isinstance(ref['media_type'], str) and engine.nonempty(ref['artifact_type']), 'Malformed file type')
        data = safe_path(self.root, ref['path']).read_bytes()
        self.counters['artifact_bytes_read' if artifact else 'source_bytes_read'] += len(data)
        engine.require(sha(data) == ref['sha256'], 'Changed referenced file artifact')
        return data
    def verify_files(self, artifact):
        for ref in artifact['files']:
            data = self.read_ref(ref, artifact=True)
            bundle = engine.parse_json(data)
            engine.require(bundle.get('schema') == 'produced-bundle/1', 'Wrong output bundle')
            prefix = Path(ref['path']).parent
            seen = set()
            for f in bundle['files']:
                q = Path(f['path'])
                engine.require(q.is_relative_to(prefix) and q != Path(ref['path']) and f['path'] not in seen, 'Wrong or duplicate bundle namespace')
                seen.add(f['path']); self.read_ref(f, artifact=True)
            engine.require(bool(seen), 'Empty produced bundle')
    def publish(self, packet, outputs):
        for value in (packet['run_id'], packet['job_id']):
            engine.require(re.fullmatch(r'[A-Za-z0-9_-]{1,80}', value), 'Unsafe run/job name')
        parent = self.output_root / packet['run_id']; parent.mkdir(exist_ok=True)
        final = parent / (packet['job_id'] + '-' + str(packet['attempt']))
        safe_path(self.root, str(final.relative_to(self.root)))
        stage = Path(tempfile.mkdtemp(prefix='.stage-', dir=parent)); owned = False
        try:
            files = []
            for name, (media, payload) in sorted(outputs.items()):
                engine.require(name != 'bundle.json' and all(re.fullmatch(r'[A-Za-z0-9_.-]+', v) for v in Path(name).parts), 'Unsafe produced name')
                dest = safe_path(stage, name); dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(payload); self.counters['artifact_bytes_written'] += len(payload)
                files.append({'path': str((final/name).relative_to(self.root)), 'sha256': sha(payload), 'media_type': media, 'artifact_type': packet['role_contract']['output_type']})
            raw = jbytes({'schema':'produced-bundle/1','dispatch_id':packet['dispatch_id'], 'selected_function':packet['selected_skill']['contract']['function'], 'files':files, 'semantic_truth_verified':False, 'release_authorized':False})
            (stage/'bundle.json').write_bytes(raw);self.counters['artifact_bytes_written'] += len(raw)
            final.mkdir(exist_ok=False); owned=True
            for src in sorted(stage.rglob('*')):
                if src.is_file():
                    dst=final/src.relative_to(stage);dst.parent.mkdir(parents=True,exist_ok=True);os.link(src,dst)
            return [{'path':str((final/'bundle.json').relative_to(self.root)),'sha256':sha(raw),'media_type':'application/json','artifact_type':packet['role_contract']['output_type']}]
        except OSError:
            self.counters['publication_failures'] += 1
            if owned: shutil.rmtree(final)
            raise
        finally: shutil.rmtree(stage)
    def prerequisite_index(self, packet):
        result=[]
        for artifact in packet['prerequisites']:
            self.verify_files(artifact)
            bundle=engine.parse_json(self.read_ref(artifact['files'][0],artifact=True))
            result.append({'job_id':artifact['id'].split('/')[-3], 'owner_role_id':artifact['owner_role_id'],'artifact_id':artifact['id'],'files':bundle['files']})
        return result
    def __call__(self, packet):
        try:
            selected=packet['selected_skill'];contract=engine.parse_json(self.read_ref(selected['contract_ref']))
            engine.require(contract==selected['contract'], 'Selected contract changed')
            self.read_ref(selected['implementation_ref'])
            self.counters['source_bytes_read'] += verify_lock(self.root, contract['source_lock_sha256'])
            refs=packet['input_refs'];engine.require(len(refs)==1,'One selected input required')
            raw=self.read_ref(refs[0]);data=engine.parse_json(raw);function=contract['function']
            upstream=self.prerequisite_index(packet)
            self.counters['function_invocations'] += 1
            if function.startswith('shared.'):
                report=engine.execute(function.split('.')[1],data);outputs=engine.artifact_bytes(report)
                if function=='shared.authored':self.counters['authored_packaging_invocations']+=1
            elif function in {'pack.brief','pack.registry','pack.authority','pack.rights'}:
                import mechanical
                outputs=mechanical.execute(function,data,packet,self)
            elif function in {'pack.route','pack.audit'}:
                report={'schema':function+'/1','case_id':data['case_id'],'prerequisites':upstream,'selected_workflow':contract['skill_id'],'external_action_queue':[{'action':a,'owner_role_id':r,'authority':'absent','state':'blocked'} for a,r in [('send',20),('spend',18),('publish',16)]], 'semantic_review_required':True, 'release_authorized':False}
                if function=='pack.audit':
                    registry=engine.parse_json(self.read_ref(data['registry_ref']))
                    report['workflow_statuses']=[{'id':w['workflow_id'],'status':w['status']} for w in registry['workflows']]
                    report['coverage_count']=len(registry['workflows']);report['actual_upstream_roles']=[a['owner_role_id'] for a in upstream]
                    report['checks']={'all_108_workflow_ids':len(registry['workflows'])==108,'actual_files_rehashed':True,'semantic_truth':False,'whole_pack_independent_review':False}
                    engine.require(report['checks']['all_108_workflow_ids'],'Incomplete workflow registry')
                outputs={'report.json':('application/json',jbytes(report)),'report.txt':('text/plain',jbytes(report))}
            else:
                # A fixed trusted runner, never caller-selected code or shell commands.
                work=Path(tempfile.mkdtemp(prefix='.invoke-',dir=self.output_root))
                try:
                    input_file=work/'input.json';input_file.write_bytes(raw);out=work/'produced'
                    proc=subprocess.run([sys.executable,'-B',str(self.root/'invoke.py'),function,str(input_file),str(out)],cwd=self.root,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
                    self.counters['spawned_processes']+=1
                    # Retain failure receipts outside accepted namespaces.
                    if proc.returncode:
                        failure=self.output_root/f"failure-{packet['run_id']}-{packet['job_id']}-{packet['attempt']}"
                        failure.mkdir(exist_ok=False)
                        from portable_receipts import retain_raw
                        private_stdout=retain_raw('failed-invocation-stdout',proc.stdout);private_stderr=retain_raw('failed-invocation-stderr',proc.stderr)
                        (failure/'diagnostic.json').write_bytes(jbytes({'status':'failed','raw_stdout':private_stdout,'raw_stderr':private_stderr,'note':'Original raw process evidence is retained outside the export, not relabeled as this portable diagnostic.'}));(failure/'input.json').write_bytes(raw)
                        if out.exists():shutil.copytree(out,failure/'partial')
                        raise ValueError('Whitelisted invocation failed; inspect separately retained raw stderr receipt '+private_stderr['sha256'])
                    receipt=read_json(out/'execution.json');self.counters['nested_processes']+=receipt.get('nested_processes',0)
                    if function.startswith('media.'):self.counters['media_render_invocations']+=1
                    outputs={str(f.relative_to(out)):(mimetypes.guess_type(f.name)[0] or 'application/octet-stream',f.read_bytes()) for f in out.rglob('*') if f.is_file()}
                finally:shutil.rmtree(work)
            self.counters['function_successes']+=1
            # Artifact consumption is an integrity dependency, not inferred semantic review.
            outputs['consumption.json']=('application/json',jbytes({'prerequisite_artifacts':upstream,'scope':'Byte-bound prerequisite consumption only. Each selected handler uses its explicit input; no automatic semantic merge or generative reasoning.'}))
            files=self.publish(packet,outputs)
            proposal={k:[f"Executed {function} on explicit source-bound input. Read produced bundle. Semantic review and external release remain unestablished."] for k in packet['role_contract']['proposal_fields']}
            result=make_result(packet,proposal=proposal)
            result['artifact'].update(files=files,selected_skill=copy.deepcopy(selected),input_refs=copy.deepcopy(refs))
            result['artifact']['limitations']=['Actual bounded local execution. Authored-content packaging does not author content. Hashes establish bytes, not source authenticity, rights or semantics. No live actions.']
            return result
        except OSError as exc:
            from portable_receipts import os_error
            return make_result(packet,status='failed',error={'code':type(exc).__name__,'detail':os_error(exc),'retryable':True})
        except (ValueError,TypeError,KeyError) as exc:
            return make_result(packet,status='failed',error={'code':type(exc).__name__,'detail':str(exc),'retryable':False})

class Orchestrator(FileArtifactOrchestrator):
    def selected_contract(self, job):
        sid=job['skill_id'];entry=self.catalog[sid]
        engine.fields(entry,'contract_ref implementation_ref','catalog entry')
        contract=engine.parse_json(self.adapter.read_ref(entry['contract_ref']))
        engine.fields(contract,'schema skill_id function output_type input_media_type implementation_sha256 source_lock_sha256','composed contract')
        engine.require(contract['schema']=='composed-skill/1' and contract['skill_id']==sid,'Wrong selected identity')
        engine.require(contract['function'] in FUNCTIONS,'Unsupported trusted function')
        engine.require(contract['output_type']==self.roles[job['role_id']]['output_type'],'Wrong owner envelope')
        engine.require(contract['input_media_type']=='application/json','Wrong input media')
        impl=self.adapter.read_ref(entry['implementation_ref'])
        engine.require(sha(Path(__file__).read_bytes())==contract['implementation_sha256']==entry['implementation_ref']['sha256'] and impl==Path(__file__).read_bytes(),'Wrong composed implementation')
        self.adapter.counters['source_bytes_read']+=verify_lock(self.file_root,contract['source_lock_sha256'])
        return {'skill_id':sid,**copy.deepcopy(entry),'contract':contract}
    def validate_result(self,result):
        size=super().validate_result(result)
        if result['status']=='ok':self.adapter.counters['source_bytes_read']+=verify_lock(self.file_root,result['artifact']['selected_skill']['contract']['source_lock_sha256'])
        return size
    def summary(self):
        out=super().summary();out['execution']='actual_whitelisted_local_composition';out['semantic_truth_verified']=False;out['live_ready']=False
        return out
