"""Fresh sequential resimulation and per-workflow evidence collection.

Writes only a fresh output directory. No independent semantic qualification.
"""
import json,sys
from pathlib import Path
from composed import ROOT,read_json,jbytes,sha,Adapter,safe_path
from pack import run_case
from run_exercises import exercises
from deliverable_acceptance import accept,harness_accept
CASES=['maplebench','harbor_workshops','ledgernest']

def check_bundle(bundle_ref,workflow,case,input_ref):
    bundle=read_json(ROOT/bundle_ref['path']);checks=[]
    paths={Path(f['path']).name:f for f in bundle['files']}
    for f in bundle['files']:
        assert sha((ROOT/f['path']).read_bytes())==f['sha256'];checks.append({'check':'produced_file_sha256','path':f['path'],'passed':True})
    fn=bundle['selected_function'];report=read_json(ROOT/paths['report.json']['path']) if 'report.json' in paths else None
    if fn=='shared.authored':
        source=read_json(ROOT/input_ref['path']);assert report['sections']==source['sections'] and report['title']==source['title'] and not report['semantic_truth_verified'];checks.append({'check':'complete_authored_sections_preserved_not_generation','passed':True})
    if fn=='shared.allocation':
        wanted={'maplebench':150000,'harbor_workshops':120000,'ledgernest':200000}[case];assert report['total_minor']==wanted and report['headroom_minor']==0 and not report['platform_budget_enforced'];checks.append({'check':'literal_shared_cap_and_zero_headroom','passed':True})
    if fn=='business.themes':
        assert report['studies'][0]['all_participant_fraction']=={'maplebench':'3/5','harbor_workshops':'2/4','ledgernest':'4/6'}[case];checks.append({'check':'independent_sample_denominator','passed':True})
    if fn=='business.competitors' and case=='maplebench':
        c=report['comparators'][0];assert c['observed']['price_minor']==18900 and c['baseline']['price_minor']==17900 and c['delivered_difference_minor'] is None;checks.append({'check':'current_fixture_observation_and_unknown_shipping','passed':True})
    if fn=='business.paid_social':
        assert report['plans'][0]['disposition']=='held_review' and 'creative_rights_unknown' in report['plans'][0]['holds'];checks.append({'check':'explicit_local_audience_taxonomy_and_unknown_rights_hold','passed':True})
    if fn=='media.video':
        q=read_json(ROOT/paths['media-qc.json']['path']);assert q['observed_frames']==144 and q['observed_seconds']==6 and q['audio_streams']==0 and q['full_playback_review']=='not_established';checks.append({'check':'actual_decode_144_frames_6_seconds_silent','passed':True})
    if fn=='media.technical':
        q=read_json(ROOT/paths['dimension-contract.json']['path']);assert q['product_axis_order'] is None and q['native_geometry_status']=='held_runtime';checks.append({'check':'unknown_product_axes_native_hold','passed':True})
    if fn=='media.web':
        text=(ROOT/paths['index.html']['path']).read_text();assert 'connect-src \'none\'' in text and 'Nothing is sent or saved' in text;checks.append({'check':'actual_local_page_external_transport_disabled','passed':True})
    if fn=='email.build':
        stages=[f for f in bundle['files'] if f['path'].endswith('email.txt')];assert len(stages)==3
        cta=read_json(ROOT/'inputs'/case/'run.json')['source']['facts']['BRIEF']['value']['cta'];assert all(cta in (ROOT/f['path']).read_text() for f in stages);checks.append({'check':'three_actual_email_stages_exact_cta','passed':True})
    if fn=='editorial.check':
        assert report['mechanical_discrepancies']==0 and report['semantic_review_required'] is True and 'authored-review.json' in paths;checks.append({'check':'actual_annotated_spans_and_quotes_match_review_required','passed':True})
    return {'case_id':case,'workflow_id':workflow,'selected_function':fn,'bundle':bundle_ref,'promised_deliverable_acceptance':accept(workflow,case,bundle_ref,input_ref),'checks':checks,'semantic_truth_verified':False}

def validate(relative):
    base=safe_path(ROOT,relative);base.mkdir(parents=True,exist_ok=False)
    results={};campaigns={};manifests={c:read_json(ROOT/'inputs'/c/'run.json') for c in CASES}
    for case in CASES:
        folder=relative+'/campaigns/'+case;summary,code=run_case(case,folder);assert code==0 and summary['receipt_count']==27 and summary['file_counters']['function_invocations']==27
        assert summary['counters']['peak_concurrency']==1 and summary['counters']['dispatches']==27 and summary['counters']['external_calls']==0 and not summary['live_ready']
        artifacts=read_json(ROOT/folder/'artifact-index.json');campaigns[case]={'summary':folder+'/summary.json','trace':folder+'/trace.jsonl','artifacts':folder+'/artifact-index.json','actual_selected_dispatches':27}
        for job in manifests[case]['jobs']:
            wid=job['skill_id'];item=check_bundle(artifacts[job['id']]['files'][0],wid,case,job['inputs'][0]);results.setdefault(wid,[]).append(item)
        print('Completed27-role campaign',case,flush=True)
    registry=read_json(ROOT/'WORKFLOWS.json')
    for w in registry['workflows']:
        wid=w['workflow_id'];fn=w['execution']
        if not fn:continue
        target_cases=CASES if fn in {'shared.authored','editorial.check','pack.brief','pack.registry','pack.authority','pack.rights','pack.route','design.wireflow','evidence.refresh','audit.markup'} else ['maplebench']
        for case in target_cases:
            if any(x['case_id']==case for x in results.get(wid,[])):continue
            folder=relative+'/workflows/'+case+'-'+wid.replace('.','-');summary,code=run_case(case,folder,wid)
            if code:raise AssertionError('Workflow failed: '+case+' '+wid+'; inspect '+folder)
            artifacts=read_json(ROOT/folder/'artifact-index.json');artifact=artifacts[wid.replace('.','-')]
            result=check_bundle(artifact['files'][0],wid,case,manifests[case]['workflow_inputs'][wid]);result['summary']=folder+'/summary.json';results.setdefault(wid,[]).append(result)
        print('Checked',wid,fn,flush=True)
    exercise_result=exercises(relative+'/exercises')
    (base/'CAMPAIGNS.json').write_bytes(jbytes(campaigns))
    entries=[]
    for w in registry['workflows']:
        wid=w['workflow_id'];entry={'workflow_id':wid,'name':w['name'],'role_id':w['role_id'],'scope_status':w['status'],'execution_evidence':results.get(wid,[]),'limitation':w['limitation'],'semantic_review_required':True,'qualification_credit':0,'live_release_authorized':False}
        if wid in ['R01.W4','R26.W4']:entry['harness_evidence']=relative+'/exercises/owner-feedback.json'
        elif wid=='R27.W2':entry['harness_evidence']=campaigns
        elif wid=='R27.W3':entry['harness_evidence']=relative+'/exercises/RESULT.json'
        elif wid in ['R11.W3','R11.W4']:entry['hold_evidence']=results['R11.W1'][0]['bundle']
        elif wid=='R27.W4':entry['hold_reason']='Final immutable ZIP and independent export/review receipts are not produced by this integration validator.'
        entry['promised_deliverable_acceptance']=[x['promised_deliverable_acceptance'] for x in results.get(wid,[])] if w['execution'] else [harness_accept(wid,relative,campaigns)]
        entries.append(entry)
    report={'schema':'workflow-execution-results/1','role_count':27,'workflow_count':108,'actual_new_campaign_dispatches':81,'campaigns':campaigns,'workflows':entries,'outer_exercises':exercise_result,'independent_semantic_review':'required_separately','final_zip_verification':'pending_separate_release','full_live_ready':False}
    (base/'WORKFLOW-RESULTS.json').write_bytes(jbytes(report));(base/'CAMPAIGNS.json').write_bytes(jbytes(campaigns));return report
if __name__=='__main__':
    try:r=validate(sys.argv[1]);print('Validated local evidence for',r['workflow_count'],'workflow contracts; live release remains blocked.')
    except Exception as e:print(type(e).__name__+': '+str(e),file=sys.stderr);raise
