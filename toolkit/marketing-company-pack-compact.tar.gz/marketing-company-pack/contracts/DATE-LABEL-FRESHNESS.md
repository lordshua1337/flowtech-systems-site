# Synthetic date-label freshness profile

Profile: synthetic-date-label-utc/1. This is a proposed local review policy, not a user instruction, legal requirement or source fact.

- Preserve each original comparator YYYY-MM-DD as source_observation_date_label with source_time_precision=date_only and its exact source JSON locator.
- source_observed_instant and source_valid_through_instant remain null for date-only comparator facts and linked claims. No observation timezone or time-of-day was supplied.
- calculation_observed_at is constructed as the date label followed by T00:00:00Z; calculation_valid_through adds the proposed 30-day review interval. These instants support deterministic synthetic comparisons only, not real observation times or intraday expiration.
- The declared review cutoff is 00:00 UTC on the campaign start DATE LABEL. Preserve source_campaign_timezone=America/Chicago, but source_campaign_start_instant remains null and cutoff_is_actual_campaign_start=false. No Chicago midnight conversion is performed.
- The calculation comparison is inclusive at valid_through. Exact real-time boundary claims are unavailable for date-only sources. Existing explicit registry-timestamp fixtures retain their separate exact declared-instant tests; they do not supply missing source precision.
- Decisions and CSV/JSON refresh requests expose these values and assumptions alongside holds, affected claim versions and proposed-not-sent actions. No refreshed source, authenticity, network request or live use authority is produced.
