# Portable 27-role marketing pack, version4

A private, bounded local pack for 27 marketing roles and 108 workflow procedures. It includes substantial three-business authored drafts, actual local tools, original SVG/PDF/silent-video/static-page examples, source-bound HTML/text emails, explicit review gates and new file-producing orchestration. It is not 27 live autonomous agents, a production service, a send/spend/deploy system or a universally validated marketing department.

## Start

1. Read START-HERE.md and WORKFLOW-RESULTS.json for exactly what ran and what remains held.
2. Use Python 3.10+ from this directory. No API key or paid provider is needed. Python 3.12 was used for validation.
3. Run `python -B pack.py verify-source` to check the accepted local execution source closure.
4. Run `python -B pack.py run maplebench --out runs/my-maplebench` for a fresh, sequential27-role execution. Substitute `harbor_workshops` or `ledgernest` for the other independent cases.
5. Run one selected workflow with `python -B pack.py workflow maplebench R08.W1 --out runs/my-copy`. Read the output summary and bundle, not just the exit code.
6. Run `python -B -m unittest discover -s tests -v` and `python -B run_exercises.py runs/my-repair-checks` for the integration checks.

Every output path is relative to this pack and must be new. Existing outputs are never intentionally overwritten. Failed invocations retain stdout, stderr, inputs and partial files as failures, never accepted outputs. Root source files and vendor components are immutable references; create a separately reviewed version to change them.

## Dependencies

Most shared, business, editorial, email, lifecycle and reused helpers use Python's standard library. Full27-role runs also call the bundled media code, which requires existing ReportLab, PyMuPDF, Inkscape, Poppler `pdftoppm`, FFmpeg/ffprobe and Node.js. No executable binary is bundled or installed by this pack. See vendor/media-web/DEPENDENCIES.md for versions and licenses, including PyMuPDF's AGPL/commercial and FFmpeg's build/codec limitations. DejaVu fonts and their license are included unchanged.

The recorded environment is Linux/POSIX. Some exact reused filesystem helpers require POSIX no-follow behavior; Windows compatibility is not established. A relocated replay on the same installed toolchain is not cross-platform certification.

If a dependency is missing, the relevant invocation fails with a retained diagnostic. That is not a successful media/browser/native execution. Other bounded workflows can still be run individually. No automatic installation, credential request or provider fallback occurs.

## What the commands actually do

- A normal case has27jobs, one real selected function per role, fixed original owner envelopes, immutable source note, typed prerequisite references and new hashed output files. A single local process dispatches sequentially. It is not networked agent transport.
- Shared packaging retains independently authored draft text. It never writes, reasons about or semantically approves that text. New briefs require a suitable model host and actual role work using the included self-contained instructions.
- Business tools calculate only from supplied finite fictional records. Empty/missing source observations are not measured zeros. Shared account, relationship, media and supplemental helper fixtures are not invented business-specific evidence.
- Media tools generate original code-native assets for the closed three-brief examples. They are not arbitrary design automation. The technical SVG is an explicitly separate fictional training block, never measured LoopStand geometry.
- Email output is actual escaped HTML and plain text with source-bound content. It is not an email-client render, mailbox draft or sent communication.
- Every external action remains blocked. Draft eligibility and contact research do not grant permission to contact anyone.

## Reading coverage honestly

WORKFLOWS.json is the108-entry command/owner/status registry. WORKFLOW-RESULTS.json links actual execution evidence or an explicit hold for each. Some functions support several related workflows, but these are not counted as new skill owners. Supplemental original helper fixtures remain distinct from the new three-business campaign runs. A local artifact may be mechanically checked yet still require semantic review, source authentication, rights review or runtime-specific proof.

Native Blender geometry/rendering, real browser responsive/keyboard/assistive-technology checks, live provider integrations, public release and independent final ZIP review are not inferred from local PASS labels. Print output retains implicit trim/bleed boxes and needs an actual printer specification. All PDF font resources were checked in the corrected media-v3 component; the failed v2 font assertion is recorded as superseded failure, not erased.

## Files and component paths

- roles-content/roles/:27self-contained role profiles, each with4procedures and repair gates.
- roles-content/content/:108substantial original authored workflow/case drafts and readable companions. Additional strategy scorecards and editorial reviews are in vendor/editorial-check/authored/.
- COMPONENTS.json resolves every component-relative implementation binding used by the versioned role profiles. Repository skill paths inside profiles are provenance-only, not missing executable dependencies.
- composed.py, invoke.py, mechanical.py, helpers.py, deliverables.py, deliverable_acceptance.py: narrow trusted local integration layer. Only fixed allowlisted implementations execute. The copied shared-runtime and existing helper source files are unchanged.
- inputs/: independent briefs/corpus/comparison fixtures and explicit per-case selected inputs.
- evidence/final-validation/campaigns/: new final27-role runs, their traces, receipts and actual products.
- evidence/final-validation/workflows/: additional selected workflow executions. evidence/final-validation/exercises/: genuine failure/recovery/rework receipts.
- vendor/: pinned original closures, original tests/contracts/fixtures and historical component evidence. Historical examples are not these new campaign runs.
- INTAKE.json and SOURCE-LOCK.json: exact source identity and execution closure. Hashes prove bytes, not semantics, authenticity or legal permission.

The integration layer is not a sandbox for malicious local code or concurrent hostile filesystem changes. Output counters describe application-observed reads/writes and child processes, not all OS I/O. Model tokens are unknown, not invented zero. Separate final semantic and export review receipts determine the accepted delivery scope.

## Version2 repairs and evidence handling

The business comparator is a changed, separately pinned successor. It derives workspace prices only under the exact supported billing-unit contract. See vendor/business-workflows/contracts/WORKSPACE-UNIT-CONTRACT.md. Unsupported units are held, not reinterpreted.

New helper invocations use pack-relative arguments where supported. Causal helper receipts preserve those actual relative arguments. Email, dependency, coding and contrast tools can return absolute output directories; only that exact verified path field is replaced in an explicitly labeled portable presentation receipt. Original raw stdout is not mislabeled or embedded. Its digest and byte count remain in the presentation, and authentic raw bytes are preserved separately outside the export root. Two unnecessary historical shared-runtime raw traces are excluded with original hashes in PORTABLE-SELECTION.json.

By default, authentic raw process/error evidence is written to a sibling directory named after this pack with the suffix -private-evidence. MARKETING_RAW_EVIDENCE_DIR can select another local directory outside the pack. This local evidence is not automatically exported. A raw error receipt can contain execution locations; inspect it locally when troubleshooting. No broad redaction, fabricated raw stdout or hidden failure conversion is performed.

## Version3 promised-output repairs

R17.W1 now produces a case-bound proposed local wireflow, an original editable SVG and rendered proof. Its six states and eight transitions include error, retry, cancel and local completion, checked by the unchanged graph checker. Added cancel/recovery screens are clearly proposed, not current page behavior. R06.W4 uses a proposed 00:00 UTC review cutoff based on the source campaign-start date label, not its America/Chicago start instant, and a proposed 30-day comparator review policy to produce current/superseded/expired/unknown decisions, affected exact-version claims and a proposed refresh queue. No evidence is refreshed or requested externally. R17.W2 inspects the actual generated HTML for control-name candidates, labels, roles, duplicate IDs and description/error references. It keeps the separate contrast fixture's negative/unknown results and all browser/keyboard/AT unknowns.

Every WORKFLOW-RESULTS entry now maps each promised deliverable to exact actual files, type and content fields, or an explicit unmet native/release hold. A captured validator failure is not completion of a missing producer. These mechanical acceptance checks do not automatically establish semantic equivalence or independent final approval. See docs/VERSION3-REPAIR-NOTES.md.

## Version4 date-label precision

The example freshness review preserves the source YYYY-MM-DD values as date-only labels. Its selected 00:00 UTC cutoff is a proposed synthetic calculation convention on the campaign start date label, not the actual America/Chicago campaign-start instant. Comparator observation midnight and 30-day expiry are likewise constructed calculation instants, not source-observed timestamps or real intraday expiry. Actual source observation/expiry instants remain null. These distinctions are present in freshness-decisions.json and every refresh-queue row, not only in this guide. Exact timestamp boundary tests remain valid only for their explicitly declared timestamp profile. No timezone/calendar conversion, new evidence, authenticity or external refresh is implied. See contracts/DATE-LABEL-FRESHNESS.md.
